-- MariaDB dump 10.19  Distrib 10.4.32-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: db
-- ------------------------------------------------------
-- Server version	10.4.32-MariaDB-1:10.4.32+maria~ubu2004-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `rememberme_token`
--

DROP TABLE IF EXISTS `rememberme_token`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rememberme_token` (
  `series` varchar(88) NOT NULL,
  `value` varchar(88) NOT NULL,
  `lastUsed` datetime NOT NULL COMMENT '(DC2Type:datetime_immutable)',
  `class` varchar(100) NOT NULL,
  `username` varchar(200) NOT NULL,
  PRIMARY KEY (`series`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rememberme_token`
--

LOCK TABLES `rememberme_token` WRITE;
/*!40000 ALTER TABLE `rememberme_token` DISABLE KEYS */;
/*!40000 ALTER TABLE `rememberme_token` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tl_article`
--

DROP TABLE IF EXISTS `tl_article`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tl_article` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `showTeaser` tinyint(1) NOT NULL DEFAULT 0,
  `protected` tinyint(1) NOT NULL DEFAULT 0,
  `published` tinyint(1) NOT NULL DEFAULT 0,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `author` int(10) unsigned NOT NULL DEFAULT 0,
  `inColumn` varchar(32) NOT NULL DEFAULT 'main',
  `teaserCssID` varchar(255) NOT NULL DEFAULT '',
  `teaser` text DEFAULT NULL,
  `printable` varchar(255) NOT NULL DEFAULT '',
  `customTpl` varchar(64) NOT NULL DEFAULT '',
  `groups` blob DEFAULT NULL,
  `cssID` varchar(255) NOT NULL DEFAULT '',
  `start` varchar(10) NOT NULL DEFAULT '',
  `stop` varchar(10) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `tstamp` (`tstamp`),
  KEY `alias` (`alias`),
  KEY `pid_published_incolumn_start_stop` (`pid`,`published`,`inColumn`,`start`,`stop`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tl_article`
--

LOCK TABLES `tl_article` WRITE;
/*!40000 ALTER TABLE `tl_article` DISABLE KEYS */;
INSERT INTO `tl_article` VALUES (1,0,0,1,2,128,1708348752,'Home','home',1,'main','',NULL,'','',NULL,'','',''),(2,0,0,1,3,128,1708348760,'Über uns','ueber-uns',1,'main','',NULL,'','',NULL,'','',''),(3,0,0,1,4,128,1708348765,'News','news',1,'main','',NULL,'','',NULL,'','',''),(4,0,0,0,5,128,1708348769,'Kontakt','kontakt',1,'main','',NULL,'','',NULL,'','',''),(5,0,0,1,6,128,1708348782,'Profil','profil',1,'main','',NULL,'','',NULL,'','',''),(6,0,0,1,7,128,1708348788,'Karriere','karriere',1,'main','',NULL,'','',NULL,'','','');
/*!40000 ALTER TABLE `tl_article` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tl_content`
--

DROP TABLE IF EXISTS `tl_content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tl_content` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL DEFAULT 'text',
  `addImage` tinyint(1) NOT NULL DEFAULT 0,
  `showPreview` tinyint(1) NOT NULL DEFAULT 0,
  `inline` tinyint(1) NOT NULL DEFAULT 0,
  `overwriteMeta` tinyint(1) NOT NULL DEFAULT 0,
  `fullsize` tinyint(1) NOT NULL DEFAULT 0,
  `thead` tinyint(1) NOT NULL DEFAULT 0,
  `tfoot` tinyint(1) NOT NULL DEFAULT 0,
  `tleft` tinyint(1) NOT NULL DEFAULT 0,
  `sortable` tinyint(1) NOT NULL DEFAULT 0,
  `closeSections` tinyint(1) NOT NULL DEFAULT 0,
  `target` tinyint(1) NOT NULL DEFAULT 0,
  `overwriteLink` tinyint(1) NOT NULL DEFAULT 0,
  `useImage` tinyint(1) NOT NULL DEFAULT 0,
  `useHomeDir` tinyint(1) NOT NULL DEFAULT 0,
  `metaIgnore` tinyint(1) NOT NULL DEFAULT 0,
  `splashImage` tinyint(1) NOT NULL DEFAULT 0,
  `sliderContinuous` tinyint(1) NOT NULL DEFAULT 0,
  `protected` tinyint(1) NOT NULL DEFAULT 0,
  `invisible` tinyint(1) NOT NULL DEFAULT 0,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `ptable` varchar(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL DEFAULT 'tl_article',
  `sorting` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `headline` varchar(255) NOT NULL DEFAULT 'a:2:{s:5:"value";s:0:"";s:4:"unit";s:2:"h2";}',
  `sectionHeadline` varchar(255) NOT NULL DEFAULT 'a:2:{s:5:"value";s:0:"";s:4:"unit";s:2:"h2";}',
  `text` mediumtext DEFAULT NULL,
  `singleSRC` binary(16) DEFAULT NULL,
  `alt` varchar(255) NOT NULL DEFAULT '',
  `imageTitle` varchar(255) NOT NULL DEFAULT '',
  `size` varchar(128) CHARACTER SET ascii COLLATE ascii_bin NOT NULL DEFAULT '',
  `imageUrl` text DEFAULT NULL,
  `caption` varchar(255) NOT NULL DEFAULT '',
  `floating` varchar(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL DEFAULT 'above',
  `html` mediumtext DEFAULT NULL,
  `unfilteredHtml` mediumtext DEFAULT NULL,
  `listtype` varchar(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL DEFAULT '',
  `listitems` blob DEFAULT NULL,
  `tableitems` mediumblob DEFAULT NULL,
  `summary` varchar(255) NOT NULL DEFAULT '',
  `sortIndex` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sortOrder` varchar(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL DEFAULT 'ascending',
  `mooHeadline` varchar(255) NOT NULL DEFAULT '',
  `mooStyle` varchar(255) NOT NULL DEFAULT '',
  `mooClasses` varchar(255) NOT NULL DEFAULT '',
  `highlight` varchar(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL DEFAULT '',
  `markdownSource` varchar(12) CHARACTER SET ascii COLLATE ascii_bin NOT NULL DEFAULT 'sourceText',
  `code` text DEFAULT NULL,
  `url` text DEFAULT NULL,
  `titleText` varchar(255) NOT NULL DEFAULT '',
  `linkTitle` varchar(255) NOT NULL DEFAULT '',
  `embed` varchar(255) NOT NULL DEFAULT '',
  `rel` varchar(64) NOT NULL DEFAULT '',
  `multiSRC` blob DEFAULT NULL,
  `perRow` smallint(5) unsigned NOT NULL DEFAULT 4,
  `perPage` smallint(5) unsigned NOT NULL DEFAULT 0,
  `numberOfItems` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sortBy` varchar(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL DEFAULT '',
  `galleryTpl` varchar(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL DEFAULT '',
  `customTpl` varchar(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL DEFAULT '',
  `playerSRC` blob DEFAULT NULL,
  `youtube` varchar(16) CHARACTER SET ascii COLLATE ascii_bin NOT NULL DEFAULT '',
  `vimeo` varchar(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL DEFAULT '',
  `posterSRC` binary(16) DEFAULT NULL,
  `playerSize` varchar(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL DEFAULT '',
  `playerOptions` text DEFAULT NULL,
  `playerStart` int(10) unsigned NOT NULL DEFAULT 0,
  `playerStop` int(10) unsigned NOT NULL DEFAULT 0,
  `playerCaption` varchar(255) NOT NULL DEFAULT '',
  `playerAspect` varchar(8) CHARACTER SET ascii COLLATE ascii_bin NOT NULL DEFAULT '',
  `playerPreload` varchar(8) CHARACTER SET ascii COLLATE ascii_bin NOT NULL DEFAULT '',
  `playerColor` varchar(6) CHARACTER SET ascii COLLATE ascii_bin NOT NULL DEFAULT '',
  `youtubeOptions` text DEFAULT NULL,
  `vimeoOptions` text DEFAULT NULL,
  `sliderDelay` int(10) unsigned NOT NULL DEFAULT 0,
  `sliderSpeed` int(10) unsigned NOT NULL DEFAULT 300,
  `sliderStartSlide` smallint(5) unsigned NOT NULL DEFAULT 0,
  `data` text DEFAULT NULL,
  `cteAlias` int(10) unsigned NOT NULL DEFAULT 0,
  `articleAlias` int(10) unsigned NOT NULL DEFAULT 0,
  `article` int(10) unsigned NOT NULL DEFAULT 0,
  `form` int(10) unsigned NOT NULL DEFAULT 0,
  `module` int(10) unsigned NOT NULL DEFAULT 0,
  `groups` blob DEFAULT NULL,
  `cssID` varchar(255) NOT NULL DEFAULT '',
  `start` varchar(10) CHARACTER SET ascii COLLATE ascii_bin NOT NULL DEFAULT '',
  `stop` varchar(10) CHARACTER SET ascii COLLATE ascii_bin NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `tstamp` (`tstamp`),
  KEY `ptable_pid_invisible_start_stop` (`ptable`,`pid`,`invisible`,`start`,`stop`),
  KEY `type` (`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tl_content`
--

LOCK TABLES `tl_content` WRITE;
/*!40000 ALTER TABLE `tl_content` DISABLE KEYS */;
/*!40000 ALTER TABLE `tl_content` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tl_crawl_queue`
--

DROP TABLE IF EXISTS `tl_crawl_queue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tl_crawl_queue` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `job_id` char(128) NOT NULL,
  `uri` longtext NOT NULL,
  `uri_hash` char(40) NOT NULL,
  `found_on` longtext DEFAULT NULL,
  `level` smallint(6) NOT NULL,
  `processed` tinyint(1) NOT NULL,
  `tags` longtext DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `job_id` (`job_id`),
  KEY `uri_hash` (`uri_hash`),
  KEY `processed` (`processed`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tl_crawl_queue`
--

LOCK TABLES `tl_crawl_queue` WRITE;
/*!40000 ALTER TABLE `tl_crawl_queue` DISABLE KEYS */;
/*!40000 ALTER TABLE `tl_crawl_queue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tl_cron_job`
--

DROP TABLE IF EXISTS `tl_cron_job`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tl_cron_job` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `lastRun` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tl_cron_job`
--

LOCK TABLES `tl_cron_job` WRITE;
/*!40000 ALTER TABLE `tl_cron_job` DISABLE KEYS */;
INSERT INTO `tl_cron_job` VALUES (1,'Contao\\CoreBundle\\Cron\\Cron::updateMinutelyCliCron','2024-02-19 14:15:38'),(2,'Contao\\CoreBundle\\Cron\\SuperviseWorkersCron','2024-02-19 14:15:38'),(3,'Contao\\CoreBundle\\Cron\\PurgeExpiredDataCron::onHourly','2024-02-19 14:15:38'),(4,'Contao\\CoreBundle\\Cron\\PurgeOptInTokensCron','2024-02-19 14:15:38'),(5,'Contao\\CoreBundle\\Cron\\PurgePreviewLinksCron','2024-02-19 14:15:38'),(6,'Contao\\CoreBundle\\Cron\\PurgeRegistrationsCron','2024-02-19 14:15:38'),(7,'Contao\\CoreBundle\\Cron\\PurgeTempFolderCron','2024-02-19 14:15:38');
/*!40000 ALTER TABLE `tl_cron_job` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tl_favorites`
--

DROP TABLE IF EXISTS `tl_favorites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tl_favorites` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `user` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `url` varchar(1022) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `tstamp` (`tstamp`),
  KEY `pid_user` (`pid`,`user`),
  KEY `url` (`url`(768))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tl_favorites`
--

LOCK TABLES `tl_favorites` WRITE;
/*!40000 ALTER TABLE `tl_favorites` DISABLE KEYS */;
INSERT INTO `tl_favorites` VALUES (1,0,128,1708348919,1,'Hauptnavigation','/contao?act=edit&do=themes&id=1&table=tl_module');
/*!40000 ALTER TABLE `tl_favorites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tl_files`
--

DROP TABLE IF EXISTS `tl_files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tl_files` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `found` tinyint(1) NOT NULL DEFAULT 1,
  `pid` binary(16) DEFAULT NULL,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `uuid` binary(16) DEFAULT NULL,
  `type` varchar(16) NOT NULL DEFAULT '',
  `path` varchar(1022) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `extension` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `hash` varchar(32) NOT NULL DEFAULT '',
  `lastModified` int(10) unsigned DEFAULT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `importantPartX` double unsigned NOT NULL DEFAULT 0,
  `importantPartY` double unsigned NOT NULL DEFAULT 0,
  `importantPartWidth` double unsigned NOT NULL DEFAULT 0,
  `importantPartHeight` double unsigned NOT NULL DEFAULT 0,
  `meta` blob DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uuid` (`uuid`),
  KEY `pid` (`pid`),
  KEY `tstamp` (`tstamp`),
  KEY `path` (`path`(768)),
  KEY `extension` (`extension`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tl_files`
--

LOCK TABLES `tl_files` WRITE;
/*!40000 ALTER TABLE `tl_files` DISABLE KEYS */;
/*!40000 ALTER TABLE `tl_files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tl_form`
--

DROP TABLE IF EXISTS `tl_form`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tl_form` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `sendViaEmail` tinyint(1) NOT NULL DEFAULT 0,
  `skipEmpty` tinyint(1) NOT NULL DEFAULT 0,
  `storeValues` tinyint(1) NOT NULL DEFAULT 0,
  `novalidate` tinyint(1) NOT NULL DEFAULT 0,
  `ajax` tinyint(1) NOT NULL DEFAULT 0,
  `allowTags` tinyint(1) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `jumpTo` int(10) unsigned NOT NULL DEFAULT 0,
  `confirmation` text DEFAULT NULL,
  `mailerTransport` varchar(255) NOT NULL DEFAULT '',
  `recipient` varchar(1022) NOT NULL DEFAULT '',
  `subject` varchar(255) NOT NULL DEFAULT '',
  `format` varchar(12) NOT NULL DEFAULT 'raw',
  `targetTable` varchar(64) NOT NULL DEFAULT '',
  `customTpl` varchar(64) NOT NULL DEFAULT '',
  `method` varchar(12) NOT NULL DEFAULT 'POST',
  `attributes` varchar(255) NOT NULL DEFAULT '',
  `formID` varchar(64) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `tstamp` (`tstamp`),
  KEY `alias` (`alias`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tl_form`
--

LOCK TABLES `tl_form` WRITE;
/*!40000 ALTER TABLE `tl_form` DISABLE KEYS */;
/*!40000 ALTER TABLE `tl_form` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tl_form_field`
--

DROP TABLE IF EXISTS `tl_form_field`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tl_form_field` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(64) NOT NULL DEFAULT 'text',
  `mandatory` tinyint(1) NOT NULL DEFAULT 0,
  `multiple` tinyint(1) NOT NULL DEFAULT 0,
  `storeFile` tinyint(1) NOT NULL DEFAULT 0,
  `useHomeDir` tinyint(1) NOT NULL DEFAULT 0,
  `doNotOverwrite` tinyint(1) NOT NULL DEFAULT 0,
  `imageSubmit` tinyint(1) NOT NULL DEFAULT 0,
  `invisible` tinyint(1) NOT NULL DEFAULT 0,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `label` varchar(255) NOT NULL DEFAULT '',
  `name` varchar(64) NOT NULL DEFAULT '',
  `text` text DEFAULT NULL,
  `html` text DEFAULT NULL,
  `options` blob DEFAULT NULL,
  `rgxp` varchar(32) NOT NULL DEFAULT '',
  `placeholder` varchar(255) NOT NULL DEFAULT '',
  `customRgxp` varchar(255) NOT NULL DEFAULT '',
  `errorMsg` varchar(255) NOT NULL DEFAULT '',
  `minlength` int(10) unsigned NOT NULL DEFAULT 0,
  `maxlength` int(10) unsigned NOT NULL DEFAULT 0,
  `maxImageWidth` int(10) unsigned NOT NULL DEFAULT 0,
  `maxImageHeight` int(10) unsigned NOT NULL DEFAULT 0,
  `minval` varchar(10) NOT NULL DEFAULT '',
  `maxval` varchar(10) NOT NULL DEFAULT '',
  `step` varchar(10) NOT NULL DEFAULT '',
  `size` varchar(255) NOT NULL DEFAULT 'a:2:{i:0;i:4;i:1;i:40;}',
  `mSize` smallint(5) unsigned NOT NULL DEFAULT 0,
  `extensions` varchar(255) NOT NULL DEFAULT 'jpg,jpeg,gif,png,pdf,doc,docx,xls,xlsx,ppt,pptx',
  `uploadFolder` binary(16) DEFAULT NULL,
  `class` varchar(255) NOT NULL DEFAULT '',
  `value` varchar(255) NOT NULL DEFAULT '',
  `accesskey` char(1) NOT NULL DEFAULT '',
  `fSize` smallint(5) unsigned NOT NULL DEFAULT 0,
  `customTpl` varchar(64) NOT NULL DEFAULT '',
  `slabel` varchar(255) NOT NULL DEFAULT '',
  `singleSRC` binary(16) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `pid_invisible` (`pid`,`invisible`),
  KEY `tstamp` (`tstamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tl_form_field`
--

LOCK TABLES `tl_form_field` WRITE;
/*!40000 ALTER TABLE `tl_form_field` DISABLE KEYS */;
/*!40000 ALTER TABLE `tl_form_field` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tl_image_size`
--

DROP TABLE IF EXISTS `tl_image_size`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tl_image_size` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `skipIfDimensionsMatch` tinyint(1) NOT NULL DEFAULT 0,
  `lazyLoading` tinyint(1) NOT NULL DEFAULT 0,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `name` varchar(64) DEFAULT NULL,
  `imageQuality` int(11) DEFAULT NULL,
  `cssClass` varchar(255) NOT NULL DEFAULT '',
  `densities` varchar(255) NOT NULL DEFAULT '',
  `sizes` varchar(255) NOT NULL DEFAULT '',
  `width` int(11) DEFAULT NULL,
  `height` int(11) DEFAULT NULL,
  `resizeMode` varchar(255) NOT NULL DEFAULT '',
  `zoom` int(11) DEFAULT NULL,
  `formats` varchar(1024) NOT NULL DEFAULT '',
  `preserveMetadata` varchar(12) NOT NULL DEFAULT 'default',
  `preserveMetadataFields` blob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `pid` (`pid`),
  KEY `tstamp` (`tstamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tl_image_size`
--

LOCK TABLES `tl_image_size` WRITE;
/*!40000 ALTER TABLE `tl_image_size` DISABLE KEYS */;
/*!40000 ALTER TABLE `tl_image_size` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tl_image_size_item`
--

DROP TABLE IF EXISTS `tl_image_size_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tl_image_size_item` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `invisible` tinyint(1) NOT NULL DEFAULT 0,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `media` varchar(255) NOT NULL DEFAULT '',
  `densities` varchar(255) NOT NULL DEFAULT '',
  `sizes` varchar(255) NOT NULL DEFAULT '',
  `width` int(11) DEFAULT NULL,
  `height` int(11) DEFAULT NULL,
  `resizeMode` varchar(255) NOT NULL DEFAULT '',
  `zoom` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `pid` (`pid`),
  KEY `tstamp` (`tstamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tl_image_size_item`
--

LOCK TABLES `tl_image_size_item` WRITE;
/*!40000 ALTER TABLE `tl_image_size_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `tl_image_size_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tl_layout`
--

DROP TABLE IF EXISTS `tl_layout`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tl_layout` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `combineScripts` tinyint(1) NOT NULL DEFAULT 1,
  `minifyMarkup` tinyint(1) NOT NULL DEFAULT 1,
  `addJQuery` tinyint(1) NOT NULL DEFAULT 0,
  `addMooTools` tinyint(1) NOT NULL DEFAULT 0,
  `static` tinyint(1) NOT NULL DEFAULT 0,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `name` varchar(255) NOT NULL DEFAULT '',
  `rows` varchar(8) NOT NULL DEFAULT '2rwh',
  `headerHeight` varchar(255) NOT NULL DEFAULT '',
  `footerHeight` varchar(255) NOT NULL DEFAULT '',
  `cols` varchar(8) NOT NULL DEFAULT '2cll',
  `widthLeft` varchar(255) NOT NULL DEFAULT '',
  `widthRight` varchar(255) NOT NULL DEFAULT '',
  `sections` blob DEFAULT NULL,
  `framework` varchar(255) NOT NULL DEFAULT 'a:2:{i:0;s:10:"layout.css";i:1;s:14:"responsive.css";}',
  `external` blob DEFAULT NULL,
  `modules` blob DEFAULT NULL,
  `template` varchar(64) NOT NULL DEFAULT '',
  `lightboxSize` varchar(255) NOT NULL DEFAULT '',
  `defaultImageDensities` varchar(255) NOT NULL DEFAULT '',
  `viewport` varchar(255) NOT NULL DEFAULT 'width=device-width,initial-scale=1.0,shrink-to-fit=no',
  `titleTag` varchar(255) NOT NULL DEFAULT '',
  `cssClass` varchar(255) NOT NULL DEFAULT '',
  `onload` varchar(255) NOT NULL DEFAULT '',
  `head` text DEFAULT NULL,
  `jquery` text DEFAULT NULL,
  `mootools` text DEFAULT NULL,
  `analytics` text DEFAULT NULL,
  `externalJs` blob DEFAULT NULL,
  `scripts` text DEFAULT NULL,
  `script` text DEFAULT NULL,
  `width` varchar(255) NOT NULL DEFAULT '',
  `align` varchar(32) NOT NULL DEFAULT 'center',
  PRIMARY KEY (`id`),
  KEY `tstamp` (`tstamp`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tl_layout`
--

LOCK TABLES `tl_layout` WRITE;
/*!40000 ALTER TABLE `tl_layout` DISABLE KEYS */;
INSERT INTO `tl_layout` VALUES (1,1,1,0,0,1,1,1708348801,'Standard','2rwh','a:2:{s:4:\"unit\";s:0:\"\";s:5:\"value\";s:0:\"\";}','','2cll','a:2:{s:4:\"unit\";s:0:\"\";s:5:\"value\";s:0:\"\";}','','a:1:{i:0;a:4:{s:5:\"title\";s:0:\"\";s:2:\"id\";s:0:\"\";s:8:\"template\";s:13:\"block_section\";s:8:\"position\";s:3:\"top\";}}','a:2:{i:0;s:10:\"layout.css\";i:1;s:14:\"responsive.css\";}',NULL,'a:2:{i:0;a:3:{s:3:\"mod\";s:1:\"1\";s:3:\"col\";s:6:\"header\";s:6:\"enable\";s:1:\"1\";}i:1;a:3:{s:3:\"mod\";s:1:\"0\";s:3:\"col\";s:4:\"main\";s:6:\"enable\";s:1:\"1\";}}','','a:3:{i:0;s:0:\"\";i:1;s:0:\"\";i:2;s:0:\"\";}','','width=device-width,initial-scale=1.0,shrink-to-fit=no','','','',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'a:2:{s:4:\"unit\";s:3:\"rem\";s:5:\"value\";s:2:\"80\";}','center');
/*!40000 ALTER TABLE `tl_layout` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tl_log`
--

DROP TABLE IF EXISTS `tl_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tl_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `source` varchar(32) NOT NULL DEFAULT '',
  `action` varchar(32) NOT NULL DEFAULT '',
  `username` varchar(64) NOT NULL DEFAULT '',
  `text` text DEFAULT NULL,
  `func` varchar(255) NOT NULL DEFAULT '',
  `browser` varchar(255) NOT NULL DEFAULT '',
  `uri` varchar(2048) NOT NULL DEFAULT '',
  `page` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `tstamp` (`tstamp`)
) ENGINE=InnoDB AUTO_INCREMENT=58 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tl_log`
--

LOCK TABLES `tl_log` WRITE;
/*!40000 ALTER TABLE `tl_log` DISABLE KEYS */;
INSERT INTO `tl_log` VALUES (1,1708348538,'FE','CRON','N/A','Purged the expired double opt-in tokens','Contao\\CoreBundle\\Cron\\PurgeOptInTokensCron::__invoke','N/A','',0),(2,1708348538,'FE','CRON','N/A','Purged the temp folder','Contao\\CoreBundle\\Cron\\PurgeTempFolderCron::__invoke','N/A','',0),(3,1708348611,'BE','ACCESS','admin','User &quot;admin&quot; has logged in','Contao\\CoreBundle\\Security\\Authentication\\AuthenticationSuccessHandler::onAuthenticationSuccess','Mozilla/5.0 (X11; Linux x86_64; rv:122.0) Gecko/20100101 Firefox/122.0','https://hofff-contao-navigation.ddev.site/contao/login?_hash=e6Xs8ubqaiaDnVak4melZmIewi87RK86p59GhetTGvc%3D&amp;redirect=https%3A%2F%2Fhofff-contao-navigation.ddev.site%2Fcontao',0),(4,1708348648,'BE','GENERAL','admin','A new entry &quot;tl_theme.id=1&quot; has been created','Contao\\DC_Table::create','Mozilla/5.0 (X11; Linux x86_64; rv:122.0) Gecko/20100101 Firefox/122.0','https://hofff-contao-navigation.ddev.site/contao?act=create&amp;do=themes&amp;ref=xlgcdeWh&amp;rt=81c5c1550fa0b0.TYPr9FSBbdaDV_jXnhvBsXqt9FrRQt9j-a8Bw-o6TSk.H7PcjA3nOoXvEq-P9Gr51EjIkQKkdeYQj-os7twDBhk32YKyPcMf79MuwA',0),(5,1708348657,'BE','GENERAL','admin','Version 1 of record &quot;tl_theme.id=1&quot; has been created','Contao\\Versions::create','Mozilla/5.0 (X11; Linux x86_64; rv:122.0) Gecko/20100101 Firefox/122.0','https://hofff-contao-navigation.ddev.site/contao?act=edit&amp;do=themes&amp;id=1&amp;ref=xlgcdeWh&amp;rt=81c5c1550fa0b0.TYPr9FSBbdaDV_jXnhvBsXqt9FrRQt9j-a8Bw-o6TSk.H7PcjA3nOoXvEq-P9Gr51EjIkQKkdeYQj-os7twDBhk32YKyPcMf79MuwA',0),(6,1708348666,'BE','GENERAL','admin','A new entry &quot;tl_theme.id=2&quot; has been created','Contao\\DC_Table::create','Mozilla/5.0 (X11; Linux x86_64; rv:122.0) Gecko/20100101 Firefox/122.0','https://hofff-contao-navigation.ddev.site/contao?act=create&amp;do=themes&amp;ref=DhNFA9Dm&amp;rt=69eac946d668a9d418b5508b90d6.-5x5URqITSiP4NBR9zZUc8vNg-S9sBEoWzvhZbxrO2Q.qaxOKUPuGnvjpYcJnUdsFvmo5rzIhyhbLX7MSIpScFSBxhAXc8o_Ed-Z6A',0),(7,1708348671,'BE','GENERAL','admin','A new entry &quot;tl_layout.id=1&quot; has been created (parent records: tl_theme.id=1)','Contao\\DC_Table::create','Mozilla/5.0 (X11; Linux x86_64; rv:122.0) Gecko/20100101 Firefox/122.0','https://hofff-contao-navigation.ddev.site/contao?act=create&amp;do=themes&amp;id=1&amp;mode=2&amp;pid=1&amp;ref=9eJHaw5M&amp;rt=cfed4badfd806726e7f7ab3.Vt6FsOrqe5CQXTu7TK1zjgBCe6o8qiEGMOkpqmNLJNg.BO6yyLOMLMP8GGzjJtxL6zInHvJJnRh1RqwEh1Vyb-gshOz2g6gJqcAkAw&amp;table=tl_layout',0),(8,1708348679,'BE','GENERAL','admin','Version 1 of record &quot;tl_layout.id=1&quot; has been created (parent records: tl_theme.id=1)','Contao\\Versions::create','Mozilla/5.0 (X11; Linux x86_64; rv:122.0) Gecko/20100101 Firefox/122.0','https://hofff-contao-navigation.ddev.site/contao?act=edit&amp;do=themes&amp;id=1&amp;ref=9eJHaw5M&amp;rt=cfed4badfd806726e7f7ab3.Vt6FsOrqe5CQXTu7TK1zjgBCe6o8qiEGMOkpqmNLJNg.BO6yyLOMLMP8GGzjJtxL6zInHvJJnRh1RqwEh1Vyb-gshOz2g6gJqcAkAw&amp;table=tl_layout',0),(9,1708348687,'BE','GENERAL','admin','Version 2 of record &quot;tl_layout.id=1&quot; has been created (parent records: tl_theme.id=1)','Contao\\Versions::create','Mozilla/5.0 (X11; Linux x86_64; rv:122.0) Gecko/20100101 Firefox/122.0','https://hofff-contao-navigation.ddev.site/contao?act=edit&amp;do=themes&amp;id=1&amp;ref=9eJHaw5M&amp;rt=cfed4badfd806726e7f7ab3.Vt6FsOrqe5CQXTu7TK1zjgBCe6o8qiEGMOkpqmNLJNg.BO6yyLOMLMP8GGzjJtxL6zInHvJJnRh1RqwEh1Vyb-gshOz2g6gJqcAkAw&amp;table=tl_layout',0),(10,1708348702,'BE','GENERAL','admin','A new entry &quot;tl_module.id=1&quot; has been created (parent records: tl_theme.id=1)','Contao\\DC_Table::create','Mozilla/5.0 (X11; Linux x86_64; rv:122.0) Gecko/20100101 Firefox/122.0','https://hofff-contao-navigation.ddev.site/contao?act=create&amp;do=themes&amp;id=1&amp;mode=2&amp;pid=1&amp;ref=0V0Mymdq&amp;rt=ac1fdd466d8cfede7b.MYxoBaLTmxHqWCWrrpwbTIiaBataDmtt9LyuJegJsfc.Y7xfffu1zEKGHXLzxO0jKbr_YPMvOVIegvmDCN4w-sdL1gFDy5HpKLohHQ&amp;table=tl_module',0),(11,1708348711,'BE','GENERAL','admin','Version 1 of record &quot;tl_module.id=1&quot; has been created (parent records: tl_theme.id=1)','Contao\\Versions::create','Mozilla/5.0 (X11; Linux x86_64; rv:122.0) Gecko/20100101 Firefox/122.0','https://hofff-contao-navigation.ddev.site/contao?act=edit&amp;do=themes&amp;id=1&amp;ref=0V0Mymdq&amp;rt=ac1fdd466d8cfede7b.MYxoBaLTmxHqWCWrrpwbTIiaBataDmtt9LyuJegJsfc.Y7xfffu1zEKGHXLzxO0jKbr_YPMvOVIegvmDCN4w-sdL1gFDy5HpKLohHQ&amp;table=tl_module',0),(12,1708348716,'BE','GENERAL','admin','Version 2 of record &quot;tl_module.id=1&quot; has been created (parent records: tl_theme.id=1)','Contao\\Versions::create','Mozilla/5.0 (X11; Linux x86_64; rv:122.0) Gecko/20100101 Firefox/122.0','https://hofff-contao-navigation.ddev.site/contao?act=edit&amp;do=themes&amp;id=1&amp;ref=0V0Mymdq&amp;rt=ac1fdd466d8cfede7b.MYxoBaLTmxHqWCWrrpwbTIiaBataDmtt9LyuJegJsfc.Y7xfffu1zEKGHXLzxO0jKbr_YPMvOVIegvmDCN4w-sdL1gFDy5HpKLohHQ&amp;table=tl_module',0),(13,1708348724,'BE','GENERAL','admin','A new entry &quot;tl_page.id=1&quot; has been created','Contao\\DC_Table::create','Mozilla/5.0 (X11; Linux x86_64; rv:122.0) Gecko/20100101 Firefox/122.0','https://hofff-contao-navigation.ddev.site/contao?act=create&amp;do=page&amp;id=&amp;mode=2&amp;pid=0&amp;ref=KGZujXRF&amp;rt=7f59362768dac0ff0d6ed0822f1b68e._ts23Rbzni--ZzIn4RMhFqrNhL_nrpyFZzEZQ0305lI.rOsBpU-VyXzSImV_i2IZc5io4eeSmaX2EXQ0bnvNrWKEgV-bf7HsFu4eCg',0),(14,1708348734,'BE','GENERAL','admin','Version 1 of record &quot;tl_page.id=1&quot; has been created','Contao\\Versions::create','Mozilla/5.0 (X11; Linux x86_64; rv:122.0) Gecko/20100101 Firefox/122.0','https://hofff-contao-navigation.ddev.site/contao?act=edit&amp;do=page&amp;id=1&amp;ref=KGZujXRF&amp;rt=7f59362768dac0ff0d6ed0822f1b68e._ts23Rbzni--ZzIn4RMhFqrNhL_nrpyFZzEZQ0305lI.rOsBpU-VyXzSImV_i2IZc5io4eeSmaX2EXQ0bnvNrWKEgV-bf7HsFu4eCg',0),(15,1708348737,'BE','GENERAL','admin','Version 2 of record &quot;tl_page.id=1&quot; has been created','Contao\\Versions::create','Mozilla/5.0 (X11; Linux x86_64; rv:122.0) Gecko/20100101 Firefox/122.0','https://hofff-contao-navigation.ddev.site/contao?act=edit&amp;do=page&amp;id=1&amp;ref=KGZujXRF&amp;rt=7f59362768dac0ff0d6ed0822f1b68e._ts23Rbzni--ZzIn4RMhFqrNhL_nrpyFZzEZQ0305lI.rOsBpU-VyXzSImV_i2IZc5io4eeSmaX2EXQ0bnvNrWKEgV-bf7HsFu4eCg',0),(16,1708348740,'BE','GENERAL','admin','Version 3 of record &quot;tl_page.id=1&quot; has been created','Contao\\Versions::create','Mozilla/5.0 (X11; Linux x86_64; rv:122.0) Gecko/20100101 Firefox/122.0','https://hofff-contao-navigation.ddev.site/contao?act=edit&amp;do=page&amp;id=1&amp;ref=KGZujXRF&amp;rt=7f59362768dac0ff0d6ed0822f1b68e._ts23Rbzni--ZzIn4RMhFqrNhL_nrpyFZzEZQ0305lI.rOsBpU-VyXzSImV_i2IZc5io4eeSmaX2EXQ0bnvNrWKEgV-bf7HsFu4eCg',0),(17,1708348747,'BE','GENERAL','admin','A new entry &quot;tl_page.id=2&quot; has been created','Contao\\DC_Table::create','Mozilla/5.0 (X11; Linux x86_64; rv:122.0) Gecko/20100101 Firefox/122.0','https://hofff-contao-navigation.ddev.site/contao?act=create&amp;do=page&amp;id=&amp;mode=2&amp;pid=1&amp;ref=kp8mtcYS&amp;rt=5c3e03b92814d11b68ea3edd34.uXuZS6Ul-kTqCV7OMNc9xnwIKNcTjCnD6rUK-pF8IK8.60uuM_xDrReGTAmWWqYFo05tTY9muxCwnPAn16dFa5_DIfANzGeIfbpwZg',0),(18,1708348752,'BE','GENERAL','admin','Version 1 of record &quot;tl_page.id=2&quot; has been created','Contao\\Versions::create','Mozilla/5.0 (X11; Linux x86_64; rv:122.0) Gecko/20100101 Firefox/122.0','https://hofff-contao-navigation.ddev.site/contao?act=edit&amp;do=page&amp;id=2&amp;ref=kp8mtcYS&amp;rt=5c3e03b92814d11b68ea3edd34.uXuZS6Ul-kTqCV7OMNc9xnwIKNcTjCnD6rUK-pF8IK8.60uuM_xDrReGTAmWWqYFo05tTY9muxCwnPAn16dFa5_DIfANzGeIfbpwZg',0),(19,1708348753,'BE','GENERAL','admin','A new entry &quot;tl_page.id=3&quot; has been created','Contao\\DC_Table::create','Mozilla/5.0 (X11; Linux x86_64; rv:122.0) Gecko/20100101 Firefox/122.0','https://hofff-contao-navigation.ddev.site/contao?act=create&amp;do=page&amp;mode=1&amp;pid=2&amp;rt=80d87.RBWL4hLtSQpV8ZE_dHutY86yyDfkks7Bc-izVeVHhBc.FiW8mkuLHlk5tMZnHgqVBvzXrW-RpfeyBa2eeNN-zyc-T-Kke687MwWIqQ',0),(20,1708348760,'BE','GENERAL','admin','Version 1 of record &quot;tl_page.id=3&quot; has been created','Contao\\Versions::create','Mozilla/5.0 (X11; Linux x86_64; rv:122.0) Gecko/20100101 Firefox/122.0','https://hofff-contao-navigation.ddev.site/contao?act=edit&amp;do=page&amp;id=3&amp;rt=80d87.RBWL4hLtSQpV8ZE_dHutY86yyDfkks7Bc-izVeVHhBc.FiW8mkuLHlk5tMZnHgqVBvzXrW-RpfeyBa2eeNN-zyc-T-Kke687MwWIqQ',0),(21,1708348760,'BE','GENERAL','admin','A new entry &quot;tl_page.id=4&quot; has been created','Contao\\DC_Table::create','Mozilla/5.0 (X11; Linux x86_64; rv:122.0) Gecko/20100101 Firefox/122.0','https://hofff-contao-navigation.ddev.site/contao?act=create&amp;do=page&amp;mode=1&amp;pid=3&amp;rt=5f79bad551a6.S2j8oQ6cmDU7_P4AHktPeAPDY9cFvA8P2IpEzTm-4N0.GVjL2Vf6z2ZXualYdDp3HTGmBo9wizZ8rs9p4A-Hq-0xMpXnZ97qDGuFxg',0),(22,1708348765,'BE','GENERAL','admin','Version 1 of record &quot;tl_page.id=4&quot; has been created','Contao\\Versions::create','Mozilla/5.0 (X11; Linux x86_64; rv:122.0) Gecko/20100101 Firefox/122.0','https://hofff-contao-navigation.ddev.site/contao?act=edit&amp;do=page&amp;id=4&amp;rt=5f79bad551a6.S2j8oQ6cmDU7_P4AHktPeAPDY9cFvA8P2IpEzTm-4N0.GVjL2Vf6z2ZXualYdDp3HTGmBo9wizZ8rs9p4A-Hq-0xMpXnZ97qDGuFxg',0),(23,1708348765,'BE','GENERAL','admin','A new entry &quot;tl_page.id=5&quot; has been created','Contao\\DC_Table::create','Mozilla/5.0 (X11; Linux x86_64; rv:122.0) Gecko/20100101 Firefox/122.0','https://hofff-contao-navigation.ddev.site/contao?act=create&amp;do=page&amp;mode=1&amp;pid=4&amp;rt=2eeb3fddfd0fb710d3934.NKEwmFlYhkbi8EIXkxtHJw80Ar3VfRvODdaRndR0L6s.ZpEH4AA-0RWOtRVP-Wp_Qj1RZ-WgSiK9e5O8sOJNZJtO-1neMBr0f7KJeg',0),(24,1708348769,'BE','GENERAL','admin','Version 1 of record &quot;tl_page.id=5&quot; has been created','Contao\\Versions::create','Mozilla/5.0 (X11; Linux x86_64; rv:122.0) Gecko/20100101 Firefox/122.0','https://hofff-contao-navigation.ddev.site/contao?act=edit&amp;do=page&amp;id=5&amp;rt=2eeb3fddfd0fb710d3934.NKEwmFlYhkbi8EIXkxtHJw80Ar3VfRvODdaRndR0L6s.ZpEH4AA-0RWOtRVP-Wp_Qj1RZ-WgSiK9e5O8sOJNZJtO-1neMBr0f7KJeg',0),(25,1708348773,'BE','GENERAL','admin','Version 2 of record &quot;tl_page.id=5&quot; has been created','Contao\\Versions::create','Mozilla/5.0 (X11; Linux x86_64; rv:122.0) Gecko/20100101 Firefox/122.0','https://hofff-contao-navigation.ddev.site/contao?act=toggle&amp;do=page&amp;field=published&amp;id=5&amp;ref=ZpvQHZra&amp;rt=86f5.40V0O9Dq-lvpOWghj3tt33zvmdHyP2B7rJ5zksX7lVo.sXVDQ4mMrQiFfD955QpVuk6K_ImHCFkI2ttev_PC3mqZHx19uaiIYrlAUA',0),(26,1708348777,'BE','GENERAL','admin','A new entry &quot;tl_page.id=6&quot; has been created','Contao\\DC_Table::create','Mozilla/5.0 (X11; Linux x86_64; rv:122.0) Gecko/20100101 Firefox/122.0','https://hofff-contao-navigation.ddev.site/contao?act=create&amp;do=page&amp;id=&amp;mode=2&amp;pid=3&amp;ref=J4nlb3tV&amp;rt=cc0f440060b.SlVsiFsPx6yzNi5xC6i88YUMxAQR5WtnNlXAUpGiJNg.GGVb8AJpkP_fc3kpYdmElLdpoVxk0lIUQBDtf6ebb-gwDwXOMk21leNPFg',0),(27,1708348782,'BE','GENERAL','admin','Version 1 of record &quot;tl_page.id=6&quot; has been created','Contao\\Versions::create','Mozilla/5.0 (X11; Linux x86_64; rv:122.0) Gecko/20100101 Firefox/122.0','https://hofff-contao-navigation.ddev.site/contao?act=edit&amp;do=page&amp;id=6&amp;ref=J4nlb3tV&amp;rt=cc0f440060b.SlVsiFsPx6yzNi5xC6i88YUMxAQR5WtnNlXAUpGiJNg.GGVb8AJpkP_fc3kpYdmElLdpoVxk0lIUQBDtf6ebb-gwDwXOMk21leNPFg',0),(28,1708348782,'BE','GENERAL','admin','A new entry &quot;tl_page.id=7&quot; has been created','Contao\\DC_Table::create','Mozilla/5.0 (X11; Linux x86_64; rv:122.0) Gecko/20100101 Firefox/122.0','https://hofff-contao-navigation.ddev.site/contao?act=create&amp;do=page&amp;mode=1&amp;pid=6&amp;rt=be9f2515.J_cgAj7iOjSqPtqSugLSWw4uJX9MTpfIF1nyn8HNA7s.dccXemeEbWfGe43K0HPqPjxLQCc5ea67YRzfsvf0SItdrUlEV6BIDfpH4g',0),(29,1708348788,'BE','GENERAL','admin','Version 1 of record &quot;tl_page.id=7&quot; has been created','Contao\\Versions::create','Mozilla/5.0 (X11; Linux x86_64; rv:122.0) Gecko/20100101 Firefox/122.0','https://hofff-contao-navigation.ddev.site/contao?act=edit&amp;do=page&amp;id=7&amp;rt=be9f2515.J_cgAj7iOjSqPtqSugLSWw4uJX9MTpfIF1nyn8HNA7s.dccXemeEbWfGe43K0HPqPjxLQCc5ea67YRzfsvf0SItdrUlEV6BIDfpH4g',0),(30,1708348801,'BE','GENERAL','admin','Version 3 of record &quot;tl_layout.id=1&quot; has been created (parent records: tl_theme.id=1)','Contao\\Versions::create','Mozilla/5.0 (X11; Linux x86_64; rv:122.0) Gecko/20100101 Firefox/122.0','https://hofff-contao-navigation.ddev.site/contao?act=edit&amp;do=themes&amp;id=1&amp;ref=at7DJW3i&amp;rt=f867d31e1490a3f3d3afabdb9bf8.W1ChuNguwz7zsPczmrEdyr0e9B4izmvuiZqG2zuy4fU.CWCWwIFIlG2f9aBr8MAlr497kUZX-VKd_9-r9g2LqsUhCsj-sWyxB6PJzw&amp;table=tl_layout',0),(31,1708348910,'BE','GENERAL','admin','A new entry &quot;tl_favorites.id=1&quot; has been created','Contao\\DC_Table::create','Mozilla/5.0 (X11; Linux x86_64; rv:122.0) Gecko/20100101 Firefox/122.0','https://hofff-contao-navigation.ddev.site/contao?act=create&amp;data=L2NvbnRhbz9hY3Q9ZWRpdCZkbz10aGVtZXMmaWQ9MSZ0YWJsZT10bF9tb2R1bGU%3D&amp;do=favorites&amp;id=&amp;mode=2&amp;pid=0&amp;ref=2pPwwf2H&amp;rt=09d40b1fc7dfdfdbe1815704eb00.O1dFmSIVoEBPPizBBK9zpqxjS_v4P4InBUmPMqh7PLM.aWdy4Xtz9xMje3uZbt5Lw54GLqONCLtUcwyiH55Cd4NBDSzfS1fSeR9HFA',0),(32,1708348919,'BE','GENERAL','admin','Version 1 of record &quot;tl_favorites.id=1&quot; has been created','Contao\\Versions::create','Mozilla/5.0 (X11; Linux x86_64; rv:122.0) Gecko/20100101 Firefox/122.0','https://hofff-contao-navigation.ddev.site/contao?act=edit&amp;do=favorites&amp;id=1&amp;ref=2pPwwf2H&amp;rt=09d40b1fc7dfdfdbe1815704eb00.O1dFmSIVoEBPPizBBK9zpqxjS_v4P4InBUmPMqh7PLM.aWdy4Xtz9xMje3uZbt5Lw54GLqONCLtUcwyiH55Cd4NBDSzfS1fSeR9HFA',0),(33,1708348925,'BE','GENERAL','admin','Version 3 of record &quot;tl_module.id=1&quot; has been created (parent records: tl_theme.id=1)','Contao\\Versions::create','Mozilla/5.0 (X11; Linux x86_64; rv:122.0) Gecko/20100101 Firefox/122.0','https://hofff-contao-navigation.ddev.site/contao?act=edit&amp;do=themes&amp;id=1&amp;ref=YD-wtk58&amp;table=tl_module',0),(34,1708348926,'BE','GENERAL','admin','Version 4 of record &quot;tl_module.id=1&quot; has been created (parent records: tl_theme.id=1)','Contao\\Versions::create','Mozilla/5.0 (X11; Linux x86_64; rv:122.0) Gecko/20100101 Firefox/122.0','https://hofff-contao-navigation.ddev.site/contao?act=edit&amp;do=themes&amp;id=1&amp;ref=YD-wtk58&amp;table=tl_module',0),(35,1708348927,'BE','GENERAL','admin','Version 5 of record &quot;tl_module.id=1&quot; has been created (parent records: tl_theme.id=1)','Contao\\Versions::create','Mozilla/5.0 (X11; Linux x86_64; rv:122.0) Gecko/20100101 Firefox/122.0','https://hofff-contao-navigation.ddev.site/contao?act=edit&amp;do=themes&amp;id=1&amp;ref=YD-wtk58&amp;table=tl_module',0),(36,1708348927,'BE','GENERAL','admin','Version 6 of record &quot;tl_module.id=1&quot; has been created (parent records: tl_theme.id=1)','Contao\\Versions::create','Mozilla/5.0 (X11; Linux x86_64; rv:122.0) Gecko/20100101 Firefox/122.0','https://hofff-contao-navigation.ddev.site/contao?act=edit&amp;do=themes&amp;id=1&amp;ref=YD-wtk58&amp;table=tl_module',0),(37,1708348928,'BE','GENERAL','admin','Version 7 of record &quot;tl_module.id=1&quot; has been created (parent records: tl_theme.id=1)','Contao\\Versions::create','Mozilla/5.0 (X11; Linux x86_64; rv:122.0) Gecko/20100101 Firefox/122.0','https://hofff-contao-navigation.ddev.site/contao?act=edit&amp;do=themes&amp;id=1&amp;ref=YD-wtk58&amp;table=tl_module',0),(38,1708348930,'BE','GENERAL','admin','Version 8 of record &quot;tl_module.id=1&quot; has been created (parent records: tl_theme.id=1)','Contao\\Versions::create','Mozilla/5.0 (X11; Linux x86_64; rv:122.0) Gecko/20100101 Firefox/122.0','https://hofff-contao-navigation.ddev.site/contao?act=edit&amp;do=themes&amp;id=1&amp;ref=YD-wtk58&amp;table=tl_module',0),(39,1708348938,'BE','GENERAL','admin','Version 9 of record &quot;tl_module.id=1&quot; has been created (parent records: tl_theme.id=1)','Contao\\Versions::create','Mozilla/5.0 (X11; Linux x86_64; rv:122.0) Gecko/20100101 Firefox/122.0','https://hofff-contao-navigation.ddev.site/contao?act=edit&amp;do=themes&amp;id=1&amp;ref=YD-wtk58&amp;table=tl_module',0),(40,1708348951,'BE','GENERAL','admin','Version 10 of record &quot;tl_module.id=1&quot; has been created (parent records: tl_theme.id=1)','Contao\\Versions::create','Mozilla/5.0 (X11; Linux x86_64; rv:122.0) Gecko/20100101 Firefox/122.0','https://hofff-contao-navigation.ddev.site/contao?act=edit&amp;do=themes&amp;id=1&amp;ref=YD-wtk58&amp;table=tl_module',0),(41,1708348952,'BE','GENERAL','admin','Version 11 of record &quot;tl_module.id=1&quot; has been created (parent records: tl_theme.id=1)','Contao\\Versions::create','Mozilla/5.0 (X11; Linux x86_64; rv:122.0) Gecko/20100101 Firefox/122.0','https://hofff-contao-navigation.ddev.site/contao?act=edit&amp;do=themes&amp;id=1&amp;ref=YD-wtk58&amp;table=tl_module',0),(42,1708348954,'BE','GENERAL','admin','Version 12 of record &quot;tl_module.id=1&quot; has been created (parent records: tl_theme.id=1)','Contao\\Versions::create','Mozilla/5.0 (X11; Linux x86_64; rv:122.0) Gecko/20100101 Firefox/122.0','https://hofff-contao-navigation.ddev.site/contao?act=edit&amp;do=themes&amp;id=1&amp;ref=YD-wtk58&amp;table=tl_module',0),(43,1708348955,'BE','GENERAL','admin','Version 13 of record &quot;tl_module.id=1&quot; has been created (parent records: tl_theme.id=1)','Contao\\Versions::create','Mozilla/5.0 (X11; Linux x86_64; rv:122.0) Gecko/20100101 Firefox/122.0','https://hofff-contao-navigation.ddev.site/contao?act=edit&amp;do=themes&amp;id=1&amp;ref=YD-wtk58&amp;table=tl_module',0),(44,1708349066,'BE','GENERAL','admin','Version 14 of record &quot;tl_module.id=1&quot; has been created (parent records: tl_theme.id=1)','Contao\\Versions::create','Mozilla/5.0 (X11; Linux x86_64; rv:122.0) Gecko/20100101 Firefox/122.0','https://hofff-contao-navigation.ddev.site/contao?act=edit&amp;do=themes&amp;id=1&amp;ref=YD-wtk58&amp;table=tl_module',0),(45,1708349209,'BE','GENERAL','admin','Version 15 of record &quot;tl_module.id=1&quot; has been created (parent records: tl_theme.id=1)','Contao\\Versions::create','Mozilla/5.0 (X11; Linux x86_64; rv:122.0) Gecko/20100101 Firefox/122.0','https://hofff-contao-navigation.ddev.site/contao?act=edit&amp;do=themes&amp;id=1&amp;ref=YD-wtk58&amp;table=tl_module',0),(46,1708349215,'BE','GENERAL','admin','Version 16 of record &quot;tl_module.id=1&quot; has been created (parent records: tl_theme.id=1)','Contao\\Versions::create','Mozilla/5.0 (X11; Linux x86_64; rv:122.0) Gecko/20100101 Firefox/122.0','https://hofff-contao-navigation.ddev.site/contao?act=edit&amp;do=themes&amp;id=1&amp;ref=YD-wtk58&amp;table=tl_module',0),(47,1708349216,'BE','GENERAL','admin','Version 17 of record &quot;tl_module.id=1&quot; has been created (parent records: tl_theme.id=1)','Contao\\Versions::create','Mozilla/5.0 (X11; Linux x86_64; rv:122.0) Gecko/20100101 Firefox/122.0','https://hofff-contao-navigation.ddev.site/contao?act=edit&amp;do=themes&amp;id=1&amp;ref=YD-wtk58&amp;table=tl_module',0),(48,1708349222,'BE','GENERAL','admin','Version 18 of record &quot;tl_module.id=1&quot; has been created (parent records: tl_theme.id=1)','Contao\\Versions::create','Mozilla/5.0 (X11; Linux x86_64; rv:122.0) Gecko/20100101 Firefox/122.0','https://hofff-contao-navigation.ddev.site/contao?act=edit&amp;do=themes&amp;id=1&amp;ref=YD-wtk58&amp;table=tl_module',0),(49,1708349230,'BE','GENERAL','admin','Version 19 of record &quot;tl_module.id=1&quot; has been created (parent records: tl_theme.id=1)','Contao\\Versions::create','Mozilla/5.0 (X11; Linux x86_64; rv:122.0) Gecko/20100101 Firefox/122.0','https://hofff-contao-navigation.ddev.site/contao?act=edit&amp;do=themes&amp;id=1&amp;ref=YD-wtk58&amp;table=tl_module',0),(50,1708349239,'BE','GENERAL','admin','Version 20 of record &quot;tl_module.id=1&quot; has been created (parent records: tl_theme.id=1)','Contao\\Versions::create','Mozilla/5.0 (X11; Linux x86_64; rv:122.0) Gecko/20100101 Firefox/122.0','https://hofff-contao-navigation.ddev.site/contao?act=edit&amp;do=themes&amp;id=1&amp;ref=YD-wtk58&amp;table=tl_module',0),(51,1708349251,'BE','GENERAL','admin','Version 21 of record &quot;tl_module.id=1&quot; has been created (parent records: tl_theme.id=1)','Contao\\Versions::create','Mozilla/5.0 (X11; Linux x86_64; rv:122.0) Gecko/20100101 Firefox/122.0','https://hofff-contao-navigation.ddev.site/contao?act=edit&amp;do=themes&amp;id=1&amp;ref=YD-wtk58&amp;table=tl_module',0),(52,1708349258,'BE','GENERAL','admin','Version 22 of record &quot;tl_module.id=1&quot; has been created (parent records: tl_theme.id=1)','Contao\\Versions::create','Mozilla/5.0 (X11; Linux x86_64; rv:122.0) Gecko/20100101 Firefox/122.0','https://hofff-contao-navigation.ddev.site/contao?act=edit&amp;do=themes&amp;id=1&amp;ref=YD-wtk58&amp;table=tl_module',0),(53,1708349260,'BE','GENERAL','admin','Version 23 of record &quot;tl_module.id=1&quot; has been created (parent records: tl_theme.id=1)','Contao\\Versions::create','Mozilla/5.0 (X11; Linux x86_64; rv:122.0) Gecko/20100101 Firefox/122.0','https://hofff-contao-navigation.ddev.site/contao?act=edit&amp;do=themes&amp;id=1&amp;ref=YD-wtk58&amp;table=tl_module',0),(54,1708349268,'BE','GENERAL','admin','Version 24 of record &quot;tl_module.id=1&quot; has been created (parent records: tl_theme.id=1)','Contao\\Versions::create','Mozilla/5.0 (X11; Linux x86_64; rv:122.0) Gecko/20100101 Firefox/122.0','https://hofff-contao-navigation.ddev.site/contao?act=edit&amp;do=themes&amp;id=1&amp;ref=YD-wtk58&amp;table=tl_module',0),(55,1708349269,'BE','GENERAL','admin','Version 25 of record &quot;tl_module.id=1&quot; has been created (parent records: tl_theme.id=1)','Contao\\Versions::create','Mozilla/5.0 (X11; Linux x86_64; rv:122.0) Gecko/20100101 Firefox/122.0','https://hofff-contao-navigation.ddev.site/contao?act=edit&amp;do=themes&amp;id=1&amp;ref=YD-wtk58&amp;table=tl_module',0),(56,1708349270,'BE','GENERAL','admin','Version 26 of record &quot;tl_module.id=1&quot; has been created (parent records: tl_theme.id=1)','Contao\\Versions::create','Mozilla/5.0 (X11; Linux x86_64; rv:122.0) Gecko/20100101 Firefox/122.0','https://hofff-contao-navigation.ddev.site/contao?act=edit&amp;do=themes&amp;id=1&amp;ref=YD-wtk58&amp;table=tl_module',0),(57,1708349281,'BE','GENERAL','admin','Version 27 of record &quot;tl_module.id=1&quot; has been created (parent records: tl_theme.id=1)','Contao\\Versions::create','Mozilla/5.0 (X11; Linux x86_64; rv:122.0) Gecko/20100101 Firefox/122.0','https://hofff-contao-navigation.ddev.site/contao?act=edit&amp;do=themes&amp;id=1&amp;ref=YD-wtk58&amp;table=tl_module',0);
/*!40000 ALTER TABLE `tl_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tl_member`
--

DROP TABLE IF EXISTS `tl_member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tl_member` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `login` tinyint(1) NOT NULL DEFAULT 0,
  `assignDir` tinyint(1) NOT NULL DEFAULT 0,
  `disable` tinyint(1) NOT NULL DEFAULT 0,
  `useTwoFactor` tinyint(1) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `firstname` varchar(255) NOT NULL DEFAULT '',
  `lastname` varchar(255) NOT NULL DEFAULT '',
  `dateOfBirth` varchar(11) NOT NULL DEFAULT '',
  `gender` varchar(32) NOT NULL DEFAULT '',
  `company` varchar(255) NOT NULL DEFAULT '',
  `street` varchar(255) NOT NULL DEFAULT '',
  `postal` varchar(32) NOT NULL DEFAULT '',
  `city` varchar(255) NOT NULL DEFAULT '',
  `state` varchar(64) NOT NULL DEFAULT '',
  `country` varchar(2) NOT NULL DEFAULT '',
  `phone` varchar(64) NOT NULL DEFAULT '',
  `mobile` varchar(64) NOT NULL DEFAULT '',
  `fax` varchar(64) NOT NULL DEFAULT '',
  `email` varchar(255) NOT NULL DEFAULT '',
  `website` varchar(255) NOT NULL DEFAULT '',
  `language` varchar(64) NOT NULL DEFAULT '',
  `groups` blob DEFAULT NULL,
  `username` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `password` varchar(255) NOT NULL DEFAULT '',
  `homeDir` binary(16) DEFAULT NULL,
  `start` varchar(10) NOT NULL DEFAULT '',
  `stop` varchar(10) NOT NULL DEFAULT '',
  `dateAdded` int(10) unsigned NOT NULL DEFAULT 0,
  `lastLogin` int(10) unsigned NOT NULL DEFAULT 0,
  `currentLogin` int(10) unsigned NOT NULL DEFAULT 0,
  `session` blob DEFAULT NULL,
  `secret` binary(128) DEFAULT NULL,
  `backupCodes` text DEFAULT NULL,
  `trustedTokenVersion` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  KEY `tstamp` (`tstamp`),
  KEY `email` (`email`),
  KEY `login_disable_start_stop` (`login`,`disable`,`start`,`stop`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tl_member`
--

LOCK TABLES `tl_member` WRITE;
/*!40000 ALTER TABLE `tl_member` DISABLE KEYS */;
/*!40000 ALTER TABLE `tl_member` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tl_member_group`
--

DROP TABLE IF EXISTS `tl_member_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tl_member_group` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `redirect` tinyint(1) NOT NULL DEFAULT 0,
  `disable` tinyint(1) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `name` varchar(255) NOT NULL DEFAULT '',
  `jumpTo` int(10) unsigned NOT NULL DEFAULT 0,
  `start` varchar(10) NOT NULL DEFAULT '',
  `stop` varchar(10) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `tstamp` (`tstamp`),
  KEY `disable_start_stop` (`disable`,`start`,`stop`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tl_member_group`
--

LOCK TABLES `tl_member_group` WRITE;
/*!40000 ALTER TABLE `tl_member_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `tl_member_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tl_message_queue`
--

DROP TABLE IF EXISTS `tl_message_queue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tl_message_queue` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `body` longtext NOT NULL,
  `headers` longtext NOT NULL,
  `queue_name` varchar(190) NOT NULL,
  `created_at` datetime NOT NULL COMMENT '(DC2Type:datetime_immutable)',
  `available_at` datetime NOT NULL COMMENT '(DC2Type:datetime_immutable)',
  `delivered_at` datetime DEFAULT NULL COMMENT '(DC2Type:datetime_immutable)',
  PRIMARY KEY (`id`),
  KEY `IDX_1E97E1ADFB7336F0` (`queue_name`),
  KEY `IDX_1E97E1ADE3BD61CE` (`available_at`),
  KEY `IDX_1E97E1AD16BA31DB` (`delivered_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tl_message_queue`
--

LOCK TABLES `tl_message_queue` WRITE;
/*!40000 ALTER TABLE `tl_message_queue` DISABLE KEYS */;
/*!40000 ALTER TABLE `tl_message_queue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tl_module`
--

DROP TABLE IF EXISTS `tl_module`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tl_module` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `hardLimit` tinyint(1) NOT NULL DEFAULT 0,
  `showProtected` tinyint(1) NOT NULL DEFAULT 0,
  `defineRoot` tinyint(1) NOT NULL DEFAULT 0,
  `showHidden` tinyint(1) NOT NULL DEFAULT 0,
  `autologin` tinyint(1) NOT NULL DEFAULT 0,
  `redirectBack` tinyint(1) NOT NULL DEFAULT 0,
  `fuzzy` tinyint(1) NOT NULL DEFAULT 0,
  `loadFirst` tinyint(1) NOT NULL DEFAULT 0,
  `useCaption` tinyint(1) NOT NULL DEFAULT 0,
  `fullsize` tinyint(1) NOT NULL DEFAULT 0,
  `disableCaptcha` tinyint(1) NOT NULL DEFAULT 0,
  `reg_allowLogin` tinyint(1) NOT NULL DEFAULT 0,
  `reg_skipName` tinyint(1) NOT NULL DEFAULT 0,
  `reg_deleteDir` tinyint(1) NOT NULL DEFAULT 0,
  `reg_assignDir` tinyint(1) NOT NULL DEFAULT 0,
  `reg_activate` tinyint(1) NOT NULL DEFAULT 0,
  `protected` tinyint(1) NOT NULL DEFAULT 0,
  `hofff_navigation_roots` longblob DEFAULT NULL,
  `hofff_navigation_roots_order` longblob DEFAULT NULL,
  `hofff_navigation_start` smallint(6) NOT NULL DEFAULT 0,
  `hofff_navigation_respectHidden` varchar(1) NOT NULL DEFAULT '',
  `hofff_navigation_respectPublish` varchar(1) NOT NULL DEFAULT '',
  `hofff_navigation_respectGuests` varchar(1) NOT NULL DEFAULT '',
  `hofff_navigation_includeStart` varchar(1) NOT NULL DEFAULT '',
  `hofff_navigation_showHiddenStart` varchar(1) NOT NULL DEFAULT '',
  `hofff_navigation_showHidden` varchar(1) NOT NULL DEFAULT '',
  `hofff_navigation_showProtected` varchar(1) NOT NULL DEFAULT '',
  `hofff_navigation_showGuests` varchar(1) NOT NULL DEFAULT '',
  `hofff_navigation_addFields` longblob DEFAULT NULL,
  `hofff_navigation_noForwardResolution` varchar(1) NOT NULL DEFAULT '',
  `hofff_navigation_showErrorPages` varchar(1) NOT NULL DEFAULT '',
  `hofff_navigation_disableEvents` varchar(1) NOT NULL DEFAULT '',
  `hofff_navigation_currentAsRoot` varchar(1) NOT NULL DEFAULT '',
  `hofff_navigation_defineRoots` varchar(1) NOT NULL DEFAULT '',
  `hofff_navigation_defineStop` varchar(1) NOT NULL DEFAULT '',
  `hofff_navigation_stop` varchar(255) NOT NULL DEFAULT '',
  `hofff_navigation_defineHard` varchar(1) NOT NULL DEFAULT '',
  `hofff_navigation_hard` smallint(6) NOT NULL DEFAULT 0,
  `hofff_navigation_isSitemap` varchar(1) NOT NULL DEFAULT '',
  `hofff_navigation_hideSingleLevel` varchar(1) NOT NULL DEFAULT '',
  `hofff_navigation_addLegacyCss` varchar(1) NOT NULL DEFAULT '',
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `name` varchar(255) NOT NULL DEFAULT '',
  `headline` varchar(255) NOT NULL DEFAULT 'a:2:{s:5:"value";s:0:"";s:4:"unit";s:2:"h2";}',
  `type` varchar(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL DEFAULT 'navigation',
  `levelOffset` smallint(5) unsigned NOT NULL DEFAULT 0,
  `showLevel` smallint(5) unsigned NOT NULL DEFAULT 0,
  `rootPage` int(10) unsigned NOT NULL DEFAULT 0,
  `navigationTpl` varchar(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL DEFAULT '',
  `customTpl` varchar(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL DEFAULT '',
  `pages` blob DEFAULT NULL,
  `customLabel` varchar(64) NOT NULL DEFAULT '',
  `jumpTo` int(10) unsigned NOT NULL DEFAULT 0,
  `overviewPage` int(10) unsigned NOT NULL DEFAULT 0,
  `pwResetPage` int(10) unsigned NOT NULL DEFAULT 0,
  `editable` blob DEFAULT NULL,
  `memberTpl` varchar(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL DEFAULT '',
  `form` int(10) unsigned NOT NULL DEFAULT 0,
  `queryType` varchar(8) CHARACTER SET ascii COLLATE ascii_bin NOT NULL DEFAULT 'and',
  `contextLength` varchar(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL DEFAULT '',
  `minKeywordLength` smallint(5) unsigned NOT NULL DEFAULT 4,
  `perPage` smallint(5) unsigned NOT NULL DEFAULT 0,
  `searchType` varchar(16) CHARACTER SET ascii COLLATE ascii_bin NOT NULL DEFAULT 'simple',
  `searchTpl` varchar(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL DEFAULT '',
  `inColumn` varchar(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL DEFAULT 'main',
  `skipFirst` smallint(5) unsigned NOT NULL DEFAULT 0,
  `singleSRC` binary(16) DEFAULT NULL,
  `imgSize` varchar(128) CHARACTER SET ascii COLLATE ascii_bin NOT NULL DEFAULT '',
  `multiSRC` blob DEFAULT NULL,
  `html` text DEFAULT NULL,
  `unfilteredHtml` mediumtext DEFAULT NULL,
  `rss_cache` int(10) unsigned NOT NULL DEFAULT 3600,
  `rss_feed` text DEFAULT NULL,
  `rss_template` varchar(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL DEFAULT '',
  `numberOfItems` smallint(5) unsigned NOT NULL DEFAULT 3,
  `reg_groups` blob DEFAULT NULL,
  `reg_close` varchar(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL DEFAULT '',
  `reg_homeDir` binary(16) DEFAULT NULL,
  `reg_jumpTo` int(10) unsigned NOT NULL DEFAULT 0,
  `reg_text` text DEFAULT NULL,
  `reg_password` text DEFAULT NULL,
  `data` text DEFAULT NULL,
  `groups` blob DEFAULT NULL,
  `cssID` varchar(255) NOT NULL DEFAULT '',
  `rootPageDependentModules` blob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tstamp` (`tstamp`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tl_module`
--

LOCK TABLES `tl_module` WRITE;
/*!40000 ALTER TABLE `tl_module` DISABLE KEYS */;
INSERT INTO `tl_module` VALUES (1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,'a:1:{i:0;i:1;}',NULL,0,'','','','','','','','',NULL,'','','','','','','0,1,2','',0,'','','',1,1708349281,'Navigation','a:2:{s:4:\"unit\";s:2:\"h2\";s:5:\"value\";s:0:\"\";}','hofff_navigation_menu',0,0,0,'','',NULL,'',0,0,0,NULL,'',0,'and','',4,0,'simple','','main',0,NULL,'',NULL,NULL,NULL,3600,NULL,'',3,NULL,'',NULL,0,NULL,NULL,NULL,NULL,'a:2:{i:0;s:0:\"\";i:1;s:0:\"\";}',NULL);
/*!40000 ALTER TABLE `tl_module` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tl_opt_in`
--

DROP TABLE IF EXISTS `tl_opt_in`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tl_opt_in` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `token` varchar(24) NOT NULL DEFAULT '',
  `createdOn` int(10) unsigned NOT NULL DEFAULT 0,
  `confirmedOn` int(10) unsigned NOT NULL DEFAULT 0,
  `removeOn` int(10) unsigned NOT NULL DEFAULT 0,
  `invalidatedThrough` varchar(24) NOT NULL DEFAULT '',
  `email` varchar(255) NOT NULL DEFAULT '',
  `emailSubject` varchar(255) NOT NULL DEFAULT '',
  `emailText` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `token` (`token`),
  KEY `tstamp` (`tstamp`),
  KEY `removeon` (`removeOn`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tl_opt_in`
--

LOCK TABLES `tl_opt_in` WRITE;
/*!40000 ALTER TABLE `tl_opt_in` DISABLE KEYS */;
/*!40000 ALTER TABLE `tl_opt_in` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tl_opt_in_related`
--

DROP TABLE IF EXISTS `tl_opt_in_related`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tl_opt_in_related` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `relTable` varchar(64) DEFAULT NULL,
  `relId` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `pid` (`pid`),
  KEY `reltable_relid` (`relTable`,`relId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tl_opt_in_related`
--

LOCK TABLES `tl_opt_in_related` WRITE;
/*!40000 ALTER TABLE `tl_opt_in_related` DISABLE KEYS */;
/*!40000 ALTER TABLE `tl_opt_in_related` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tl_page`
--

DROP TABLE IF EXISTS `tl_page`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tl_page` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `requireItem` tinyint(1) NOT NULL DEFAULT 0,
  `alwaysForward` tinyint(1) NOT NULL DEFAULT 0,
  `redirectBack` tinyint(1) NOT NULL DEFAULT 0,
  `target` tinyint(1) NOT NULL DEFAULT 0,
  `fallback` tinyint(1) NOT NULL DEFAULT 0,
  `disableLanguageRedirect` tinyint(1) NOT NULL DEFAULT 0,
  `maintenanceMode` tinyint(1) NOT NULL DEFAULT 0,
  `enableCanonical` tinyint(1) NOT NULL DEFAULT 0,
  `useFolderUrl` tinyint(1) NOT NULL DEFAULT 0,
  `useSSL` tinyint(1) NOT NULL DEFAULT 1,
  `autoforward` tinyint(1) NOT NULL DEFAULT 0,
  `protected` tinyint(1) NOT NULL DEFAULT 0,
  `includeLayout` tinyint(1) NOT NULL DEFAULT 0,
  `includeCache` tinyint(1) NOT NULL DEFAULT 0,
  `alwaysLoadFromCache` tinyint(1) NOT NULL DEFAULT 0,
  `includeChmod` tinyint(1) NOT NULL DEFAULT 0,
  `noSearch` tinyint(1) NOT NULL DEFAULT 0,
  `hide` tinyint(1) NOT NULL DEFAULT 0,
  `published` tinyint(1) NOT NULL DEFAULT 0,
  `enforceTwoFactor` tinyint(1) NOT NULL DEFAULT 0,
  `enableCsp` tinyint(1) NOT NULL DEFAULT 0,
  `csp` longtext DEFAULT NULL,
  `cspReportOnly` tinyint(1) NOT NULL DEFAULT 0,
  `cspReportLog` tinyint(1) NOT NULL DEFAULT 0,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `type` varchar(64) NOT NULL DEFAULT 'regular',
  `alias` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `routePriority` int(11) NOT NULL DEFAULT 0,
  `pageTitle` varchar(255) NOT NULL DEFAULT '',
  `language` varchar(64) NOT NULL DEFAULT '',
  `robots` varchar(32) NOT NULL DEFAULT '',
  `description` text DEFAULT NULL,
  `redirect` varchar(32) NOT NULL DEFAULT 'permanent',
  `jumpTo` int(10) unsigned NOT NULL DEFAULT 0,
  `url` varchar(2048) NOT NULL DEFAULT '',
  `dns` varchar(255) NOT NULL DEFAULT '',
  `staticFiles` varchar(255) NOT NULL DEFAULT '',
  `staticPlugins` varchar(255) NOT NULL DEFAULT '',
  `favicon` binary(16) DEFAULT NULL,
  `robotsTxt` text DEFAULT NULL,
  `mailerTransport` varchar(255) NOT NULL DEFAULT '',
  `canonicalLink` varchar(2048) NOT NULL DEFAULT '',
  `canonicalKeepParams` varchar(255) NOT NULL DEFAULT '',
  `adminEmail` varchar(255) NOT NULL DEFAULT '',
  `dateFormat` varchar(32) NOT NULL DEFAULT '',
  `timeFormat` varchar(32) NOT NULL DEFAULT '',
  `datimFormat` varchar(32) NOT NULL DEFAULT '',
  `validAliasCharacters` varchar(255) NOT NULL DEFAULT '',
  `urlPrefix` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `urlSuffix` varchar(16) NOT NULL DEFAULT '',
  `groups` blob DEFAULT NULL,
  `layout` int(10) unsigned NOT NULL DEFAULT 0,
  `subpageLayout` int(10) unsigned NOT NULL DEFAULT 0,
  `cache` int(10) unsigned NOT NULL DEFAULT 0,
  `clientCache` int(10) unsigned NOT NULL DEFAULT 0,
  `cuser` int(10) unsigned NOT NULL DEFAULT 0,
  `cgroup` int(10) unsigned NOT NULL DEFAULT 0,
  `chmod` varchar(255) NOT NULL DEFAULT '',
  `cssClass` varchar(64) NOT NULL DEFAULT '',
  `sitemap` varchar(32) NOT NULL DEFAULT '',
  `accesskey` char(1) NOT NULL DEFAULT '',
  `start` varchar(10) NOT NULL DEFAULT '',
  `stop` varchar(10) NOT NULL DEFAULT '',
  `twoFactorJumpTo` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `tstamp` (`tstamp`),
  KEY `alias` (`alias`),
  KEY `type_dns_fallback_published_start_stop` (`type`,`dns`,`fallback`,`published`,`start`,`stop`),
  KEY `pid_published_type_start_stop` (`pid`,`published`,`type`,`start`,`stop`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tl_page`
--

LOCK TABLES `tl_page` WRITE;
/*!40000 ALTER TABLE `tl_page` DISABLE KEYS */;
INSERT INTO `tl_page` VALUES (1,0,0,0,0,1,0,0,1,0,1,0,0,1,0,0,0,0,0,1,0,0,'default-src \'self\'',0,0,0,128,1708348740,'Contao Navigation','root','contao-navigation',0,'','de','',NULL,'permanent',0,'','','','',NULL,NULL,'','','','','','','','','','',NULL,1,0,0,0,0,0,'a:9:{i:0;s:2:\"u1\";i:1;s:2:\"u2\";i:2;s:2:\"u3\";i:3;s:2:\"u4\";i:4;s:2:\"u5\";i:5;s:2:\"u6\";i:6;s:2:\"g4\";i:7;s:2:\"g5\";i:8;s:2:\"g6\";}','','','','','',0),(2,0,0,0,0,0,0,0,1,0,1,0,0,0,0,0,0,0,0,1,0,0,'default-src \'self\'',0,0,1,128,1708348752,'Home','regular','home',0,'','','index,follow',NULL,'permanent',0,'','','','',NULL,NULL,'','','','','','','','','','',NULL,0,0,0,0,0,0,'a:9:{i:0;s:2:\"u1\";i:1;s:2:\"u2\";i:2;s:2:\"u3\";i:3;s:2:\"u4\";i:4;s:2:\"u5\";i:5;s:2:\"u6\";i:6;s:2:\"g4\";i:7;s:2:\"g5\";i:8;s:2:\"g6\";}','','map_default','','','',0),(3,0,0,0,0,0,0,0,1,0,1,0,0,0,0,0,0,0,0,1,0,0,'default-src \'self\'',0,0,1,256,1708348760,'Über uns','regular','ueber-uns',0,'','','index,follow',NULL,'permanent',0,'','','','',NULL,NULL,'','','','','','','','','','',NULL,0,0,0,0,0,0,'a:9:{i:0;s:2:\"u1\";i:1;s:2:\"u2\";i:2;s:2:\"u3\";i:3;s:2:\"u4\";i:4;s:2:\"u5\";i:5;s:2:\"u6\";i:6;s:2:\"g4\";i:7;s:2:\"g5\";i:8;s:2:\"g6\";}','','map_default','','','',0),(4,0,0,0,0,0,0,0,1,0,1,0,0,0,0,0,0,0,0,1,0,0,'default-src \'self\'',0,0,1,384,1708348765,'News','regular','news',0,'','','index,follow',NULL,'permanent',0,'','','','',NULL,NULL,'','','','','','','','','','',NULL,0,0,0,0,0,0,'a:9:{i:0;s:2:\"u1\";i:1;s:2:\"u2\";i:2;s:2:\"u3\";i:3;s:2:\"u4\";i:4;s:2:\"u5\";i:5;s:2:\"u6\";i:6;s:2:\"g4\";i:7;s:2:\"g5\";i:8;s:2:\"g6\";}','','map_default','','','',0),(5,0,0,0,0,0,0,0,1,0,1,0,0,0,0,0,0,0,0,1,0,0,'default-src \'self\'',0,0,1,512,1708348773,'Kontakt','regular','kontakt',0,'','','index,follow',NULL,'permanent',0,'','','','',NULL,NULL,'','','','','','','','','','',NULL,0,0,0,0,0,0,'a:9:{i:0;s:2:\"u1\";i:1;s:2:\"u2\";i:2;s:2:\"u3\";i:3;s:2:\"u4\";i:4;s:2:\"u5\";i:5;s:2:\"u6\";i:6;s:2:\"g4\";i:7;s:2:\"g5\";i:8;s:2:\"g6\";}','','map_default','','','',0),(6,0,0,0,0,0,0,0,1,0,1,0,0,0,0,0,0,0,0,1,0,0,'default-src \'self\'',0,0,3,128,1708348782,'Profil','regular','profil',0,'','','index,follow',NULL,'permanent',0,'','','','',NULL,NULL,'','','','','','','','','','',NULL,0,0,0,0,0,0,'a:9:{i:0;s:2:\"u1\";i:1;s:2:\"u2\";i:2;s:2:\"u3\";i:3;s:2:\"u4\";i:4;s:2:\"u5\";i:5;s:2:\"u6\";i:6;s:2:\"g4\";i:7;s:2:\"g5\";i:8;s:2:\"g6\";}','','map_default','','','',0),(7,0,0,0,0,0,0,0,1,0,1,0,0,0,0,0,0,0,0,1,0,0,'default-src \'self\'',0,0,3,256,1708348788,'Karriere','regular','karriere',0,'','','index,follow',NULL,'permanent',0,'','','','',NULL,NULL,'','','','','','','','','','',NULL,0,0,0,0,0,0,'a:9:{i:0;s:2:\"u1\";i:1;s:2:\"u2\";i:2;s:2:\"u3\";i:3;s:2:\"u4\";i:4;s:2:\"u5\";i:5;s:2:\"u6\";i:6;s:2:\"g4\";i:7;s:2:\"g5\";i:8;s:2:\"g6\";}','','map_default','','','',0);
/*!40000 ALTER TABLE `tl_page` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tl_preview_link`
--

DROP TABLE IF EXISTS `tl_preview_link`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tl_preview_link` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `showUnpublished` tinyint(1) NOT NULL DEFAULT 0,
  `restrictToUrl` tinyint(1) NOT NULL DEFAULT 1,
  `published` tinyint(1) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `url` varchar(2048) NOT NULL DEFAULT '',
  `createdAt` int(10) unsigned NOT NULL DEFAULT 0,
  `expiresAt` int(10) unsigned NOT NULL DEFAULT 0,
  `createdBy` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `tstamp` (`tstamp`),
  KEY `id_published_expiresat` (`id`,`published`,`expiresAt`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tl_preview_link`
--

LOCK TABLES `tl_preview_link` WRITE;
/*!40000 ALTER TABLE `tl_preview_link` DISABLE KEYS */;
/*!40000 ALTER TABLE `tl_preview_link` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tl_search`
--

DROP TABLE IF EXISTS `tl_search`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tl_search` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `protected` tinyint(1) NOT NULL DEFAULT 0,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `title` text DEFAULT NULL,
  `url` varchar(2048) CHARACTER SET ascii COLLATE ascii_bin NOT NULL DEFAULT '',
  `text` mediumtext DEFAULT NULL,
  `filesize` double NOT NULL DEFAULT 0,
  `checksum` varchar(32) NOT NULL DEFAULT '',
  `groups` blob DEFAULT NULL,
  `language` varchar(5) NOT NULL DEFAULT '',
  `vectorLength` double NOT NULL DEFAULT 0,
  `meta` mediumtext DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `url` (`url`),
  UNIQUE KEY `pid_checksum` (`pid`,`checksum`),
  KEY `tstamp` (`tstamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tl_search`
--

LOCK TABLES `tl_search` WRITE;
/*!40000 ALTER TABLE `tl_search` DISABLE KEYS */;
/*!40000 ALTER TABLE `tl_search` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tl_search_index`
--

DROP TABLE IF EXISTS `tl_search_index`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tl_search_index` (
  `pid` int(10) unsigned NOT NULL,
  `termId` int(10) unsigned NOT NULL,
  `relevance` smallint(5) unsigned NOT NULL,
  PRIMARY KEY (`termId`,`pid`),
  KEY `pid` (`pid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tl_search_index`
--

LOCK TABLES `tl_search_index` WRITE;
/*!40000 ALTER TABLE `tl_search_index` DISABLE KEYS */;
/*!40000 ALTER TABLE `tl_search_index` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tl_search_term`
--

DROP TABLE IF EXISTS `tl_search_term`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tl_search_term` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `term` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `documentFrequency` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `term` (`term`),
  KEY `documentfrequency` (`documentFrequency`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tl_search_term`
--

LOCK TABLES `tl_search_term` WRITE;
/*!40000 ALTER TABLE `tl_search_term` DISABLE KEYS */;
/*!40000 ALTER TABLE `tl_search_term` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tl_theme`
--

DROP TABLE IF EXISTS `tl_theme`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tl_theme` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `name` varchar(128) NOT NULL DEFAULT '',
  `author` varchar(128) NOT NULL DEFAULT '',
  `folders` blob DEFAULT NULL,
  `screenshot` binary(16) DEFAULT NULL,
  `templates` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `tstamp` (`tstamp`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tl_theme`
--

LOCK TABLES `tl_theme` WRITE;
/*!40000 ALTER TABLE `tl_theme` DISABLE KEYS */;
INSERT INTO `tl_theme` VALUES (1,1708348657,'Theme','hofff.com',NULL,NULL,'');
/*!40000 ALTER TABLE `tl_theme` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tl_trusted_device`
--

DROP TABLE IF EXISTS `tl_trusted_device`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tl_trusted_device` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created` datetime NOT NULL,
  `userClass` varchar(255) DEFAULT NULL,
  `userId` int(11) DEFAULT NULL,
  `user_agent` longtext DEFAULT NULL,
  `ua_family` varchar(255) DEFAULT NULL,
  `os_family` varchar(255) DEFAULT NULL,
  `device_family` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tl_trusted_device`
--

LOCK TABLES `tl_trusted_device` WRITE;
/*!40000 ALTER TABLE `tl_trusted_device` DISABLE KEYS */;
/*!40000 ALTER TABLE `tl_trusted_device` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tl_undo`
--

DROP TABLE IF EXISTS `tl_undo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tl_undo` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `fromTable` varchar(255) NOT NULL DEFAULT '',
  `query` text DEFAULT NULL,
  `affectedRows` smallint(5) unsigned NOT NULL DEFAULT 0,
  `data` mediumblob DEFAULT NULL,
  `preview` mediumblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `pid` (`pid`),
  KEY `tstamp` (`tstamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tl_undo`
--

LOCK TABLES `tl_undo` WRITE;
/*!40000 ALTER TABLE `tl_undo` DISABLE KEYS */;
/*!40000 ALTER TABLE `tl_undo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tl_user`
--

DROP TABLE IF EXISTS `tl_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tl_user` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `showHelp` tinyint(1) NOT NULL DEFAULT 1,
  `thumbnails` tinyint(1) NOT NULL DEFAULT 1,
  `useRTE` tinyint(1) NOT NULL DEFAULT 1,
  `useCE` tinyint(1) NOT NULL DEFAULT 1,
  `doNotCollapse` tinyint(1) NOT NULL DEFAULT 0,
  `pwChange` tinyint(1) NOT NULL DEFAULT 0,
  `admin` tinyint(1) NOT NULL DEFAULT 0,
  `disable` tinyint(1) NOT NULL DEFAULT 0,
  `useTwoFactor` tinyint(1) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `username` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `name` varchar(255) NOT NULL DEFAULT '',
  `email` varchar(255) NOT NULL DEFAULT '',
  `language` varchar(64) NOT NULL DEFAULT '',
  `backendTheme` varchar(32) NOT NULL DEFAULT '',
  `uploader` varchar(32) NOT NULL DEFAULT '',
  `password` varchar(255) NOT NULL DEFAULT '',
  `groups` blob DEFAULT NULL,
  `inherit` varchar(12) NOT NULL DEFAULT 'group',
  `modules` blob DEFAULT NULL,
  `themes` blob DEFAULT NULL,
  `elements` blob DEFAULT NULL,
  `fields` blob DEFAULT NULL,
  `frontendModules` blob DEFAULT NULL,
  `pagemounts` blob DEFAULT NULL,
  `alpty` blob DEFAULT NULL,
  `filemounts` blob DEFAULT NULL,
  `fop` blob DEFAULT NULL,
  `imageSizes` blob DEFAULT NULL,
  `forms` blob DEFAULT NULL,
  `formp` blob DEFAULT NULL,
  `amg` blob DEFAULT NULL,
  `start` varchar(10) NOT NULL DEFAULT '',
  `stop` varchar(10) NOT NULL DEFAULT '',
  `session` blob DEFAULT NULL,
  `dateAdded` int(10) unsigned NOT NULL DEFAULT 0,
  `secret` binary(128) DEFAULT NULL,
  `lastLogin` int(10) unsigned NOT NULL DEFAULT 0,
  `currentLogin` int(10) unsigned NOT NULL DEFAULT 0,
  `backupCodes` text DEFAULT NULL,
  `trustedTokenVersion` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  KEY `tstamp` (`tstamp`),
  KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tl_user`
--

LOCK TABLES `tl_user` WRITE;
/*!40000 ALTER TABLE `tl_user` DISABLE KEYS */;
INSERT INTO `tl_user` VALUES (1,1,1,1,1,0,0,1,0,0,1708348600,'admin','Administrator','info@hofff.com','de','flexible','','$2y$13$qilHLHXlSCqmG7tMUNN34OGpUlg2eD//1KERbjT/Besr3U0xs8136',NULL,'group','a:0:{}','a:0:{}','a:0:{}','a:0:{}','a:0:{}','a:0:{}','a:0:{}','a:0:{}','a:0:{}','a:0:{}','a:0:{}','a:0:{}','a:0:{}','','','a:3:{s:11:\"new_records\";a:1:{s:12:\"tl_favorites\";a:1:{i:0;s:1:\"1\";}}s:15:\"fieldset_states\";a:1:{s:9:\"tl_layout\";a:1:{s:13:\"static_legend\";i:1;}}s:12:\"tl_page_tree\";a:5:{i:1;i:1;i:2;i:0;i:3;i:0;i:4;i:0;i:5;i:0;}}',1708348600,NULL,0,1708348611,NULL,0);
/*!40000 ALTER TABLE `tl_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tl_user_group`
--

DROP TABLE IF EXISTS `tl_user_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tl_user_group` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `disable` tinyint(1) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `name` varchar(255) NOT NULL DEFAULT '',
  `modules` blob DEFAULT NULL,
  `themes` blob DEFAULT NULL,
  `elements` blob DEFAULT NULL,
  `fields` blob DEFAULT NULL,
  `frontendModules` blob DEFAULT NULL,
  `pagemounts` blob DEFAULT NULL,
  `alpty` blob DEFAULT NULL,
  `filemounts` blob DEFAULT NULL,
  `fop` blob DEFAULT NULL,
  `imageSizes` blob DEFAULT NULL,
  `forms` blob DEFAULT NULL,
  `formp` blob DEFAULT NULL,
  `amg` blob DEFAULT NULL,
  `alexf` blob DEFAULT NULL,
  `start` varchar(10) NOT NULL DEFAULT '',
  `stop` varchar(10) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `tstamp` (`tstamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tl_user_group`
--

LOCK TABLES `tl_user_group` WRITE;
/*!40000 ALTER TABLE `tl_user_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `tl_user_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tl_version`
--

DROP TABLE IF EXISTS `tl_version`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tl_version` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `active` tinyint(1) NOT NULL DEFAULT 0,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `version` smallint(5) unsigned NOT NULL DEFAULT 1,
  `fromTable` varchar(255) NOT NULL DEFAULT '',
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `username` varchar(64) DEFAULT NULL,
  `description` varchar(255) NOT NULL DEFAULT '',
  `editUrl` text DEFAULT NULL,
  `data` mediumblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `pid_fromtable_version` (`pid`,`fromTable`,`version`),
  KEY `tstamp` (`tstamp`),
  KEY `userid` (`userid`)
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tl_version`
--

LOCK TABLES `tl_version` WRITE;
/*!40000 ALTER TABLE `tl_version` DISABLE KEYS */;
INSERT INTO `tl_version` VALUES (1,1,1,1708348657,1,'tl_theme',1,'admin','Theme','contao?do=themes&act=edit&id=1','a:7:{s:2:\"id\";i:1;s:6:\"tstamp\";i:1708348657;s:4:\"name\";s:5:\"Theme\";s:6:\"author\";s:9:\"hofff.com\";s:7:\"folders\";N;s:10:\"screenshot\";N;s:9:\"templates\";s:0:\"\";}'),(2,0,1,1708348679,1,'tl_layout',1,'admin','','contao?do=themes&table=tl_layout&act=edit&id=1','a:35:{s:2:\"id\";i:1;s:14:\"combineScripts\";i:1;s:12:\"minifyMarkup\";i:1;s:9:\"addJQuery\";i:0;s:11:\"addMooTools\";i:0;s:6:\"static\";i:1;s:3:\"pid\";i:1;s:6:\"tstamp\";i:1708348679;s:4:\"name\";s:0:\"\";s:4:\"rows\";s:4:\"2rwh\";s:12:\"headerHeight\";s:0:\"\";s:12:\"footerHeight\";s:0:\"\";s:4:\"cols\";s:4:\"2cll\";s:9:\"widthLeft\";s:0:\"\";s:10:\"widthRight\";s:0:\"\";s:8:\"sections\";N;s:9:\"framework\";s:54:\"a:2:{i:0;s:10:\"layout.css\";i:1;s:14:\"responsive.css\";}\";s:8:\"external\";N;s:7:\"modules\";s:68:\"a:1:{i:0;a:3:{s:3:\"mod\";i:0;s:3:\"col\";s:4:\"main\";s:6:\"enable\";i:1;}}\";s:8:\"template\";s:0:\"\";s:12:\"lightboxSize\";s:0:\"\";s:21:\"defaultImageDensities\";s:0:\"\";s:8:\"viewport\";s:53:\"width=device-width,initial-scale=1.0,shrink-to-fit=no\";s:8:\"titleTag\";s:0:\"\";s:8:\"cssClass\";s:0:\"\";s:6:\"onload\";s:0:\"\";s:4:\"head\";N;s:6:\"jquery\";N;s:8:\"mootools\";N;s:9:\"analytics\";N;s:10:\"externalJs\";N;s:7:\"scripts\";N;s:6:\"script\";N;s:5:\"width\";s:0:\"\";s:5:\"align\";s:6:\"center\";}'),(3,0,1,1708348687,2,'tl_layout',1,'admin','Standard','contao?do=themes&table=tl_layout&act=edit&id=1','a:35:{s:2:\"id\";i:1;s:14:\"combineScripts\";i:1;s:12:\"minifyMarkup\";i:1;s:9:\"addJQuery\";i:0;s:11:\"addMooTools\";i:0;s:6:\"static\";i:1;s:3:\"pid\";i:1;s:6:\"tstamp\";i:1708348687;s:4:\"name\";s:8:\"Standard\";s:4:\"rows\";s:4:\"2rwh\";s:12:\"headerHeight\";s:43:\"a:2:{s:4:\"unit\";s:0:\"\";s:5:\"value\";s:0:\"\";}\";s:12:\"footerHeight\";s:0:\"\";s:4:\"cols\";s:4:\"2cll\";s:9:\"widthLeft\";s:43:\"a:2:{s:4:\"unit\";s:0:\"\";s:5:\"value\";s:0:\"\";}\";s:10:\"widthRight\";s:0:\"\";s:8:\"sections\";s:112:\"a:1:{i:0;a:4:{s:5:\"title\";s:0:\"\";s:2:\"id\";s:0:\"\";s:8:\"template\";s:13:\"block_section\";s:8:\"position\";s:3:\"top\";}}\";s:9:\"framework\";s:54:\"a:2:{i:0;s:10:\"layout.css\";i:1;s:14:\"responsive.css\";}\";s:8:\"external\";N;s:7:\"modules\";s:76:\"a:1:{i:0;a:3:{s:3:\"mod\";s:1:\"0\";s:3:\"col\";s:4:\"main\";s:6:\"enable\";s:1:\"1\";}}\";s:8:\"template\";s:0:\"\";s:12:\"lightboxSize\";s:39:\"a:3:{i:0;s:0:\"\";i:1;s:0:\"\";i:2;s:0:\"\";}\";s:21:\"defaultImageDensities\";s:0:\"\";s:8:\"viewport\";s:53:\"width=device-width,initial-scale=1.0,shrink-to-fit=no\";s:8:\"titleTag\";s:0:\"\";s:8:\"cssClass\";s:0:\"\";s:6:\"onload\";s:0:\"\";s:4:\"head\";N;s:6:\"jquery\";N;s:8:\"mootools\";N;s:9:\"analytics\";N;s:10:\"externalJs\";N;s:7:\"scripts\";N;s:6:\"script\";N;s:5:\"width\";s:48:\"a:2:{s:4:\"unit\";s:3:\"rem\";s:5:\"value\";s:2:\"80\";}\";s:5:\"align\";s:6:\"center\";}'),(4,0,1,1708348711,1,'tl_module',1,'admin','Navigation','contao?do=themes&table=tl_module&act=edit&id=1','a:87:{s:2:\"id\";i:1;s:9:\"hardLimit\";i:0;s:13:\"showProtected\";i:0;s:10:\"defineRoot\";i:0;s:10:\"showHidden\";i:0;s:9:\"autologin\";i:0;s:12:\"redirectBack\";i:0;s:5:\"fuzzy\";i:0;s:9:\"loadFirst\";i:0;s:10:\"useCaption\";i:0;s:8:\"fullsize\";i:0;s:14:\"disableCaptcha\";i:0;s:14:\"reg_allowLogin\";i:0;s:12:\"reg_skipName\";i:0;s:13:\"reg_deleteDir\";i:0;s:13:\"reg_assignDir\";i:0;s:12:\"reg_activate\";i:0;s:9:\"protected\";i:0;s:22:\"hofff_navigation_roots\";N;s:28:\"hofff_navigation_roots_order\";N;s:22:\"hofff_navigation_start\";i:0;s:30:\"hofff_navigation_respectHidden\";s:0:\"\";s:31:\"hofff_navigation_respectPublish\";s:0:\"\";s:30:\"hofff_navigation_respectGuests\";s:0:\"\";s:29:\"hofff_navigation_includeStart\";s:0:\"\";s:32:\"hofff_navigation_showHiddenStart\";s:0:\"\";s:27:\"hofff_navigation_showHidden\";s:0:\"\";s:30:\"hofff_navigation_showProtected\";s:0:\"\";s:27:\"hofff_navigation_showGuests\";s:0:\"\";s:26:\"hofff_navigation_addFields\";N;s:36:\"hofff_navigation_noForwardResolution\";s:0:\"\";s:31:\"hofff_navigation_showErrorPages\";s:0:\"\";s:30:\"hofff_navigation_disableEvents\";s:0:\"\";s:30:\"hofff_navigation_currentAsRoot\";s:0:\"\";s:28:\"hofff_navigation_defineRoots\";s:0:\"\";s:27:\"hofff_navigation_defineStop\";s:0:\"\";s:21:\"hofff_navigation_stop\";s:0:\"\";s:27:\"hofff_navigation_defineHard\";s:0:\"\";s:21:\"hofff_navigation_hard\";i:0;s:26:\"hofff_navigation_isSitemap\";s:0:\"\";s:32:\"hofff_navigation_hideSingleLevel\";s:0:\"\";s:29:\"hofff_navigation_addLegacyCss\";s:0:\"\";s:3:\"pid\";i:1;s:6:\"tstamp\";i:1708348711;s:4:\"name\";s:10:\"Navigation\";s:8:\"headline\";s:45:\"a:2:{s:4:\"unit\";s:2:\"h2\";s:5:\"value\";s:0:\"\";}\";s:4:\"type\";s:21:\"hofff_navigation_menu\";s:11:\"levelOffset\";i:0;s:9:\"showLevel\";i:0;s:8:\"rootPage\";i:0;s:13:\"navigationTpl\";s:0:\"\";s:9:\"customTpl\";s:0:\"\";s:5:\"pages\";N;s:11:\"customLabel\";s:0:\"\";s:6:\"jumpTo\";i:0;s:12:\"overviewPage\";i:0;s:11:\"pwResetPage\";i:0;s:8:\"editable\";N;s:9:\"memberTpl\";s:0:\"\";s:4:\"form\";i:0;s:9:\"queryType\";s:3:\"and\";s:13:\"contextLength\";s:0:\"\";s:16:\"minKeywordLength\";i:4;s:7:\"perPage\";i:0;s:10:\"searchType\";s:6:\"simple\";s:9:\"searchTpl\";s:0:\"\";s:8:\"inColumn\";s:4:\"main\";s:9:\"skipFirst\";i:0;s:9:\"singleSRC\";N;s:7:\"imgSize\";s:0:\"\";s:8:\"multiSRC\";N;s:4:\"html\";N;s:14:\"unfilteredHtml\";N;s:9:\"rss_cache\";i:3600;s:8:\"rss_feed\";N;s:12:\"rss_template\";s:0:\"\";s:13:\"numberOfItems\";i:3;s:10:\"reg_groups\";N;s:9:\"reg_close\";s:0:\"\";s:11:\"reg_homeDir\";N;s:10:\"reg_jumpTo\";i:0;s:8:\"reg_text\";N;s:12:\"reg_password\";N;s:4:\"data\";N;s:6:\"groups\";N;s:5:\"cssID\";s:28:\"a:2:{i:0;s:0:\"\";i:1;s:0:\"\";}\";s:24:\"rootPageDependentModules\";N;}'),(5,0,1,1708348716,2,'tl_module',1,'admin','Navigation','contao?do=themes&table=tl_module&act=edit&id=1','a:87:{s:2:\"id\";i:1;s:9:\"hardLimit\";i:0;s:13:\"showProtected\";i:0;s:10:\"defineRoot\";i:0;s:10:\"showHidden\";i:0;s:9:\"autologin\";i:0;s:12:\"redirectBack\";i:0;s:5:\"fuzzy\";i:0;s:9:\"loadFirst\";i:0;s:10:\"useCaption\";i:0;s:8:\"fullsize\";i:0;s:14:\"disableCaptcha\";i:0;s:14:\"reg_allowLogin\";i:0;s:12:\"reg_skipName\";i:0;s:13:\"reg_deleteDir\";i:0;s:13:\"reg_assignDir\";i:0;s:12:\"reg_activate\";i:0;s:9:\"protected\";i:0;s:22:\"hofff_navigation_roots\";N;s:28:\"hofff_navigation_roots_order\";N;s:22:\"hofff_navigation_start\";i:0;s:30:\"hofff_navigation_respectHidden\";s:0:\"\";s:31:\"hofff_navigation_respectPublish\";s:0:\"\";s:30:\"hofff_navigation_respectGuests\";s:0:\"\";s:29:\"hofff_navigation_includeStart\";s:0:\"\";s:32:\"hofff_navigation_showHiddenStart\";s:0:\"\";s:27:\"hofff_navigation_showHidden\";s:0:\"\";s:30:\"hofff_navigation_showProtected\";s:0:\"\";s:27:\"hofff_navigation_showGuests\";s:0:\"\";s:26:\"hofff_navigation_addFields\";N;s:36:\"hofff_navigation_noForwardResolution\";s:0:\"\";s:31:\"hofff_navigation_showErrorPages\";s:0:\"\";s:30:\"hofff_navigation_disableEvents\";s:0:\"\";s:30:\"hofff_navigation_currentAsRoot\";s:0:\"\";s:28:\"hofff_navigation_defineRoots\";s:0:\"\";s:27:\"hofff_navigation_defineStop\";s:0:\"\";s:21:\"hofff_navigation_stop\";s:0:\"\";s:27:\"hofff_navigation_defineHard\";s:0:\"\";s:21:\"hofff_navigation_hard\";i:0;s:26:\"hofff_navigation_isSitemap\";s:0:\"\";s:32:\"hofff_navigation_hideSingleLevel\";s:0:\"\";s:29:\"hofff_navigation_addLegacyCss\";s:0:\"\";s:3:\"pid\";i:1;s:6:\"tstamp\";i:1708348716;s:4:\"name\";s:10:\"Navigation\";s:8:\"headline\";s:45:\"a:2:{s:4:\"unit\";s:2:\"h2\";s:5:\"value\";s:0:\"\";}\";s:4:\"type\";s:21:\"hofff_navigation_menu\";s:11:\"levelOffset\";i:0;s:9:\"showLevel\";i:0;s:8:\"rootPage\";i:0;s:13:\"navigationTpl\";s:0:\"\";s:9:\"customTpl\";s:0:\"\";s:5:\"pages\";N;s:11:\"customLabel\";s:0:\"\";s:6:\"jumpTo\";i:0;s:12:\"overviewPage\";i:0;s:11:\"pwResetPage\";i:0;s:8:\"editable\";N;s:9:\"memberTpl\";s:0:\"\";s:4:\"form\";i:0;s:9:\"queryType\";s:3:\"and\";s:13:\"contextLength\";s:0:\"\";s:16:\"minKeywordLength\";i:4;s:7:\"perPage\";i:0;s:10:\"searchType\";s:6:\"simple\";s:9:\"searchTpl\";s:0:\"\";s:8:\"inColumn\";s:4:\"main\";s:9:\"skipFirst\";i:0;s:9:\"singleSRC\";N;s:7:\"imgSize\";s:0:\"\";s:8:\"multiSRC\";N;s:4:\"html\";N;s:14:\"unfilteredHtml\";N;s:9:\"rss_cache\";i:3600;s:8:\"rss_feed\";N;s:12:\"rss_template\";s:0:\"\";s:13:\"numberOfItems\";i:3;s:10:\"reg_groups\";N;s:9:\"reg_close\";s:0:\"\";s:11:\"reg_homeDir\";N;s:10:\"reg_jumpTo\";i:0;s:8:\"reg_text\";N;s:12:\"reg_password\";N;s:4:\"data\";N;s:6:\"groups\";N;s:5:\"cssID\";s:28:\"a:2:{i:0;s:0:\"\";i:1;s:0:\"\";}\";s:24:\"rootPageDependentModules\";N;}'),(6,0,1,1708348734,1,'tl_page',1,'admin','Contao Navigation','contao?do=page&act=edit&id=1','a:68:{s:2:\"id\";i:1;s:11:\"requireItem\";i:0;s:13:\"alwaysForward\";i:0;s:12:\"redirectBack\";i:0;s:6:\"target\";i:0;s:8:\"fallback\";i:1;s:23:\"disableLanguageRedirect\";i:0;s:15:\"maintenanceMode\";i:0;s:15:\"enableCanonical\";i:1;s:12:\"useFolderUrl\";i:0;s:6:\"useSSL\";i:1;s:11:\"autoforward\";i:0;s:9:\"protected\";i:0;s:13:\"includeLayout\";i:0;s:12:\"includeCache\";i:0;s:19:\"alwaysLoadFromCache\";i:0;s:12:\"includeChmod\";i:0;s:8:\"noSearch\";i:0;s:4:\"hide\";i:0;s:9:\"published\";i:0;s:16:\"enforceTwoFactor\";i:0;s:9:\"enableCsp\";i:0;s:3:\"csp\";s:18:\"default-src \'self\'\";s:13:\"cspReportOnly\";i:0;s:12:\"cspReportLog\";i:0;s:3:\"pid\";i:0;s:7:\"sorting\";i:128;s:6:\"tstamp\";i:1708348734;s:5:\"title\";s:17:\"Contao Navigation\";s:4:\"type\";s:4:\"root\";s:5:\"alias\";s:17:\"contao-navigation\";s:13:\"routePriority\";i:0;s:9:\"pageTitle\";s:0:\"\";s:8:\"language\";s:2:\"de\";s:6:\"robots\";s:0:\"\";s:11:\"description\";N;s:8:\"redirect\";s:9:\"permanent\";s:6:\"jumpTo\";i:0;s:3:\"url\";s:0:\"\";s:3:\"dns\";s:0:\"\";s:11:\"staticFiles\";s:0:\"\";s:13:\"staticPlugins\";s:0:\"\";s:7:\"favicon\";N;s:9:\"robotsTxt\";N;s:15:\"mailerTransport\";s:0:\"\";s:13:\"canonicalLink\";s:0:\"\";s:19:\"canonicalKeepParams\";s:0:\"\";s:10:\"adminEmail\";s:0:\"\";s:10:\"dateFormat\";s:0:\"\";s:10:\"timeFormat\";s:0:\"\";s:11:\"datimFormat\";s:0:\"\";s:20:\"validAliasCharacters\";s:0:\"\";s:9:\"urlPrefix\";s:0:\"\";s:9:\"urlSuffix\";s:0:\"\";s:6:\"groups\";N;s:6:\"layout\";i:0;s:13:\"subpageLayout\";i:0;s:5:\"cache\";i:0;s:11:\"clientCache\";i:0;s:5:\"cuser\";i:0;s:6:\"cgroup\";i:0;s:5:\"chmod\";s:123:\"a:9:{i:0;s:2:\"u1\";i:1;s:2:\"u2\";i:2;s:2:\"u3\";i:3;s:2:\"u4\";i:4;s:2:\"u5\";i:5;s:2:\"u6\";i:6;s:2:\"g4\";i:7;s:2:\"g5\";i:8;s:2:\"g6\";}\";s:8:\"cssClass\";s:0:\"\";s:7:\"sitemap\";s:0:\"\";s:9:\"accesskey\";s:0:\"\";s:5:\"start\";s:0:\"\";s:4:\"stop\";s:0:\"\";s:15:\"twoFactorJumpTo\";i:0;}'),(7,0,1,1708348737,2,'tl_page',1,'admin','Contao Navigation','contao?do=page&act=edit&id=1','a:68:{s:2:\"id\";i:1;s:11:\"requireItem\";i:0;s:13:\"alwaysForward\";i:0;s:12:\"redirectBack\";i:0;s:6:\"target\";i:0;s:8:\"fallback\";i:1;s:23:\"disableLanguageRedirect\";i:0;s:15:\"maintenanceMode\";i:0;s:15:\"enableCanonical\";i:1;s:12:\"useFolderUrl\";i:0;s:6:\"useSSL\";i:1;s:11:\"autoforward\";i:0;s:9:\"protected\";i:0;s:13:\"includeLayout\";i:1;s:12:\"includeCache\";i:0;s:19:\"alwaysLoadFromCache\";i:0;s:12:\"includeChmod\";i:0;s:8:\"noSearch\";i:0;s:4:\"hide\";i:0;s:9:\"published\";i:0;s:16:\"enforceTwoFactor\";i:0;s:9:\"enableCsp\";i:0;s:3:\"csp\";s:18:\"default-src \'self\'\";s:13:\"cspReportOnly\";i:0;s:12:\"cspReportLog\";i:0;s:3:\"pid\";i:0;s:7:\"sorting\";i:128;s:6:\"tstamp\";i:1708348737;s:5:\"title\";s:17:\"Contao Navigation\";s:4:\"type\";s:4:\"root\";s:5:\"alias\";s:17:\"contao-navigation\";s:13:\"routePriority\";i:0;s:9:\"pageTitle\";s:0:\"\";s:8:\"language\";s:2:\"de\";s:6:\"robots\";s:0:\"\";s:11:\"description\";N;s:8:\"redirect\";s:9:\"permanent\";s:6:\"jumpTo\";i:0;s:3:\"url\";s:0:\"\";s:3:\"dns\";s:0:\"\";s:11:\"staticFiles\";s:0:\"\";s:13:\"staticPlugins\";s:0:\"\";s:7:\"favicon\";N;s:9:\"robotsTxt\";N;s:15:\"mailerTransport\";s:0:\"\";s:13:\"canonicalLink\";s:0:\"\";s:19:\"canonicalKeepParams\";s:0:\"\";s:10:\"adminEmail\";s:0:\"\";s:10:\"dateFormat\";s:0:\"\";s:10:\"timeFormat\";s:0:\"\";s:11:\"datimFormat\";s:0:\"\";s:20:\"validAliasCharacters\";s:0:\"\";s:9:\"urlPrefix\";s:0:\"\";s:9:\"urlSuffix\";s:0:\"\";s:6:\"groups\";N;s:6:\"layout\";i:0;s:13:\"subpageLayout\";i:0;s:5:\"cache\";i:0;s:11:\"clientCache\";i:0;s:5:\"cuser\";i:0;s:6:\"cgroup\";i:0;s:5:\"chmod\";s:123:\"a:9:{i:0;s:2:\"u1\";i:1;s:2:\"u2\";i:2;s:2:\"u3\";i:3;s:2:\"u4\";i:4;s:2:\"u5\";i:5;s:2:\"u6\";i:6;s:2:\"g4\";i:7;s:2:\"g5\";i:8;s:2:\"g6\";}\";s:8:\"cssClass\";s:0:\"\";s:7:\"sitemap\";s:0:\"\";s:9:\"accesskey\";s:0:\"\";s:5:\"start\";s:0:\"\";s:4:\"stop\";s:0:\"\";s:15:\"twoFactorJumpTo\";i:0;}'),(8,1,1,1708348740,3,'tl_page',1,'admin','Contao Navigation','contao?do=page&act=edit&id=1','a:68:{s:2:\"id\";i:1;s:11:\"requireItem\";i:0;s:13:\"alwaysForward\";i:0;s:12:\"redirectBack\";i:0;s:6:\"target\";i:0;s:8:\"fallback\";i:1;s:23:\"disableLanguageRedirect\";i:0;s:15:\"maintenanceMode\";i:0;s:15:\"enableCanonical\";i:1;s:12:\"useFolderUrl\";i:0;s:6:\"useSSL\";i:1;s:11:\"autoforward\";i:0;s:9:\"protected\";i:0;s:13:\"includeLayout\";i:1;s:12:\"includeCache\";i:0;s:19:\"alwaysLoadFromCache\";i:0;s:12:\"includeChmod\";i:0;s:8:\"noSearch\";i:0;s:4:\"hide\";i:0;s:9:\"published\";i:1;s:16:\"enforceTwoFactor\";i:0;s:9:\"enableCsp\";i:0;s:3:\"csp\";s:18:\"default-src \'self\'\";s:13:\"cspReportOnly\";i:0;s:12:\"cspReportLog\";i:0;s:3:\"pid\";i:0;s:7:\"sorting\";i:128;s:6:\"tstamp\";i:1708348740;s:5:\"title\";s:17:\"Contao Navigation\";s:4:\"type\";s:4:\"root\";s:5:\"alias\";s:17:\"contao-navigation\";s:13:\"routePriority\";i:0;s:9:\"pageTitle\";s:0:\"\";s:8:\"language\";s:2:\"de\";s:6:\"robots\";s:0:\"\";s:11:\"description\";N;s:8:\"redirect\";s:9:\"permanent\";s:6:\"jumpTo\";i:0;s:3:\"url\";s:0:\"\";s:3:\"dns\";s:0:\"\";s:11:\"staticFiles\";s:0:\"\";s:13:\"staticPlugins\";s:0:\"\";s:7:\"favicon\";N;s:9:\"robotsTxt\";N;s:15:\"mailerTransport\";s:0:\"\";s:13:\"canonicalLink\";s:0:\"\";s:19:\"canonicalKeepParams\";s:0:\"\";s:10:\"adminEmail\";s:0:\"\";s:10:\"dateFormat\";s:0:\"\";s:10:\"timeFormat\";s:0:\"\";s:11:\"datimFormat\";s:0:\"\";s:20:\"validAliasCharacters\";s:0:\"\";s:9:\"urlPrefix\";s:0:\"\";s:9:\"urlSuffix\";s:0:\"\";s:6:\"groups\";N;s:6:\"layout\";i:1;s:13:\"subpageLayout\";i:0;s:5:\"cache\";i:0;s:11:\"clientCache\";i:0;s:5:\"cuser\";i:0;s:6:\"cgroup\";i:0;s:5:\"chmod\";s:123:\"a:9:{i:0;s:2:\"u1\";i:1;s:2:\"u2\";i:2;s:2:\"u3\";i:3;s:2:\"u4\";i:4;s:2:\"u5\";i:5;s:2:\"u6\";i:6;s:2:\"g4\";i:7;s:2:\"g5\";i:8;s:2:\"g6\";}\";s:8:\"cssClass\";s:0:\"\";s:7:\"sitemap\";s:0:\"\";s:9:\"accesskey\";s:0:\"\";s:5:\"start\";s:0:\"\";s:4:\"stop\";s:0:\"\";s:15:\"twoFactorJumpTo\";i:0;}'),(9,1,2,1708348752,1,'tl_page',1,'admin','Home','contao?do=page&act=edit&id=2','a:68:{s:2:\"id\";i:2;s:11:\"requireItem\";i:0;s:13:\"alwaysForward\";i:0;s:12:\"redirectBack\";i:0;s:6:\"target\";i:0;s:8:\"fallback\";i:0;s:23:\"disableLanguageRedirect\";i:0;s:15:\"maintenanceMode\";i:0;s:15:\"enableCanonical\";i:1;s:12:\"useFolderUrl\";i:0;s:6:\"useSSL\";i:1;s:11:\"autoforward\";i:0;s:9:\"protected\";i:0;s:13:\"includeLayout\";i:0;s:12:\"includeCache\";i:0;s:19:\"alwaysLoadFromCache\";i:0;s:12:\"includeChmod\";i:0;s:8:\"noSearch\";i:0;s:4:\"hide\";i:0;s:9:\"published\";i:1;s:16:\"enforceTwoFactor\";i:0;s:9:\"enableCsp\";i:0;s:3:\"csp\";s:18:\"default-src \'self\'\";s:13:\"cspReportOnly\";i:0;s:12:\"cspReportLog\";i:0;s:3:\"pid\";i:1;s:7:\"sorting\";i:128;s:6:\"tstamp\";i:1708348752;s:5:\"title\";s:4:\"Home\";s:4:\"type\";s:7:\"regular\";s:5:\"alias\";s:4:\"home\";s:13:\"routePriority\";i:0;s:9:\"pageTitle\";s:0:\"\";s:8:\"language\";s:0:\"\";s:6:\"robots\";s:12:\"index,follow\";s:11:\"description\";N;s:8:\"redirect\";s:9:\"permanent\";s:6:\"jumpTo\";i:0;s:3:\"url\";s:0:\"\";s:3:\"dns\";s:0:\"\";s:11:\"staticFiles\";s:0:\"\";s:13:\"staticPlugins\";s:0:\"\";s:7:\"favicon\";N;s:9:\"robotsTxt\";N;s:15:\"mailerTransport\";s:0:\"\";s:13:\"canonicalLink\";s:0:\"\";s:19:\"canonicalKeepParams\";s:0:\"\";s:10:\"adminEmail\";s:0:\"\";s:10:\"dateFormat\";s:0:\"\";s:10:\"timeFormat\";s:0:\"\";s:11:\"datimFormat\";s:0:\"\";s:20:\"validAliasCharacters\";s:0:\"\";s:9:\"urlPrefix\";s:0:\"\";s:9:\"urlSuffix\";s:0:\"\";s:6:\"groups\";N;s:6:\"layout\";i:0;s:13:\"subpageLayout\";i:0;s:5:\"cache\";i:0;s:11:\"clientCache\";i:0;s:5:\"cuser\";i:0;s:6:\"cgroup\";i:0;s:5:\"chmod\";s:123:\"a:9:{i:0;s:2:\"u1\";i:1;s:2:\"u2\";i:2;s:2:\"u3\";i:3;s:2:\"u4\";i:4;s:2:\"u5\";i:5;s:2:\"u6\";i:6;s:2:\"g4\";i:7;s:2:\"g5\";i:8;s:2:\"g6\";}\";s:8:\"cssClass\";s:0:\"\";s:7:\"sitemap\";s:11:\"map_default\";s:9:\"accesskey\";s:0:\"\";s:5:\"start\";s:0:\"\";s:4:\"stop\";s:0:\"\";s:15:\"twoFactorJumpTo\";i:0;}'),(10,1,3,1708348760,1,'tl_page',1,'admin','Über uns','contao?do=page&act=edit&id=3','a:68:{s:2:\"id\";i:3;s:11:\"requireItem\";i:0;s:13:\"alwaysForward\";i:0;s:12:\"redirectBack\";i:0;s:6:\"target\";i:0;s:8:\"fallback\";i:0;s:23:\"disableLanguageRedirect\";i:0;s:15:\"maintenanceMode\";i:0;s:15:\"enableCanonical\";i:1;s:12:\"useFolderUrl\";i:0;s:6:\"useSSL\";i:1;s:11:\"autoforward\";i:0;s:9:\"protected\";i:0;s:13:\"includeLayout\";i:0;s:12:\"includeCache\";i:0;s:19:\"alwaysLoadFromCache\";i:0;s:12:\"includeChmod\";i:0;s:8:\"noSearch\";i:0;s:4:\"hide\";i:0;s:9:\"published\";i:1;s:16:\"enforceTwoFactor\";i:0;s:9:\"enableCsp\";i:0;s:3:\"csp\";s:18:\"default-src \'self\'\";s:13:\"cspReportOnly\";i:0;s:12:\"cspReportLog\";i:0;s:3:\"pid\";i:1;s:7:\"sorting\";i:256;s:6:\"tstamp\";i:1708348760;s:5:\"title\";s:9:\"Über uns\";s:4:\"type\";s:7:\"regular\";s:5:\"alias\";s:9:\"ueber-uns\";s:13:\"routePriority\";i:0;s:9:\"pageTitle\";s:0:\"\";s:8:\"language\";s:0:\"\";s:6:\"robots\";s:12:\"index,follow\";s:11:\"description\";N;s:8:\"redirect\";s:9:\"permanent\";s:6:\"jumpTo\";i:0;s:3:\"url\";s:0:\"\";s:3:\"dns\";s:0:\"\";s:11:\"staticFiles\";s:0:\"\";s:13:\"staticPlugins\";s:0:\"\";s:7:\"favicon\";N;s:9:\"robotsTxt\";N;s:15:\"mailerTransport\";s:0:\"\";s:13:\"canonicalLink\";s:0:\"\";s:19:\"canonicalKeepParams\";s:0:\"\";s:10:\"adminEmail\";s:0:\"\";s:10:\"dateFormat\";s:0:\"\";s:10:\"timeFormat\";s:0:\"\";s:11:\"datimFormat\";s:0:\"\";s:20:\"validAliasCharacters\";s:0:\"\";s:9:\"urlPrefix\";s:0:\"\";s:9:\"urlSuffix\";s:0:\"\";s:6:\"groups\";N;s:6:\"layout\";i:0;s:13:\"subpageLayout\";i:0;s:5:\"cache\";i:0;s:11:\"clientCache\";i:0;s:5:\"cuser\";i:0;s:6:\"cgroup\";i:0;s:5:\"chmod\";s:123:\"a:9:{i:0;s:2:\"u1\";i:1;s:2:\"u2\";i:2;s:2:\"u3\";i:3;s:2:\"u4\";i:4;s:2:\"u5\";i:5;s:2:\"u6\";i:6;s:2:\"g4\";i:7;s:2:\"g5\";i:8;s:2:\"g6\";}\";s:8:\"cssClass\";s:0:\"\";s:7:\"sitemap\";s:11:\"map_default\";s:9:\"accesskey\";s:0:\"\";s:5:\"start\";s:0:\"\";s:4:\"stop\";s:0:\"\";s:15:\"twoFactorJumpTo\";i:0;}'),(11,1,4,1708348765,1,'tl_page',1,'admin','News','contao?do=page&act=edit&id=4','a:68:{s:2:\"id\";i:4;s:11:\"requireItem\";i:0;s:13:\"alwaysForward\";i:0;s:12:\"redirectBack\";i:0;s:6:\"target\";i:0;s:8:\"fallback\";i:0;s:23:\"disableLanguageRedirect\";i:0;s:15:\"maintenanceMode\";i:0;s:15:\"enableCanonical\";i:1;s:12:\"useFolderUrl\";i:0;s:6:\"useSSL\";i:1;s:11:\"autoforward\";i:0;s:9:\"protected\";i:0;s:13:\"includeLayout\";i:0;s:12:\"includeCache\";i:0;s:19:\"alwaysLoadFromCache\";i:0;s:12:\"includeChmod\";i:0;s:8:\"noSearch\";i:0;s:4:\"hide\";i:0;s:9:\"published\";i:1;s:16:\"enforceTwoFactor\";i:0;s:9:\"enableCsp\";i:0;s:3:\"csp\";s:18:\"default-src \'self\'\";s:13:\"cspReportOnly\";i:0;s:12:\"cspReportLog\";i:0;s:3:\"pid\";i:1;s:7:\"sorting\";i:384;s:6:\"tstamp\";i:1708348765;s:5:\"title\";s:4:\"News\";s:4:\"type\";s:7:\"regular\";s:5:\"alias\";s:4:\"news\";s:13:\"routePriority\";i:0;s:9:\"pageTitle\";s:0:\"\";s:8:\"language\";s:0:\"\";s:6:\"robots\";s:12:\"index,follow\";s:11:\"description\";N;s:8:\"redirect\";s:9:\"permanent\";s:6:\"jumpTo\";i:0;s:3:\"url\";s:0:\"\";s:3:\"dns\";s:0:\"\";s:11:\"staticFiles\";s:0:\"\";s:13:\"staticPlugins\";s:0:\"\";s:7:\"favicon\";N;s:9:\"robotsTxt\";N;s:15:\"mailerTransport\";s:0:\"\";s:13:\"canonicalLink\";s:0:\"\";s:19:\"canonicalKeepParams\";s:0:\"\";s:10:\"adminEmail\";s:0:\"\";s:10:\"dateFormat\";s:0:\"\";s:10:\"timeFormat\";s:0:\"\";s:11:\"datimFormat\";s:0:\"\";s:20:\"validAliasCharacters\";s:0:\"\";s:9:\"urlPrefix\";s:0:\"\";s:9:\"urlSuffix\";s:0:\"\";s:6:\"groups\";N;s:6:\"layout\";i:0;s:13:\"subpageLayout\";i:0;s:5:\"cache\";i:0;s:11:\"clientCache\";i:0;s:5:\"cuser\";i:0;s:6:\"cgroup\";i:0;s:5:\"chmod\";s:123:\"a:9:{i:0;s:2:\"u1\";i:1;s:2:\"u2\";i:2;s:2:\"u3\";i:3;s:2:\"u4\";i:4;s:2:\"u5\";i:5;s:2:\"u6\";i:6;s:2:\"g4\";i:7;s:2:\"g5\";i:8;s:2:\"g6\";}\";s:8:\"cssClass\";s:0:\"\";s:7:\"sitemap\";s:11:\"map_default\";s:9:\"accesskey\";s:0:\"\";s:5:\"start\";s:0:\"\";s:4:\"stop\";s:0:\"\";s:15:\"twoFactorJumpTo\";i:0;}'),(12,0,5,1708348769,1,'tl_page',1,'admin','Kontakt','contao?do=page&act=edit&id=5','a:68:{s:2:\"id\";i:5;s:11:\"requireItem\";i:0;s:13:\"alwaysForward\";i:0;s:12:\"redirectBack\";i:0;s:6:\"target\";i:0;s:8:\"fallback\";i:0;s:23:\"disableLanguageRedirect\";i:0;s:15:\"maintenanceMode\";i:0;s:15:\"enableCanonical\";i:1;s:12:\"useFolderUrl\";i:0;s:6:\"useSSL\";i:1;s:11:\"autoforward\";i:0;s:9:\"protected\";i:0;s:13:\"includeLayout\";i:0;s:12:\"includeCache\";i:0;s:19:\"alwaysLoadFromCache\";i:0;s:12:\"includeChmod\";i:0;s:8:\"noSearch\";i:0;s:4:\"hide\";i:0;s:9:\"published\";i:0;s:16:\"enforceTwoFactor\";i:0;s:9:\"enableCsp\";i:0;s:3:\"csp\";s:18:\"default-src \'self\'\";s:13:\"cspReportOnly\";i:0;s:12:\"cspReportLog\";i:0;s:3:\"pid\";i:1;s:7:\"sorting\";i:512;s:6:\"tstamp\";i:1708348769;s:5:\"title\";s:7:\"Kontakt\";s:4:\"type\";s:7:\"regular\";s:5:\"alias\";s:7:\"kontakt\";s:13:\"routePriority\";i:0;s:9:\"pageTitle\";s:0:\"\";s:8:\"language\";s:0:\"\";s:6:\"robots\";s:12:\"index,follow\";s:11:\"description\";N;s:8:\"redirect\";s:9:\"permanent\";s:6:\"jumpTo\";i:0;s:3:\"url\";s:0:\"\";s:3:\"dns\";s:0:\"\";s:11:\"staticFiles\";s:0:\"\";s:13:\"staticPlugins\";s:0:\"\";s:7:\"favicon\";N;s:9:\"robotsTxt\";N;s:15:\"mailerTransport\";s:0:\"\";s:13:\"canonicalLink\";s:0:\"\";s:19:\"canonicalKeepParams\";s:0:\"\";s:10:\"adminEmail\";s:0:\"\";s:10:\"dateFormat\";s:0:\"\";s:10:\"timeFormat\";s:0:\"\";s:11:\"datimFormat\";s:0:\"\";s:20:\"validAliasCharacters\";s:0:\"\";s:9:\"urlPrefix\";s:0:\"\";s:9:\"urlSuffix\";s:0:\"\";s:6:\"groups\";N;s:6:\"layout\";i:0;s:13:\"subpageLayout\";i:0;s:5:\"cache\";i:0;s:11:\"clientCache\";i:0;s:5:\"cuser\";i:0;s:6:\"cgroup\";i:0;s:5:\"chmod\";s:123:\"a:9:{i:0;s:2:\"u1\";i:1;s:2:\"u2\";i:2;s:2:\"u3\";i:3;s:2:\"u4\";i:4;s:2:\"u5\";i:5;s:2:\"u6\";i:6;s:2:\"g4\";i:7;s:2:\"g5\";i:8;s:2:\"g6\";}\";s:8:\"cssClass\";s:0:\"\";s:7:\"sitemap\";s:11:\"map_default\";s:9:\"accesskey\";s:0:\"\";s:5:\"start\";s:0:\"\";s:4:\"stop\";s:0:\"\";s:15:\"twoFactorJumpTo\";i:0;}'),(13,1,5,1708348773,2,'tl_page',1,'admin','Kontakt','contao?do=page&act=edit&field=published&id=5','a:68:{s:2:\"id\";i:5;s:11:\"requireItem\";i:0;s:13:\"alwaysForward\";i:0;s:12:\"redirectBack\";i:0;s:6:\"target\";i:0;s:8:\"fallback\";i:0;s:23:\"disableLanguageRedirect\";i:0;s:15:\"maintenanceMode\";i:0;s:15:\"enableCanonical\";i:1;s:12:\"useFolderUrl\";i:0;s:6:\"useSSL\";i:1;s:11:\"autoforward\";i:0;s:9:\"protected\";i:0;s:13:\"includeLayout\";i:0;s:12:\"includeCache\";i:0;s:19:\"alwaysLoadFromCache\";i:0;s:12:\"includeChmod\";i:0;s:8:\"noSearch\";i:0;s:4:\"hide\";i:0;s:9:\"published\";i:1;s:16:\"enforceTwoFactor\";i:0;s:9:\"enableCsp\";i:0;s:3:\"csp\";s:18:\"default-src \'self\'\";s:13:\"cspReportOnly\";i:0;s:12:\"cspReportLog\";i:0;s:3:\"pid\";i:1;s:7:\"sorting\";i:512;s:6:\"tstamp\";i:1708348773;s:5:\"title\";s:7:\"Kontakt\";s:4:\"type\";s:7:\"regular\";s:5:\"alias\";s:7:\"kontakt\";s:13:\"routePriority\";i:0;s:9:\"pageTitle\";s:0:\"\";s:8:\"language\";s:0:\"\";s:6:\"robots\";s:12:\"index,follow\";s:11:\"description\";N;s:8:\"redirect\";s:9:\"permanent\";s:6:\"jumpTo\";i:0;s:3:\"url\";s:0:\"\";s:3:\"dns\";s:0:\"\";s:11:\"staticFiles\";s:0:\"\";s:13:\"staticPlugins\";s:0:\"\";s:7:\"favicon\";N;s:9:\"robotsTxt\";N;s:15:\"mailerTransport\";s:0:\"\";s:13:\"canonicalLink\";s:0:\"\";s:19:\"canonicalKeepParams\";s:0:\"\";s:10:\"adminEmail\";s:0:\"\";s:10:\"dateFormat\";s:0:\"\";s:10:\"timeFormat\";s:0:\"\";s:11:\"datimFormat\";s:0:\"\";s:20:\"validAliasCharacters\";s:0:\"\";s:9:\"urlPrefix\";s:0:\"\";s:9:\"urlSuffix\";s:0:\"\";s:6:\"groups\";N;s:6:\"layout\";i:0;s:13:\"subpageLayout\";i:0;s:5:\"cache\";i:0;s:11:\"clientCache\";i:0;s:5:\"cuser\";i:0;s:6:\"cgroup\";i:0;s:5:\"chmod\";s:123:\"a:9:{i:0;s:2:\"u1\";i:1;s:2:\"u2\";i:2;s:2:\"u3\";i:3;s:2:\"u4\";i:4;s:2:\"u5\";i:5;s:2:\"u6\";i:6;s:2:\"g4\";i:7;s:2:\"g5\";i:8;s:2:\"g6\";}\";s:8:\"cssClass\";s:0:\"\";s:7:\"sitemap\";s:11:\"map_default\";s:9:\"accesskey\";s:0:\"\";s:5:\"start\";s:0:\"\";s:4:\"stop\";s:0:\"\";s:15:\"twoFactorJumpTo\";i:0;}'),(14,1,6,1708348782,1,'tl_page',1,'admin','Profil','contao?do=page&act=edit&id=6','a:68:{s:2:\"id\";i:6;s:11:\"requireItem\";i:0;s:13:\"alwaysForward\";i:0;s:12:\"redirectBack\";i:0;s:6:\"target\";i:0;s:8:\"fallback\";i:0;s:23:\"disableLanguageRedirect\";i:0;s:15:\"maintenanceMode\";i:0;s:15:\"enableCanonical\";i:1;s:12:\"useFolderUrl\";i:0;s:6:\"useSSL\";i:1;s:11:\"autoforward\";i:0;s:9:\"protected\";i:0;s:13:\"includeLayout\";i:0;s:12:\"includeCache\";i:0;s:19:\"alwaysLoadFromCache\";i:0;s:12:\"includeChmod\";i:0;s:8:\"noSearch\";i:0;s:4:\"hide\";i:0;s:9:\"published\";i:1;s:16:\"enforceTwoFactor\";i:0;s:9:\"enableCsp\";i:0;s:3:\"csp\";s:18:\"default-src \'self\'\";s:13:\"cspReportOnly\";i:0;s:12:\"cspReportLog\";i:0;s:3:\"pid\";i:3;s:7:\"sorting\";i:128;s:6:\"tstamp\";i:1708348782;s:5:\"title\";s:6:\"Profil\";s:4:\"type\";s:7:\"regular\";s:5:\"alias\";s:6:\"profil\";s:13:\"routePriority\";i:0;s:9:\"pageTitle\";s:0:\"\";s:8:\"language\";s:0:\"\";s:6:\"robots\";s:12:\"index,follow\";s:11:\"description\";N;s:8:\"redirect\";s:9:\"permanent\";s:6:\"jumpTo\";i:0;s:3:\"url\";s:0:\"\";s:3:\"dns\";s:0:\"\";s:11:\"staticFiles\";s:0:\"\";s:13:\"staticPlugins\";s:0:\"\";s:7:\"favicon\";N;s:9:\"robotsTxt\";N;s:15:\"mailerTransport\";s:0:\"\";s:13:\"canonicalLink\";s:0:\"\";s:19:\"canonicalKeepParams\";s:0:\"\";s:10:\"adminEmail\";s:0:\"\";s:10:\"dateFormat\";s:0:\"\";s:10:\"timeFormat\";s:0:\"\";s:11:\"datimFormat\";s:0:\"\";s:20:\"validAliasCharacters\";s:0:\"\";s:9:\"urlPrefix\";s:0:\"\";s:9:\"urlSuffix\";s:0:\"\";s:6:\"groups\";N;s:6:\"layout\";i:0;s:13:\"subpageLayout\";i:0;s:5:\"cache\";i:0;s:11:\"clientCache\";i:0;s:5:\"cuser\";i:0;s:6:\"cgroup\";i:0;s:5:\"chmod\";s:123:\"a:9:{i:0;s:2:\"u1\";i:1;s:2:\"u2\";i:2;s:2:\"u3\";i:3;s:2:\"u4\";i:4;s:2:\"u5\";i:5;s:2:\"u6\";i:6;s:2:\"g4\";i:7;s:2:\"g5\";i:8;s:2:\"g6\";}\";s:8:\"cssClass\";s:0:\"\";s:7:\"sitemap\";s:11:\"map_default\";s:9:\"accesskey\";s:0:\"\";s:5:\"start\";s:0:\"\";s:4:\"stop\";s:0:\"\";s:15:\"twoFactorJumpTo\";i:0;}'),(15,1,7,1708348788,1,'tl_page',1,'admin','Karriere','contao?do=page&act=edit&id=7','a:68:{s:2:\"id\";i:7;s:11:\"requireItem\";i:0;s:13:\"alwaysForward\";i:0;s:12:\"redirectBack\";i:0;s:6:\"target\";i:0;s:8:\"fallback\";i:0;s:23:\"disableLanguageRedirect\";i:0;s:15:\"maintenanceMode\";i:0;s:15:\"enableCanonical\";i:1;s:12:\"useFolderUrl\";i:0;s:6:\"useSSL\";i:1;s:11:\"autoforward\";i:0;s:9:\"protected\";i:0;s:13:\"includeLayout\";i:0;s:12:\"includeCache\";i:0;s:19:\"alwaysLoadFromCache\";i:0;s:12:\"includeChmod\";i:0;s:8:\"noSearch\";i:0;s:4:\"hide\";i:0;s:9:\"published\";i:1;s:16:\"enforceTwoFactor\";i:0;s:9:\"enableCsp\";i:0;s:3:\"csp\";s:18:\"default-src \'self\'\";s:13:\"cspReportOnly\";i:0;s:12:\"cspReportLog\";i:0;s:3:\"pid\";i:3;s:7:\"sorting\";i:256;s:6:\"tstamp\";i:1708348788;s:5:\"title\";s:8:\"Karriere\";s:4:\"type\";s:7:\"regular\";s:5:\"alias\";s:8:\"karriere\";s:13:\"routePriority\";i:0;s:9:\"pageTitle\";s:0:\"\";s:8:\"language\";s:0:\"\";s:6:\"robots\";s:12:\"index,follow\";s:11:\"description\";N;s:8:\"redirect\";s:9:\"permanent\";s:6:\"jumpTo\";i:0;s:3:\"url\";s:0:\"\";s:3:\"dns\";s:0:\"\";s:11:\"staticFiles\";s:0:\"\";s:13:\"staticPlugins\";s:0:\"\";s:7:\"favicon\";N;s:9:\"robotsTxt\";N;s:15:\"mailerTransport\";s:0:\"\";s:13:\"canonicalLink\";s:0:\"\";s:19:\"canonicalKeepParams\";s:0:\"\";s:10:\"adminEmail\";s:0:\"\";s:10:\"dateFormat\";s:0:\"\";s:10:\"timeFormat\";s:0:\"\";s:11:\"datimFormat\";s:0:\"\";s:20:\"validAliasCharacters\";s:0:\"\";s:9:\"urlPrefix\";s:0:\"\";s:9:\"urlSuffix\";s:0:\"\";s:6:\"groups\";N;s:6:\"layout\";i:0;s:13:\"subpageLayout\";i:0;s:5:\"cache\";i:0;s:11:\"clientCache\";i:0;s:5:\"cuser\";i:0;s:6:\"cgroup\";i:0;s:5:\"chmod\";s:123:\"a:9:{i:0;s:2:\"u1\";i:1;s:2:\"u2\";i:2;s:2:\"u3\";i:3;s:2:\"u4\";i:4;s:2:\"u5\";i:5;s:2:\"u6\";i:6;s:2:\"g4\";i:7;s:2:\"g5\";i:8;s:2:\"g6\";}\";s:8:\"cssClass\";s:0:\"\";s:7:\"sitemap\";s:11:\"map_default\";s:9:\"accesskey\";s:0:\"\";s:5:\"start\";s:0:\"\";s:4:\"stop\";s:0:\"\";s:15:\"twoFactorJumpTo\";i:0;}'),(16,1,1,1708348801,3,'tl_layout',1,'admin','Standard','contao?do=themes&id=1&table=tl_layout&act=edit','a:35:{s:2:\"id\";i:1;s:14:\"combineScripts\";i:1;s:12:\"minifyMarkup\";i:1;s:9:\"addJQuery\";i:0;s:11:\"addMooTools\";i:0;s:6:\"static\";i:1;s:3:\"pid\";i:1;s:6:\"tstamp\";i:1708348801;s:4:\"name\";s:8:\"Standard\";s:4:\"rows\";s:4:\"2rwh\";s:12:\"headerHeight\";s:43:\"a:2:{s:4:\"unit\";s:0:\"\";s:5:\"value\";s:0:\"\";}\";s:12:\"footerHeight\";s:0:\"\";s:4:\"cols\";s:4:\"2cll\";s:9:\"widthLeft\";s:43:\"a:2:{s:4:\"unit\";s:0:\"\";s:5:\"value\";s:0:\"\";}\";s:10:\"widthRight\";s:0:\"\";s:8:\"sections\";s:112:\"a:1:{i:0;a:4:{s:5:\"title\";s:0:\"\";s:2:\"id\";s:0:\"\";s:8:\"template\";s:13:\"block_section\";s:8:\"position\";s:3:\"top\";}}\";s:9:\"framework\";s:54:\"a:2:{i:0;s:10:\"layout.css\";i:1;s:14:\"responsive.css\";}\";s:8:\"external\";N;s:7:\"modules\";s:148:\"a:2:{i:0;a:3:{s:3:\"mod\";s:1:\"1\";s:3:\"col\";s:6:\"header\";s:6:\"enable\";s:1:\"1\";}i:1;a:3:{s:3:\"mod\";s:1:\"0\";s:3:\"col\";s:4:\"main\";s:6:\"enable\";s:1:\"1\";}}\";s:8:\"template\";s:0:\"\";s:12:\"lightboxSize\";s:39:\"a:3:{i:0;s:0:\"\";i:1;s:0:\"\";i:2;s:0:\"\";}\";s:21:\"defaultImageDensities\";s:0:\"\";s:8:\"viewport\";s:53:\"width=device-width,initial-scale=1.0,shrink-to-fit=no\";s:8:\"titleTag\";s:0:\"\";s:8:\"cssClass\";s:0:\"\";s:6:\"onload\";s:0:\"\";s:4:\"head\";N;s:6:\"jquery\";N;s:8:\"mootools\";N;s:9:\"analytics\";N;s:10:\"externalJs\";N;s:7:\"scripts\";N;s:6:\"script\";N;s:5:\"width\";s:48:\"a:2:{s:4:\"unit\";s:3:\"rem\";s:5:\"value\";s:2:\"80\";}\";s:5:\"align\";s:6:\"center\";}'),(17,1,1,1708348919,1,'tl_favorites',1,'admin','Hauptnavigation','contao?do=favorites&act=edit&id=1','a:7:{s:2:\"id\";i:1;s:3:\"pid\";i:0;s:7:\"sorting\";i:128;s:6:\"tstamp\";i:1708348919;s:4:\"user\";i:1;s:5:\"title\";s:15:\"Hauptnavigation\";s:3:\"url\";s:47:\"/contao?act=edit&do=themes&id=1&table=tl_module\";}'),(18,0,1,1708348925,3,'tl_module',1,'admin','Navigation','contao?act=edit&do=themes&id=1&table=tl_module','a:87:{s:2:\"id\";i:1;s:9:\"hardLimit\";i:0;s:13:\"showProtected\";i:0;s:10:\"defineRoot\";i:0;s:10:\"showHidden\";i:0;s:9:\"autologin\";i:0;s:12:\"redirectBack\";i:0;s:5:\"fuzzy\";i:0;s:9:\"loadFirst\";i:0;s:10:\"useCaption\";i:0;s:8:\"fullsize\";i:0;s:14:\"disableCaptcha\";i:0;s:14:\"reg_allowLogin\";i:0;s:12:\"reg_skipName\";i:0;s:13:\"reg_deleteDir\";i:0;s:13:\"reg_assignDir\";i:0;s:12:\"reg_activate\";i:0;s:9:\"protected\";i:0;s:22:\"hofff_navigation_roots\";N;s:28:\"hofff_navigation_roots_order\";N;s:22:\"hofff_navigation_start\";i:0;s:30:\"hofff_navigation_respectHidden\";s:0:\"\";s:31:\"hofff_navigation_respectPublish\";s:0:\"\";s:30:\"hofff_navigation_respectGuests\";s:0:\"\";s:29:\"hofff_navigation_includeStart\";s:0:\"\";s:32:\"hofff_navigation_showHiddenStart\";s:0:\"\";s:27:\"hofff_navigation_showHidden\";s:0:\"\";s:30:\"hofff_navigation_showProtected\";s:0:\"\";s:27:\"hofff_navigation_showGuests\";s:0:\"\";s:26:\"hofff_navigation_addFields\";N;s:36:\"hofff_navigation_noForwardResolution\";s:0:\"\";s:31:\"hofff_navigation_showErrorPages\";s:0:\"\";s:30:\"hofff_navigation_disableEvents\";s:0:\"\";s:30:\"hofff_navigation_currentAsRoot\";s:0:\"\";s:28:\"hofff_navigation_defineRoots\";s:1:\"1\";s:27:\"hofff_navigation_defineStop\";s:0:\"\";s:21:\"hofff_navigation_stop\";s:0:\"\";s:27:\"hofff_navigation_defineHard\";s:0:\"\";s:21:\"hofff_navigation_hard\";i:0;s:26:\"hofff_navigation_isSitemap\";s:0:\"\";s:32:\"hofff_navigation_hideSingleLevel\";s:0:\"\";s:29:\"hofff_navigation_addLegacyCss\";s:0:\"\";s:3:\"pid\";i:1;s:6:\"tstamp\";i:1708348925;s:4:\"name\";s:10:\"Navigation\";s:8:\"headline\";s:45:\"a:2:{s:4:\"unit\";s:2:\"h2\";s:5:\"value\";s:0:\"\";}\";s:4:\"type\";s:21:\"hofff_navigation_menu\";s:11:\"levelOffset\";i:0;s:9:\"showLevel\";i:0;s:8:\"rootPage\";i:0;s:13:\"navigationTpl\";s:0:\"\";s:9:\"customTpl\";s:0:\"\";s:5:\"pages\";N;s:11:\"customLabel\";s:0:\"\";s:6:\"jumpTo\";i:0;s:12:\"overviewPage\";i:0;s:11:\"pwResetPage\";i:0;s:8:\"editable\";N;s:9:\"memberTpl\";s:0:\"\";s:4:\"form\";i:0;s:9:\"queryType\";s:3:\"and\";s:13:\"contextLength\";s:0:\"\";s:16:\"minKeywordLength\";i:4;s:7:\"perPage\";i:0;s:10:\"searchType\";s:6:\"simple\";s:9:\"searchTpl\";s:0:\"\";s:8:\"inColumn\";s:4:\"main\";s:9:\"skipFirst\";i:0;s:9:\"singleSRC\";N;s:7:\"imgSize\";s:0:\"\";s:8:\"multiSRC\";N;s:4:\"html\";N;s:14:\"unfilteredHtml\";N;s:9:\"rss_cache\";i:3600;s:8:\"rss_feed\";N;s:12:\"rss_template\";s:0:\"\";s:13:\"numberOfItems\";i:3;s:10:\"reg_groups\";N;s:9:\"reg_close\";s:0:\"\";s:11:\"reg_homeDir\";N;s:10:\"reg_jumpTo\";i:0;s:8:\"reg_text\";N;s:12:\"reg_password\";N;s:4:\"data\";N;s:6:\"groups\";N;s:5:\"cssID\";s:28:\"a:2:{i:0;s:0:\"\";i:1;s:0:\"\";}\";s:24:\"rootPageDependentModules\";N;}'),(19,0,1,1708348926,4,'tl_module',1,'admin','Navigation','contao?act=edit&do=themes&id=1&table=tl_module','a:87:{s:2:\"id\";i:1;s:9:\"hardLimit\";i:0;s:13:\"showProtected\";i:0;s:10:\"defineRoot\";i:0;s:10:\"showHidden\";i:0;s:9:\"autologin\";i:0;s:12:\"redirectBack\";i:0;s:5:\"fuzzy\";i:0;s:9:\"loadFirst\";i:0;s:10:\"useCaption\";i:0;s:8:\"fullsize\";i:0;s:14:\"disableCaptcha\";i:0;s:14:\"reg_allowLogin\";i:0;s:12:\"reg_skipName\";i:0;s:13:\"reg_deleteDir\";i:0;s:13:\"reg_assignDir\";i:0;s:12:\"reg_activate\";i:0;s:9:\"protected\";i:0;s:22:\"hofff_navigation_roots\";N;s:28:\"hofff_navigation_roots_order\";N;s:22:\"hofff_navigation_start\";i:0;s:30:\"hofff_navigation_respectHidden\";s:0:\"\";s:31:\"hofff_navigation_respectPublish\";s:0:\"\";s:30:\"hofff_navigation_respectGuests\";s:0:\"\";s:29:\"hofff_navigation_includeStart\";s:0:\"\";s:32:\"hofff_navigation_showHiddenStart\";s:0:\"\";s:27:\"hofff_navigation_showHidden\";s:0:\"\";s:30:\"hofff_navigation_showProtected\";s:0:\"\";s:27:\"hofff_navigation_showGuests\";s:0:\"\";s:26:\"hofff_navigation_addFields\";N;s:36:\"hofff_navigation_noForwardResolution\";s:0:\"\";s:31:\"hofff_navigation_showErrorPages\";s:0:\"\";s:30:\"hofff_navigation_disableEvents\";s:0:\"\";s:30:\"hofff_navigation_currentAsRoot\";s:0:\"\";s:28:\"hofff_navigation_defineRoots\";s:0:\"\";s:27:\"hofff_navigation_defineStop\";s:0:\"\";s:21:\"hofff_navigation_stop\";s:0:\"\";s:27:\"hofff_navigation_defineHard\";s:0:\"\";s:21:\"hofff_navigation_hard\";i:0;s:26:\"hofff_navigation_isSitemap\";s:0:\"\";s:32:\"hofff_navigation_hideSingleLevel\";s:0:\"\";s:29:\"hofff_navigation_addLegacyCss\";s:0:\"\";s:3:\"pid\";i:1;s:6:\"tstamp\";i:1708348926;s:4:\"name\";s:10:\"Navigation\";s:8:\"headline\";s:45:\"a:2:{s:4:\"unit\";s:2:\"h2\";s:5:\"value\";s:0:\"\";}\";s:4:\"type\";s:21:\"hofff_navigation_menu\";s:11:\"levelOffset\";i:0;s:9:\"showLevel\";i:0;s:8:\"rootPage\";i:0;s:13:\"navigationTpl\";s:0:\"\";s:9:\"customTpl\";s:0:\"\";s:5:\"pages\";N;s:11:\"customLabel\";s:0:\"\";s:6:\"jumpTo\";i:0;s:12:\"overviewPage\";i:0;s:11:\"pwResetPage\";i:0;s:8:\"editable\";N;s:9:\"memberTpl\";s:0:\"\";s:4:\"form\";i:0;s:9:\"queryType\";s:3:\"and\";s:13:\"contextLength\";s:0:\"\";s:16:\"minKeywordLength\";i:4;s:7:\"perPage\";i:0;s:10:\"searchType\";s:6:\"simple\";s:9:\"searchTpl\";s:0:\"\";s:8:\"inColumn\";s:4:\"main\";s:9:\"skipFirst\";i:0;s:9:\"singleSRC\";N;s:7:\"imgSize\";s:0:\"\";s:8:\"multiSRC\";N;s:4:\"html\";N;s:14:\"unfilteredHtml\";N;s:9:\"rss_cache\";i:3600;s:8:\"rss_feed\";N;s:12:\"rss_template\";s:0:\"\";s:13:\"numberOfItems\";i:3;s:10:\"reg_groups\";N;s:9:\"reg_close\";s:0:\"\";s:11:\"reg_homeDir\";N;s:10:\"reg_jumpTo\";i:0;s:8:\"reg_text\";N;s:12:\"reg_password\";N;s:4:\"data\";N;s:6:\"groups\";N;s:5:\"cssID\";s:28:\"a:2:{i:0;s:0:\"\";i:1;s:0:\"\";}\";s:24:\"rootPageDependentModules\";N;}'),(20,0,1,1708348927,5,'tl_module',1,'admin','Navigation','contao?act=edit&do=themes&id=1&table=tl_module','a:87:{s:2:\"id\";i:1;s:9:\"hardLimit\";i:0;s:13:\"showProtected\";i:0;s:10:\"defineRoot\";i:0;s:10:\"showHidden\";i:0;s:9:\"autologin\";i:0;s:12:\"redirectBack\";i:0;s:5:\"fuzzy\";i:0;s:9:\"loadFirst\";i:0;s:10:\"useCaption\";i:0;s:8:\"fullsize\";i:0;s:14:\"disableCaptcha\";i:0;s:14:\"reg_allowLogin\";i:0;s:12:\"reg_skipName\";i:0;s:13:\"reg_deleteDir\";i:0;s:13:\"reg_assignDir\";i:0;s:12:\"reg_activate\";i:0;s:9:\"protected\";i:0;s:22:\"hofff_navigation_roots\";N;s:28:\"hofff_navigation_roots_order\";N;s:22:\"hofff_navigation_start\";i:0;s:30:\"hofff_navigation_respectHidden\";s:0:\"\";s:31:\"hofff_navigation_respectPublish\";s:0:\"\";s:30:\"hofff_navigation_respectGuests\";s:0:\"\";s:29:\"hofff_navigation_includeStart\";s:0:\"\";s:32:\"hofff_navigation_showHiddenStart\";s:0:\"\";s:27:\"hofff_navigation_showHidden\";s:0:\"\";s:30:\"hofff_navigation_showProtected\";s:0:\"\";s:27:\"hofff_navigation_showGuests\";s:0:\"\";s:26:\"hofff_navigation_addFields\";N;s:36:\"hofff_navigation_noForwardResolution\";s:0:\"\";s:31:\"hofff_navigation_showErrorPages\";s:0:\"\";s:30:\"hofff_navigation_disableEvents\";s:0:\"\";s:30:\"hofff_navigation_currentAsRoot\";s:0:\"\";s:28:\"hofff_navigation_defineRoots\";s:1:\"1\";s:27:\"hofff_navigation_defineStop\";s:0:\"\";s:21:\"hofff_navigation_stop\";s:0:\"\";s:27:\"hofff_navigation_defineHard\";s:0:\"\";s:21:\"hofff_navigation_hard\";i:0;s:26:\"hofff_navigation_isSitemap\";s:0:\"\";s:32:\"hofff_navigation_hideSingleLevel\";s:0:\"\";s:29:\"hofff_navigation_addLegacyCss\";s:0:\"\";s:3:\"pid\";i:1;s:6:\"tstamp\";i:1708348927;s:4:\"name\";s:10:\"Navigation\";s:8:\"headline\";s:45:\"a:2:{s:4:\"unit\";s:2:\"h2\";s:5:\"value\";s:0:\"\";}\";s:4:\"type\";s:21:\"hofff_navigation_menu\";s:11:\"levelOffset\";i:0;s:9:\"showLevel\";i:0;s:8:\"rootPage\";i:0;s:13:\"navigationTpl\";s:0:\"\";s:9:\"customTpl\";s:0:\"\";s:5:\"pages\";N;s:11:\"customLabel\";s:0:\"\";s:6:\"jumpTo\";i:0;s:12:\"overviewPage\";i:0;s:11:\"pwResetPage\";i:0;s:8:\"editable\";N;s:9:\"memberTpl\";s:0:\"\";s:4:\"form\";i:0;s:9:\"queryType\";s:3:\"and\";s:13:\"contextLength\";s:0:\"\";s:16:\"minKeywordLength\";i:4;s:7:\"perPage\";i:0;s:10:\"searchType\";s:6:\"simple\";s:9:\"searchTpl\";s:0:\"\";s:8:\"inColumn\";s:4:\"main\";s:9:\"skipFirst\";i:0;s:9:\"singleSRC\";N;s:7:\"imgSize\";s:0:\"\";s:8:\"multiSRC\";N;s:4:\"html\";N;s:14:\"unfilteredHtml\";N;s:9:\"rss_cache\";i:3600;s:8:\"rss_feed\";N;s:12:\"rss_template\";s:0:\"\";s:13:\"numberOfItems\";i:3;s:10:\"reg_groups\";N;s:9:\"reg_close\";s:0:\"\";s:11:\"reg_homeDir\";N;s:10:\"reg_jumpTo\";i:0;s:8:\"reg_text\";N;s:12:\"reg_password\";N;s:4:\"data\";N;s:6:\"groups\";N;s:5:\"cssID\";s:28:\"a:2:{i:0;s:0:\"\";i:1;s:0:\"\";}\";s:24:\"rootPageDependentModules\";N;}'),(21,0,1,1708348927,6,'tl_module',1,'admin','Navigation','contao?act=edit&do=themes&id=1&table=tl_module','a:87:{s:2:\"id\";i:1;s:9:\"hardLimit\";i:0;s:13:\"showProtected\";i:0;s:10:\"defineRoot\";i:0;s:10:\"showHidden\";i:0;s:9:\"autologin\";i:0;s:12:\"redirectBack\";i:0;s:5:\"fuzzy\";i:0;s:9:\"loadFirst\";i:0;s:10:\"useCaption\";i:0;s:8:\"fullsize\";i:0;s:14:\"disableCaptcha\";i:0;s:14:\"reg_allowLogin\";i:0;s:12:\"reg_skipName\";i:0;s:13:\"reg_deleteDir\";i:0;s:13:\"reg_assignDir\";i:0;s:12:\"reg_activate\";i:0;s:9:\"protected\";i:0;s:22:\"hofff_navigation_roots\";N;s:28:\"hofff_navigation_roots_order\";N;s:22:\"hofff_navigation_start\";i:0;s:30:\"hofff_navigation_respectHidden\";s:0:\"\";s:31:\"hofff_navigation_respectPublish\";s:0:\"\";s:30:\"hofff_navigation_respectGuests\";s:0:\"\";s:29:\"hofff_navigation_includeStart\";s:0:\"\";s:32:\"hofff_navigation_showHiddenStart\";s:0:\"\";s:27:\"hofff_navigation_showHidden\";s:0:\"\";s:30:\"hofff_navigation_showProtected\";s:0:\"\";s:27:\"hofff_navigation_showGuests\";s:0:\"\";s:26:\"hofff_navigation_addFields\";N;s:36:\"hofff_navigation_noForwardResolution\";s:0:\"\";s:31:\"hofff_navigation_showErrorPages\";s:0:\"\";s:30:\"hofff_navigation_disableEvents\";s:0:\"\";s:30:\"hofff_navigation_currentAsRoot\";s:0:\"\";s:28:\"hofff_navigation_defineRoots\";s:0:\"\";s:27:\"hofff_navigation_defineStop\";s:0:\"\";s:21:\"hofff_navigation_stop\";s:0:\"\";s:27:\"hofff_navigation_defineHard\";s:0:\"\";s:21:\"hofff_navigation_hard\";i:0;s:26:\"hofff_navigation_isSitemap\";s:0:\"\";s:32:\"hofff_navigation_hideSingleLevel\";s:0:\"\";s:29:\"hofff_navigation_addLegacyCss\";s:0:\"\";s:3:\"pid\";i:1;s:6:\"tstamp\";i:1708348927;s:4:\"name\";s:10:\"Navigation\";s:8:\"headline\";s:45:\"a:2:{s:4:\"unit\";s:2:\"h2\";s:5:\"value\";s:0:\"\";}\";s:4:\"type\";s:21:\"hofff_navigation_menu\";s:11:\"levelOffset\";i:0;s:9:\"showLevel\";i:0;s:8:\"rootPage\";i:0;s:13:\"navigationTpl\";s:0:\"\";s:9:\"customTpl\";s:0:\"\";s:5:\"pages\";N;s:11:\"customLabel\";s:0:\"\";s:6:\"jumpTo\";i:0;s:12:\"overviewPage\";i:0;s:11:\"pwResetPage\";i:0;s:8:\"editable\";N;s:9:\"memberTpl\";s:0:\"\";s:4:\"form\";i:0;s:9:\"queryType\";s:3:\"and\";s:13:\"contextLength\";s:0:\"\";s:16:\"minKeywordLength\";i:4;s:7:\"perPage\";i:0;s:10:\"searchType\";s:6:\"simple\";s:9:\"searchTpl\";s:0:\"\";s:8:\"inColumn\";s:4:\"main\";s:9:\"skipFirst\";i:0;s:9:\"singleSRC\";N;s:7:\"imgSize\";s:0:\"\";s:8:\"multiSRC\";N;s:4:\"html\";N;s:14:\"unfilteredHtml\";N;s:9:\"rss_cache\";i:3600;s:8:\"rss_feed\";N;s:12:\"rss_template\";s:0:\"\";s:13:\"numberOfItems\";i:3;s:10:\"reg_groups\";N;s:9:\"reg_close\";s:0:\"\";s:11:\"reg_homeDir\";N;s:10:\"reg_jumpTo\";i:0;s:8:\"reg_text\";N;s:12:\"reg_password\";N;s:4:\"data\";N;s:6:\"groups\";N;s:5:\"cssID\";s:28:\"a:2:{i:0;s:0:\"\";i:1;s:0:\"\";}\";s:24:\"rootPageDependentModules\";N;}'),(22,0,1,1708348928,7,'tl_module',1,'admin','Navigation','contao?act=edit&do=themes&id=1&table=tl_module','a:87:{s:2:\"id\";i:1;s:9:\"hardLimit\";i:0;s:13:\"showProtected\";i:0;s:10:\"defineRoot\";i:0;s:10:\"showHidden\";i:0;s:9:\"autologin\";i:0;s:12:\"redirectBack\";i:0;s:5:\"fuzzy\";i:0;s:9:\"loadFirst\";i:0;s:10:\"useCaption\";i:0;s:8:\"fullsize\";i:0;s:14:\"disableCaptcha\";i:0;s:14:\"reg_allowLogin\";i:0;s:12:\"reg_skipName\";i:0;s:13:\"reg_deleteDir\";i:0;s:13:\"reg_assignDir\";i:0;s:12:\"reg_activate\";i:0;s:9:\"protected\";i:0;s:22:\"hofff_navigation_roots\";N;s:28:\"hofff_navigation_roots_order\";N;s:22:\"hofff_navigation_start\";i:0;s:30:\"hofff_navigation_respectHidden\";s:0:\"\";s:31:\"hofff_navigation_respectPublish\";s:0:\"\";s:30:\"hofff_navigation_respectGuests\";s:0:\"\";s:29:\"hofff_navigation_includeStart\";s:0:\"\";s:32:\"hofff_navigation_showHiddenStart\";s:0:\"\";s:27:\"hofff_navigation_showHidden\";s:0:\"\";s:30:\"hofff_navigation_showProtected\";s:0:\"\";s:27:\"hofff_navigation_showGuests\";s:0:\"\";s:26:\"hofff_navigation_addFields\";N;s:36:\"hofff_navigation_noForwardResolution\";s:0:\"\";s:31:\"hofff_navigation_showErrorPages\";s:0:\"\";s:30:\"hofff_navigation_disableEvents\";s:0:\"\";s:30:\"hofff_navigation_currentAsRoot\";s:0:\"\";s:28:\"hofff_navigation_defineRoots\";s:1:\"1\";s:27:\"hofff_navigation_defineStop\";s:0:\"\";s:21:\"hofff_navigation_stop\";s:0:\"\";s:27:\"hofff_navigation_defineHard\";s:0:\"\";s:21:\"hofff_navigation_hard\";i:0;s:26:\"hofff_navigation_isSitemap\";s:0:\"\";s:32:\"hofff_navigation_hideSingleLevel\";s:0:\"\";s:29:\"hofff_navigation_addLegacyCss\";s:0:\"\";s:3:\"pid\";i:1;s:6:\"tstamp\";i:1708348928;s:4:\"name\";s:10:\"Navigation\";s:8:\"headline\";s:45:\"a:2:{s:4:\"unit\";s:2:\"h2\";s:5:\"value\";s:0:\"\";}\";s:4:\"type\";s:21:\"hofff_navigation_menu\";s:11:\"levelOffset\";i:0;s:9:\"showLevel\";i:0;s:8:\"rootPage\";i:0;s:13:\"navigationTpl\";s:0:\"\";s:9:\"customTpl\";s:0:\"\";s:5:\"pages\";N;s:11:\"customLabel\";s:0:\"\";s:6:\"jumpTo\";i:0;s:12:\"overviewPage\";i:0;s:11:\"pwResetPage\";i:0;s:8:\"editable\";N;s:9:\"memberTpl\";s:0:\"\";s:4:\"form\";i:0;s:9:\"queryType\";s:3:\"and\";s:13:\"contextLength\";s:0:\"\";s:16:\"minKeywordLength\";i:4;s:7:\"perPage\";i:0;s:10:\"searchType\";s:6:\"simple\";s:9:\"searchTpl\";s:0:\"\";s:8:\"inColumn\";s:4:\"main\";s:9:\"skipFirst\";i:0;s:9:\"singleSRC\";N;s:7:\"imgSize\";s:0:\"\";s:8:\"multiSRC\";N;s:4:\"html\";N;s:14:\"unfilteredHtml\";N;s:9:\"rss_cache\";i:3600;s:8:\"rss_feed\";N;s:12:\"rss_template\";s:0:\"\";s:13:\"numberOfItems\";i:3;s:10:\"reg_groups\";N;s:9:\"reg_close\";s:0:\"\";s:11:\"reg_homeDir\";N;s:10:\"reg_jumpTo\";i:0;s:8:\"reg_text\";N;s:12:\"reg_password\";N;s:4:\"data\";N;s:6:\"groups\";N;s:5:\"cssID\";s:28:\"a:2:{i:0;s:0:\"\";i:1;s:0:\"\";}\";s:24:\"rootPageDependentModules\";N;}'),(23,0,1,1708348930,8,'tl_module',1,'admin','Navigation','contao?act=edit&do=themes&id=1&table=tl_module','a:87:{s:2:\"id\";i:1;s:9:\"hardLimit\";i:0;s:13:\"showProtected\";i:0;s:10:\"defineRoot\";i:0;s:10:\"showHidden\";i:0;s:9:\"autologin\";i:0;s:12:\"redirectBack\";i:0;s:5:\"fuzzy\";i:0;s:9:\"loadFirst\";i:0;s:10:\"useCaption\";i:0;s:8:\"fullsize\";i:0;s:14:\"disableCaptcha\";i:0;s:14:\"reg_allowLogin\";i:0;s:12:\"reg_skipName\";i:0;s:13:\"reg_deleteDir\";i:0;s:13:\"reg_assignDir\";i:0;s:12:\"reg_activate\";i:0;s:9:\"protected\";i:0;s:22:\"hofff_navigation_roots\";N;s:28:\"hofff_navigation_roots_order\";N;s:22:\"hofff_navigation_start\";i:0;s:30:\"hofff_navigation_respectHidden\";s:0:\"\";s:31:\"hofff_navigation_respectPublish\";s:0:\"\";s:30:\"hofff_navigation_respectGuests\";s:0:\"\";s:29:\"hofff_navigation_includeStart\";s:0:\"\";s:32:\"hofff_navigation_showHiddenStart\";s:0:\"\";s:27:\"hofff_navigation_showHidden\";s:0:\"\";s:30:\"hofff_navigation_showProtected\";s:0:\"\";s:27:\"hofff_navigation_showGuests\";s:0:\"\";s:26:\"hofff_navigation_addFields\";N;s:36:\"hofff_navigation_noForwardResolution\";s:0:\"\";s:31:\"hofff_navigation_showErrorPages\";s:0:\"\";s:30:\"hofff_navigation_disableEvents\";s:0:\"\";s:30:\"hofff_navigation_currentAsRoot\";s:0:\"\";s:28:\"hofff_navigation_defineRoots\";s:1:\"1\";s:27:\"hofff_navigation_defineStop\";s:0:\"\";s:21:\"hofff_navigation_stop\";s:0:\"\";s:27:\"hofff_navigation_defineHard\";s:0:\"\";s:21:\"hofff_navigation_hard\";i:0;s:26:\"hofff_navigation_isSitemap\";s:0:\"\";s:32:\"hofff_navigation_hideSingleLevel\";s:0:\"\";s:29:\"hofff_navigation_addLegacyCss\";s:0:\"\";s:3:\"pid\";i:1;s:6:\"tstamp\";i:1708348930;s:4:\"name\";s:10:\"Navigation\";s:8:\"headline\";s:45:\"a:2:{s:4:\"unit\";s:2:\"h2\";s:5:\"value\";s:0:\"\";}\";s:4:\"type\";s:21:\"hofff_navigation_menu\";s:11:\"levelOffset\";i:0;s:9:\"showLevel\";i:0;s:8:\"rootPage\";i:0;s:13:\"navigationTpl\";s:0:\"\";s:9:\"customTpl\";s:0:\"\";s:5:\"pages\";N;s:11:\"customLabel\";s:0:\"\";s:6:\"jumpTo\";i:0;s:12:\"overviewPage\";i:0;s:11:\"pwResetPage\";i:0;s:8:\"editable\";N;s:9:\"memberTpl\";s:0:\"\";s:4:\"form\";i:0;s:9:\"queryType\";s:3:\"and\";s:13:\"contextLength\";s:0:\"\";s:16:\"minKeywordLength\";i:4;s:7:\"perPage\";i:0;s:10:\"searchType\";s:6:\"simple\";s:9:\"searchTpl\";s:0:\"\";s:8:\"inColumn\";s:4:\"main\";s:9:\"skipFirst\";i:0;s:9:\"singleSRC\";N;s:7:\"imgSize\";s:0:\"\";s:8:\"multiSRC\";N;s:4:\"html\";N;s:14:\"unfilteredHtml\";N;s:9:\"rss_cache\";i:3600;s:8:\"rss_feed\";N;s:12:\"rss_template\";s:0:\"\";s:13:\"numberOfItems\";i:3;s:10:\"reg_groups\";N;s:9:\"reg_close\";s:0:\"\";s:11:\"reg_homeDir\";N;s:10:\"reg_jumpTo\";i:0;s:8:\"reg_text\";N;s:12:\"reg_password\";N;s:4:\"data\";N;s:6:\"groups\";N;s:5:\"cssID\";s:28:\"a:2:{i:0;s:0:\"\";i:1;s:0:\"\";}\";s:24:\"rootPageDependentModules\";N;}'),(24,0,1,1708348938,9,'tl_module',1,'admin','Navigation','contao?act=edit&do=themes&id=1&table=tl_module','a:87:{s:2:\"id\";i:1;s:9:\"hardLimit\";i:0;s:13:\"showProtected\";i:0;s:10:\"defineRoot\";i:0;s:10:\"showHidden\";i:0;s:9:\"autologin\";i:0;s:12:\"redirectBack\";i:0;s:5:\"fuzzy\";i:0;s:9:\"loadFirst\";i:0;s:10:\"useCaption\";i:0;s:8:\"fullsize\";i:0;s:14:\"disableCaptcha\";i:0;s:14:\"reg_allowLogin\";i:0;s:12:\"reg_skipName\";i:0;s:13:\"reg_deleteDir\";i:0;s:13:\"reg_assignDir\";i:0;s:12:\"reg_activate\";i:0;s:9:\"protected\";i:0;s:22:\"hofff_navigation_roots\";s:14:\"a:1:{i:0;i:1;}\";s:28:\"hofff_navigation_roots_order\";N;s:22:\"hofff_navigation_start\";i:0;s:30:\"hofff_navigation_respectHidden\";s:0:\"\";s:31:\"hofff_navigation_respectPublish\";s:0:\"\";s:30:\"hofff_navigation_respectGuests\";s:0:\"\";s:29:\"hofff_navigation_includeStart\";s:0:\"\";s:32:\"hofff_navigation_showHiddenStart\";s:0:\"\";s:27:\"hofff_navigation_showHidden\";s:0:\"\";s:30:\"hofff_navigation_showProtected\";s:0:\"\";s:27:\"hofff_navigation_showGuests\";s:0:\"\";s:26:\"hofff_navigation_addFields\";N;s:36:\"hofff_navigation_noForwardResolution\";s:0:\"\";s:31:\"hofff_navigation_showErrorPages\";s:0:\"\";s:30:\"hofff_navigation_disableEvents\";s:0:\"\";s:30:\"hofff_navigation_currentAsRoot\";s:0:\"\";s:28:\"hofff_navigation_defineRoots\";s:1:\"1\";s:27:\"hofff_navigation_defineStop\";s:0:\"\";s:21:\"hofff_navigation_stop\";s:0:\"\";s:27:\"hofff_navigation_defineHard\";s:0:\"\";s:21:\"hofff_navigation_hard\";i:0;s:26:\"hofff_navigation_isSitemap\";s:0:\"\";s:32:\"hofff_navigation_hideSingleLevel\";s:0:\"\";s:29:\"hofff_navigation_addLegacyCss\";s:0:\"\";s:3:\"pid\";i:1;s:6:\"tstamp\";i:1708348938;s:4:\"name\";s:10:\"Navigation\";s:8:\"headline\";s:45:\"a:2:{s:4:\"unit\";s:2:\"h2\";s:5:\"value\";s:0:\"\";}\";s:4:\"type\";s:21:\"hofff_navigation_menu\";s:11:\"levelOffset\";i:0;s:9:\"showLevel\";i:0;s:8:\"rootPage\";i:0;s:13:\"navigationTpl\";s:0:\"\";s:9:\"customTpl\";s:0:\"\";s:5:\"pages\";N;s:11:\"customLabel\";s:0:\"\";s:6:\"jumpTo\";i:0;s:12:\"overviewPage\";i:0;s:11:\"pwResetPage\";i:0;s:8:\"editable\";N;s:9:\"memberTpl\";s:0:\"\";s:4:\"form\";i:0;s:9:\"queryType\";s:3:\"and\";s:13:\"contextLength\";s:0:\"\";s:16:\"minKeywordLength\";i:4;s:7:\"perPage\";i:0;s:10:\"searchType\";s:6:\"simple\";s:9:\"searchTpl\";s:0:\"\";s:8:\"inColumn\";s:4:\"main\";s:9:\"skipFirst\";i:0;s:9:\"singleSRC\";N;s:7:\"imgSize\";s:0:\"\";s:8:\"multiSRC\";N;s:4:\"html\";N;s:14:\"unfilteredHtml\";N;s:9:\"rss_cache\";i:3600;s:8:\"rss_feed\";N;s:12:\"rss_template\";s:0:\"\";s:13:\"numberOfItems\";i:3;s:10:\"reg_groups\";N;s:9:\"reg_close\";s:0:\"\";s:11:\"reg_homeDir\";N;s:10:\"reg_jumpTo\";i:0;s:8:\"reg_text\";N;s:12:\"reg_password\";N;s:4:\"data\";N;s:6:\"groups\";N;s:5:\"cssID\";s:28:\"a:2:{i:0;s:0:\"\";i:1;s:0:\"\";}\";s:24:\"rootPageDependentModules\";N;}'),(25,0,1,1708348951,10,'tl_module',1,'admin','Navigation','contao?act=edit&do=themes&id=1&table=tl_module','a:87:{s:2:\"id\";i:1;s:9:\"hardLimit\";i:0;s:13:\"showProtected\";i:0;s:10:\"defineRoot\";i:0;s:10:\"showHidden\";i:0;s:9:\"autologin\";i:0;s:12:\"redirectBack\";i:0;s:5:\"fuzzy\";i:0;s:9:\"loadFirst\";i:0;s:10:\"useCaption\";i:0;s:8:\"fullsize\";i:0;s:14:\"disableCaptcha\";i:0;s:14:\"reg_allowLogin\";i:0;s:12:\"reg_skipName\";i:0;s:13:\"reg_deleteDir\";i:0;s:13:\"reg_assignDir\";i:0;s:12:\"reg_activate\";i:0;s:9:\"protected\";i:0;s:22:\"hofff_navigation_roots\";s:14:\"a:1:{i:0;i:1;}\";s:28:\"hofff_navigation_roots_order\";N;s:22:\"hofff_navigation_start\";i:0;s:30:\"hofff_navigation_respectHidden\";s:0:\"\";s:31:\"hofff_navigation_respectPublish\";s:0:\"\";s:30:\"hofff_navigation_respectGuests\";s:0:\"\";s:29:\"hofff_navigation_includeStart\";s:1:\"1\";s:32:\"hofff_navigation_showHiddenStart\";s:0:\"\";s:27:\"hofff_navigation_showHidden\";s:0:\"\";s:30:\"hofff_navigation_showProtected\";s:0:\"\";s:27:\"hofff_navigation_showGuests\";s:0:\"\";s:26:\"hofff_navigation_addFields\";N;s:36:\"hofff_navigation_noForwardResolution\";s:0:\"\";s:31:\"hofff_navigation_showErrorPages\";s:0:\"\";s:30:\"hofff_navigation_disableEvents\";s:0:\"\";s:30:\"hofff_navigation_currentAsRoot\";s:0:\"\";s:28:\"hofff_navigation_defineRoots\";s:1:\"1\";s:27:\"hofff_navigation_defineStop\";s:0:\"\";s:21:\"hofff_navigation_stop\";s:0:\"\";s:27:\"hofff_navigation_defineHard\";s:0:\"\";s:21:\"hofff_navigation_hard\";i:0;s:26:\"hofff_navigation_isSitemap\";s:0:\"\";s:32:\"hofff_navigation_hideSingleLevel\";s:0:\"\";s:29:\"hofff_navigation_addLegacyCss\";s:0:\"\";s:3:\"pid\";i:1;s:6:\"tstamp\";i:1708348951;s:4:\"name\";s:10:\"Navigation\";s:8:\"headline\";s:45:\"a:2:{s:4:\"unit\";s:2:\"h2\";s:5:\"value\";s:0:\"\";}\";s:4:\"type\";s:21:\"hofff_navigation_menu\";s:11:\"levelOffset\";i:0;s:9:\"showLevel\";i:0;s:8:\"rootPage\";i:0;s:13:\"navigationTpl\";s:0:\"\";s:9:\"customTpl\";s:0:\"\";s:5:\"pages\";N;s:11:\"customLabel\";s:0:\"\";s:6:\"jumpTo\";i:0;s:12:\"overviewPage\";i:0;s:11:\"pwResetPage\";i:0;s:8:\"editable\";N;s:9:\"memberTpl\";s:0:\"\";s:4:\"form\";i:0;s:9:\"queryType\";s:3:\"and\";s:13:\"contextLength\";s:0:\"\";s:16:\"minKeywordLength\";i:4;s:7:\"perPage\";i:0;s:10:\"searchType\";s:6:\"simple\";s:9:\"searchTpl\";s:0:\"\";s:8:\"inColumn\";s:4:\"main\";s:9:\"skipFirst\";i:0;s:9:\"singleSRC\";N;s:7:\"imgSize\";s:0:\"\";s:8:\"multiSRC\";N;s:4:\"html\";N;s:14:\"unfilteredHtml\";N;s:9:\"rss_cache\";i:3600;s:8:\"rss_feed\";N;s:12:\"rss_template\";s:0:\"\";s:13:\"numberOfItems\";i:3;s:10:\"reg_groups\";N;s:9:\"reg_close\";s:0:\"\";s:11:\"reg_homeDir\";N;s:10:\"reg_jumpTo\";i:0;s:8:\"reg_text\";N;s:12:\"reg_password\";N;s:4:\"data\";N;s:6:\"groups\";N;s:5:\"cssID\";s:28:\"a:2:{i:0;s:0:\"\";i:1;s:0:\"\";}\";s:24:\"rootPageDependentModules\";N;}'),(26,0,1,1708348952,11,'tl_module',1,'admin','Navigation','contao?act=edit&do=themes&id=1&table=tl_module','a:87:{s:2:\"id\";i:1;s:9:\"hardLimit\";i:0;s:13:\"showProtected\";i:0;s:10:\"defineRoot\";i:0;s:10:\"showHidden\";i:0;s:9:\"autologin\";i:0;s:12:\"redirectBack\";i:0;s:5:\"fuzzy\";i:0;s:9:\"loadFirst\";i:0;s:10:\"useCaption\";i:0;s:8:\"fullsize\";i:0;s:14:\"disableCaptcha\";i:0;s:14:\"reg_allowLogin\";i:0;s:12:\"reg_skipName\";i:0;s:13:\"reg_deleteDir\";i:0;s:13:\"reg_assignDir\";i:0;s:12:\"reg_activate\";i:0;s:9:\"protected\";i:0;s:22:\"hofff_navigation_roots\";s:14:\"a:1:{i:0;i:1;}\";s:28:\"hofff_navigation_roots_order\";N;s:22:\"hofff_navigation_start\";i:0;s:30:\"hofff_navigation_respectHidden\";s:0:\"\";s:31:\"hofff_navigation_respectPublish\";s:0:\"\";s:30:\"hofff_navigation_respectGuests\";s:0:\"\";s:29:\"hofff_navigation_includeStart\";s:1:\"1\";s:32:\"hofff_navigation_showHiddenStart\";s:0:\"\";s:27:\"hofff_navigation_showHidden\";s:0:\"\";s:30:\"hofff_navigation_showProtected\";s:0:\"\";s:27:\"hofff_navigation_showGuests\";s:0:\"\";s:26:\"hofff_navigation_addFields\";N;s:36:\"hofff_navigation_noForwardResolution\";s:0:\"\";s:31:\"hofff_navigation_showErrorPages\";s:0:\"\";s:30:\"hofff_navigation_disableEvents\";s:0:\"\";s:30:\"hofff_navigation_currentAsRoot\";s:0:\"\";s:28:\"hofff_navigation_defineRoots\";s:1:\"1\";s:27:\"hofff_navigation_defineStop\";s:1:\"1\";s:21:\"hofff_navigation_stop\";s:0:\"\";s:27:\"hofff_navigation_defineHard\";s:0:\"\";s:21:\"hofff_navigation_hard\";i:0;s:26:\"hofff_navigation_isSitemap\";s:0:\"\";s:32:\"hofff_navigation_hideSingleLevel\";s:0:\"\";s:29:\"hofff_navigation_addLegacyCss\";s:0:\"\";s:3:\"pid\";i:1;s:6:\"tstamp\";i:1708348952;s:4:\"name\";s:10:\"Navigation\";s:8:\"headline\";s:45:\"a:2:{s:4:\"unit\";s:2:\"h2\";s:5:\"value\";s:0:\"\";}\";s:4:\"type\";s:21:\"hofff_navigation_menu\";s:11:\"levelOffset\";i:0;s:9:\"showLevel\";i:0;s:8:\"rootPage\";i:0;s:13:\"navigationTpl\";s:0:\"\";s:9:\"customTpl\";s:0:\"\";s:5:\"pages\";N;s:11:\"customLabel\";s:0:\"\";s:6:\"jumpTo\";i:0;s:12:\"overviewPage\";i:0;s:11:\"pwResetPage\";i:0;s:8:\"editable\";N;s:9:\"memberTpl\";s:0:\"\";s:4:\"form\";i:0;s:9:\"queryType\";s:3:\"and\";s:13:\"contextLength\";s:0:\"\";s:16:\"minKeywordLength\";i:4;s:7:\"perPage\";i:0;s:10:\"searchType\";s:6:\"simple\";s:9:\"searchTpl\";s:0:\"\";s:8:\"inColumn\";s:4:\"main\";s:9:\"skipFirst\";i:0;s:9:\"singleSRC\";N;s:7:\"imgSize\";s:0:\"\";s:8:\"multiSRC\";N;s:4:\"html\";N;s:14:\"unfilteredHtml\";N;s:9:\"rss_cache\";i:3600;s:8:\"rss_feed\";N;s:12:\"rss_template\";s:0:\"\";s:13:\"numberOfItems\";i:3;s:10:\"reg_groups\";N;s:9:\"reg_close\";s:0:\"\";s:11:\"reg_homeDir\";N;s:10:\"reg_jumpTo\";i:0;s:8:\"reg_text\";N;s:12:\"reg_password\";N;s:4:\"data\";N;s:6:\"groups\";N;s:5:\"cssID\";s:28:\"a:2:{i:0;s:0:\"\";i:1;s:0:\"\";}\";s:24:\"rootPageDependentModules\";N;}'),(27,0,1,1708348954,12,'tl_module',1,'admin','Navigation','contao?act=edit&do=themes&id=1&table=tl_module','a:87:{s:2:\"id\";i:1;s:9:\"hardLimit\";i:0;s:13:\"showProtected\";i:0;s:10:\"defineRoot\";i:0;s:10:\"showHidden\";i:0;s:9:\"autologin\";i:0;s:12:\"redirectBack\";i:0;s:5:\"fuzzy\";i:0;s:9:\"loadFirst\";i:0;s:10:\"useCaption\";i:0;s:8:\"fullsize\";i:0;s:14:\"disableCaptcha\";i:0;s:14:\"reg_allowLogin\";i:0;s:12:\"reg_skipName\";i:0;s:13:\"reg_deleteDir\";i:0;s:13:\"reg_assignDir\";i:0;s:12:\"reg_activate\";i:0;s:9:\"protected\";i:0;s:22:\"hofff_navigation_roots\";s:14:\"a:1:{i:0;i:1;}\";s:28:\"hofff_navigation_roots_order\";N;s:22:\"hofff_navigation_start\";i:0;s:30:\"hofff_navigation_respectHidden\";s:0:\"\";s:31:\"hofff_navigation_respectPublish\";s:0:\"\";s:30:\"hofff_navigation_respectGuests\";s:0:\"\";s:29:\"hofff_navigation_includeStart\";s:1:\"1\";s:32:\"hofff_navigation_showHiddenStart\";s:0:\"\";s:27:\"hofff_navigation_showHidden\";s:0:\"\";s:30:\"hofff_navigation_showProtected\";s:0:\"\";s:27:\"hofff_navigation_showGuests\";s:0:\"\";s:26:\"hofff_navigation_addFields\";N;s:36:\"hofff_navigation_noForwardResolution\";s:0:\"\";s:31:\"hofff_navigation_showErrorPages\";s:0:\"\";s:30:\"hofff_navigation_disableEvents\";s:0:\"\";s:30:\"hofff_navigation_currentAsRoot\";s:0:\"\";s:28:\"hofff_navigation_defineRoots\";s:1:\"1\";s:27:\"hofff_navigation_defineStop\";s:0:\"\";s:21:\"hofff_navigation_stop\";s:0:\"\";s:27:\"hofff_navigation_defineHard\";s:0:\"\";s:21:\"hofff_navigation_hard\";i:0;s:26:\"hofff_navigation_isSitemap\";s:0:\"\";s:32:\"hofff_navigation_hideSingleLevel\";s:0:\"\";s:29:\"hofff_navigation_addLegacyCss\";s:0:\"\";s:3:\"pid\";i:1;s:6:\"tstamp\";i:1708348954;s:4:\"name\";s:10:\"Navigation\";s:8:\"headline\";s:45:\"a:2:{s:4:\"unit\";s:2:\"h2\";s:5:\"value\";s:0:\"\";}\";s:4:\"type\";s:21:\"hofff_navigation_menu\";s:11:\"levelOffset\";i:0;s:9:\"showLevel\";i:0;s:8:\"rootPage\";i:0;s:13:\"navigationTpl\";s:0:\"\";s:9:\"customTpl\";s:0:\"\";s:5:\"pages\";N;s:11:\"customLabel\";s:0:\"\";s:6:\"jumpTo\";i:0;s:12:\"overviewPage\";i:0;s:11:\"pwResetPage\";i:0;s:8:\"editable\";N;s:9:\"memberTpl\";s:0:\"\";s:4:\"form\";i:0;s:9:\"queryType\";s:3:\"and\";s:13:\"contextLength\";s:0:\"\";s:16:\"minKeywordLength\";i:4;s:7:\"perPage\";i:0;s:10:\"searchType\";s:6:\"simple\";s:9:\"searchTpl\";s:0:\"\";s:8:\"inColumn\";s:4:\"main\";s:9:\"skipFirst\";i:0;s:9:\"singleSRC\";N;s:7:\"imgSize\";s:0:\"\";s:8:\"multiSRC\";N;s:4:\"html\";N;s:14:\"unfilteredHtml\";N;s:9:\"rss_cache\";i:3600;s:8:\"rss_feed\";N;s:12:\"rss_template\";s:0:\"\";s:13:\"numberOfItems\";i:3;s:10:\"reg_groups\";N;s:9:\"reg_close\";s:0:\"\";s:11:\"reg_homeDir\";N;s:10:\"reg_jumpTo\";i:0;s:8:\"reg_text\";N;s:12:\"reg_password\";N;s:4:\"data\";N;s:6:\"groups\";N;s:5:\"cssID\";s:28:\"a:2:{i:0;s:0:\"\";i:1;s:0:\"\";}\";s:24:\"rootPageDependentModules\";N;}'),(28,0,1,1708348955,13,'tl_module',1,'admin','Navigation','contao?act=edit&do=themes&id=1&table=tl_module','a:87:{s:2:\"id\";i:1;s:9:\"hardLimit\";i:0;s:13:\"showProtected\";i:0;s:10:\"defineRoot\";i:0;s:10:\"showHidden\";i:0;s:9:\"autologin\";i:0;s:12:\"redirectBack\";i:0;s:5:\"fuzzy\";i:0;s:9:\"loadFirst\";i:0;s:10:\"useCaption\";i:0;s:8:\"fullsize\";i:0;s:14:\"disableCaptcha\";i:0;s:14:\"reg_allowLogin\";i:0;s:12:\"reg_skipName\";i:0;s:13:\"reg_deleteDir\";i:0;s:13:\"reg_assignDir\";i:0;s:12:\"reg_activate\";i:0;s:9:\"protected\";i:0;s:22:\"hofff_navigation_roots\";s:14:\"a:1:{i:0;i:1;}\";s:28:\"hofff_navigation_roots_order\";N;s:22:\"hofff_navigation_start\";i:0;s:30:\"hofff_navigation_respectHidden\";s:0:\"\";s:31:\"hofff_navigation_respectPublish\";s:0:\"\";s:30:\"hofff_navigation_respectGuests\";s:0:\"\";s:29:\"hofff_navigation_includeStart\";s:1:\"1\";s:32:\"hofff_navigation_showHiddenStart\";s:0:\"\";s:27:\"hofff_navigation_showHidden\";s:0:\"\";s:30:\"hofff_navigation_showProtected\";s:0:\"\";s:27:\"hofff_navigation_showGuests\";s:0:\"\";s:26:\"hofff_navigation_addFields\";N;s:36:\"hofff_navigation_noForwardResolution\";s:0:\"\";s:31:\"hofff_navigation_showErrorPages\";s:0:\"\";s:30:\"hofff_navigation_disableEvents\";s:0:\"\";s:30:\"hofff_navigation_currentAsRoot\";s:0:\"\";s:28:\"hofff_navigation_defineRoots\";s:1:\"1\";s:27:\"hofff_navigation_defineStop\";s:0:\"\";s:21:\"hofff_navigation_stop\";s:0:\"\";s:27:\"hofff_navigation_defineHard\";s:0:\"\";s:21:\"hofff_navigation_hard\";i:0;s:26:\"hofff_navigation_isSitemap\";s:0:\"\";s:32:\"hofff_navigation_hideSingleLevel\";s:0:\"\";s:29:\"hofff_navigation_addLegacyCss\";s:0:\"\";s:3:\"pid\";i:1;s:6:\"tstamp\";i:1708348955;s:4:\"name\";s:10:\"Navigation\";s:8:\"headline\";s:45:\"a:2:{s:4:\"unit\";s:2:\"h2\";s:5:\"value\";s:0:\"\";}\";s:4:\"type\";s:21:\"hofff_navigation_menu\";s:11:\"levelOffset\";i:0;s:9:\"showLevel\";i:0;s:8:\"rootPage\";i:0;s:13:\"navigationTpl\";s:0:\"\";s:9:\"customTpl\";s:0:\"\";s:5:\"pages\";N;s:11:\"customLabel\";s:0:\"\";s:6:\"jumpTo\";i:0;s:12:\"overviewPage\";i:0;s:11:\"pwResetPage\";i:0;s:8:\"editable\";N;s:9:\"memberTpl\";s:0:\"\";s:4:\"form\";i:0;s:9:\"queryType\";s:3:\"and\";s:13:\"contextLength\";s:0:\"\";s:16:\"minKeywordLength\";i:4;s:7:\"perPage\";i:0;s:10:\"searchType\";s:6:\"simple\";s:9:\"searchTpl\";s:0:\"\";s:8:\"inColumn\";s:4:\"main\";s:9:\"skipFirst\";i:0;s:9:\"singleSRC\";N;s:7:\"imgSize\";s:0:\"\";s:8:\"multiSRC\";N;s:4:\"html\";N;s:14:\"unfilteredHtml\";N;s:9:\"rss_cache\";i:3600;s:8:\"rss_feed\";N;s:12:\"rss_template\";s:0:\"\";s:13:\"numberOfItems\";i:3;s:10:\"reg_groups\";N;s:9:\"reg_close\";s:0:\"\";s:11:\"reg_homeDir\";N;s:10:\"reg_jumpTo\";i:0;s:8:\"reg_text\";N;s:12:\"reg_password\";N;s:4:\"data\";N;s:6:\"groups\";N;s:5:\"cssID\";s:28:\"a:2:{i:0;s:0:\"\";i:1;s:0:\"\";}\";s:24:\"rootPageDependentModules\";N;}'),(29,0,1,1708349066,14,'tl_module',1,'admin','Navigation','contao?act=edit&do=themes&id=1&table=tl_module','a:87:{s:2:\"id\";i:1;s:9:\"hardLimit\";i:0;s:13:\"showProtected\";i:0;s:10:\"defineRoot\";i:0;s:10:\"showHidden\";i:0;s:9:\"autologin\";i:0;s:12:\"redirectBack\";i:0;s:5:\"fuzzy\";i:0;s:9:\"loadFirst\";i:0;s:10:\"useCaption\";i:0;s:8:\"fullsize\";i:0;s:14:\"disableCaptcha\";i:0;s:14:\"reg_allowLogin\";i:0;s:12:\"reg_skipName\";i:0;s:13:\"reg_deleteDir\";i:0;s:13:\"reg_assignDir\";i:0;s:12:\"reg_activate\";i:0;s:9:\"protected\";i:0;s:22:\"hofff_navigation_roots\";s:14:\"a:1:{i:0;i:1;}\";s:28:\"hofff_navigation_roots_order\";N;s:22:\"hofff_navigation_start\";i:0;s:30:\"hofff_navigation_respectHidden\";s:0:\"\";s:31:\"hofff_navigation_respectPublish\";s:0:\"\";s:30:\"hofff_navigation_respectGuests\";s:0:\"\";s:29:\"hofff_navigation_includeStart\";s:1:\"1\";s:32:\"hofff_navigation_showHiddenStart\";s:0:\"\";s:27:\"hofff_navigation_showHidden\";s:0:\"\";s:30:\"hofff_navigation_showProtected\";s:0:\"\";s:27:\"hofff_navigation_showGuests\";s:0:\"\";s:26:\"hofff_navigation_addFields\";N;s:36:\"hofff_navigation_noForwardResolution\";s:0:\"\";s:31:\"hofff_navigation_showErrorPages\";s:0:\"\";s:30:\"hofff_navigation_disableEvents\";s:0:\"\";s:30:\"hofff_navigation_currentAsRoot\";s:1:\"1\";s:28:\"hofff_navigation_defineRoots\";s:1:\"1\";s:27:\"hofff_navigation_defineStop\";s:0:\"\";s:21:\"hofff_navigation_stop\";s:0:\"\";s:27:\"hofff_navigation_defineHard\";s:0:\"\";s:21:\"hofff_navigation_hard\";i:0;s:26:\"hofff_navigation_isSitemap\";s:0:\"\";s:32:\"hofff_navigation_hideSingleLevel\";s:0:\"\";s:29:\"hofff_navigation_addLegacyCss\";s:0:\"\";s:3:\"pid\";i:1;s:6:\"tstamp\";i:1708349066;s:4:\"name\";s:10:\"Navigation\";s:8:\"headline\";s:45:\"a:2:{s:4:\"unit\";s:2:\"h2\";s:5:\"value\";s:0:\"\";}\";s:4:\"type\";s:21:\"hofff_navigation_menu\";s:11:\"levelOffset\";i:0;s:9:\"showLevel\";i:0;s:8:\"rootPage\";i:0;s:13:\"navigationTpl\";s:0:\"\";s:9:\"customTpl\";s:0:\"\";s:5:\"pages\";N;s:11:\"customLabel\";s:0:\"\";s:6:\"jumpTo\";i:0;s:12:\"overviewPage\";i:0;s:11:\"pwResetPage\";i:0;s:8:\"editable\";N;s:9:\"memberTpl\";s:0:\"\";s:4:\"form\";i:0;s:9:\"queryType\";s:3:\"and\";s:13:\"contextLength\";s:0:\"\";s:16:\"minKeywordLength\";i:4;s:7:\"perPage\";i:0;s:10:\"searchType\";s:6:\"simple\";s:9:\"searchTpl\";s:0:\"\";s:8:\"inColumn\";s:4:\"main\";s:9:\"skipFirst\";i:0;s:9:\"singleSRC\";N;s:7:\"imgSize\";s:0:\"\";s:8:\"multiSRC\";N;s:4:\"html\";N;s:14:\"unfilteredHtml\";N;s:9:\"rss_cache\";i:3600;s:8:\"rss_feed\";N;s:12:\"rss_template\";s:0:\"\";s:13:\"numberOfItems\";i:3;s:10:\"reg_groups\";N;s:9:\"reg_close\";s:0:\"\";s:11:\"reg_homeDir\";N;s:10:\"reg_jumpTo\";i:0;s:8:\"reg_text\";N;s:12:\"reg_password\";N;s:4:\"data\";N;s:6:\"groups\";N;s:5:\"cssID\";s:28:\"a:2:{i:0;s:0:\"\";i:1;s:0:\"\";}\";s:24:\"rootPageDependentModules\";N;}'),(30,0,1,1708349209,15,'tl_module',1,'admin','Navigation','contao?act=edit&do=themes&id=1&table=tl_module','a:87:{s:2:\"id\";i:1;s:9:\"hardLimit\";i:0;s:13:\"showProtected\";i:0;s:10:\"defineRoot\";i:0;s:10:\"showHidden\";i:0;s:9:\"autologin\";i:0;s:12:\"redirectBack\";i:0;s:5:\"fuzzy\";i:0;s:9:\"loadFirst\";i:0;s:10:\"useCaption\";i:0;s:8:\"fullsize\";i:0;s:14:\"disableCaptcha\";i:0;s:14:\"reg_allowLogin\";i:0;s:12:\"reg_skipName\";i:0;s:13:\"reg_deleteDir\";i:0;s:13:\"reg_assignDir\";i:0;s:12:\"reg_activate\";i:0;s:9:\"protected\";i:0;s:22:\"hofff_navigation_roots\";s:14:\"a:1:{i:0;i:1;}\";s:28:\"hofff_navigation_roots_order\";N;s:22:\"hofff_navigation_start\";i:0;s:30:\"hofff_navigation_respectHidden\";s:0:\"\";s:31:\"hofff_navigation_respectPublish\";s:0:\"\";s:30:\"hofff_navigation_respectGuests\";s:0:\"\";s:29:\"hofff_navigation_includeStart\";s:1:\"1\";s:32:\"hofff_navigation_showHiddenStart\";s:0:\"\";s:27:\"hofff_navigation_showHidden\";s:0:\"\";s:30:\"hofff_navigation_showProtected\";s:0:\"\";s:27:\"hofff_navigation_showGuests\";s:0:\"\";s:26:\"hofff_navigation_addFields\";N;s:36:\"hofff_navigation_noForwardResolution\";s:0:\"\";s:31:\"hofff_navigation_showErrorPages\";s:0:\"\";s:30:\"hofff_navigation_disableEvents\";s:0:\"\";s:30:\"hofff_navigation_currentAsRoot\";s:0:\"\";s:28:\"hofff_navigation_defineRoots\";s:1:\"1\";s:27:\"hofff_navigation_defineStop\";s:0:\"\";s:21:\"hofff_navigation_stop\";s:0:\"\";s:27:\"hofff_navigation_defineHard\";s:0:\"\";s:21:\"hofff_navigation_hard\";i:0;s:26:\"hofff_navigation_isSitemap\";s:0:\"\";s:32:\"hofff_navigation_hideSingleLevel\";s:0:\"\";s:29:\"hofff_navigation_addLegacyCss\";s:0:\"\";s:3:\"pid\";i:1;s:6:\"tstamp\";i:1708349209;s:4:\"name\";s:10:\"Navigation\";s:8:\"headline\";s:45:\"a:2:{s:4:\"unit\";s:2:\"h2\";s:5:\"value\";s:0:\"\";}\";s:4:\"type\";s:21:\"hofff_navigation_menu\";s:11:\"levelOffset\";i:0;s:9:\"showLevel\";i:0;s:8:\"rootPage\";i:0;s:13:\"navigationTpl\";s:0:\"\";s:9:\"customTpl\";s:0:\"\";s:5:\"pages\";N;s:11:\"customLabel\";s:0:\"\";s:6:\"jumpTo\";i:0;s:12:\"overviewPage\";i:0;s:11:\"pwResetPage\";i:0;s:8:\"editable\";N;s:9:\"memberTpl\";s:0:\"\";s:4:\"form\";i:0;s:9:\"queryType\";s:3:\"and\";s:13:\"contextLength\";s:0:\"\";s:16:\"minKeywordLength\";i:4;s:7:\"perPage\";i:0;s:10:\"searchType\";s:6:\"simple\";s:9:\"searchTpl\";s:0:\"\";s:8:\"inColumn\";s:4:\"main\";s:9:\"skipFirst\";i:0;s:9:\"singleSRC\";N;s:7:\"imgSize\";s:0:\"\";s:8:\"multiSRC\";N;s:4:\"html\";N;s:14:\"unfilteredHtml\";N;s:9:\"rss_cache\";i:3600;s:8:\"rss_feed\";N;s:12:\"rss_template\";s:0:\"\";s:13:\"numberOfItems\";i:3;s:10:\"reg_groups\";N;s:9:\"reg_close\";s:0:\"\";s:11:\"reg_homeDir\";N;s:10:\"reg_jumpTo\";i:0;s:8:\"reg_text\";N;s:12:\"reg_password\";N;s:4:\"data\";N;s:6:\"groups\";N;s:5:\"cssID\";s:28:\"a:2:{i:0;s:0:\"\";i:1;s:0:\"\";}\";s:24:\"rootPageDependentModules\";N;}'),(31,0,1,1708349215,16,'tl_module',1,'admin','Navigation','contao?act=edit&do=themes&id=1&table=tl_module','a:87:{s:2:\"id\";i:1;s:9:\"hardLimit\";i:0;s:13:\"showProtected\";i:0;s:10:\"defineRoot\";i:0;s:10:\"showHidden\";i:0;s:9:\"autologin\";i:0;s:12:\"redirectBack\";i:0;s:5:\"fuzzy\";i:0;s:9:\"loadFirst\";i:0;s:10:\"useCaption\";i:0;s:8:\"fullsize\";i:0;s:14:\"disableCaptcha\";i:0;s:14:\"reg_allowLogin\";i:0;s:12:\"reg_skipName\";i:0;s:13:\"reg_deleteDir\";i:0;s:13:\"reg_assignDir\";i:0;s:12:\"reg_activate\";i:0;s:9:\"protected\";i:0;s:22:\"hofff_navigation_roots\";s:14:\"a:1:{i:0;i:1;}\";s:28:\"hofff_navigation_roots_order\";N;s:22:\"hofff_navigation_start\";i:0;s:30:\"hofff_navigation_respectHidden\";s:0:\"\";s:31:\"hofff_navigation_respectPublish\";s:0:\"\";s:30:\"hofff_navigation_respectGuests\";s:0:\"\";s:29:\"hofff_navigation_includeStart\";s:0:\"\";s:32:\"hofff_navigation_showHiddenStart\";s:0:\"\";s:27:\"hofff_navigation_showHidden\";s:0:\"\";s:30:\"hofff_navigation_showProtected\";s:0:\"\";s:27:\"hofff_navigation_showGuests\";s:0:\"\";s:26:\"hofff_navigation_addFields\";N;s:36:\"hofff_navigation_noForwardResolution\";s:0:\"\";s:31:\"hofff_navigation_showErrorPages\";s:0:\"\";s:30:\"hofff_navigation_disableEvents\";s:0:\"\";s:30:\"hofff_navigation_currentAsRoot\";s:0:\"\";s:28:\"hofff_navigation_defineRoots\";s:1:\"1\";s:27:\"hofff_navigation_defineStop\";s:0:\"\";s:21:\"hofff_navigation_stop\";s:0:\"\";s:27:\"hofff_navigation_defineHard\";s:0:\"\";s:21:\"hofff_navigation_hard\";i:0;s:26:\"hofff_navigation_isSitemap\";s:0:\"\";s:32:\"hofff_navigation_hideSingleLevel\";s:0:\"\";s:29:\"hofff_navigation_addLegacyCss\";s:0:\"\";s:3:\"pid\";i:1;s:6:\"tstamp\";i:1708349215;s:4:\"name\";s:10:\"Navigation\";s:8:\"headline\";s:45:\"a:2:{s:4:\"unit\";s:2:\"h2\";s:5:\"value\";s:0:\"\";}\";s:4:\"type\";s:21:\"hofff_navigation_menu\";s:11:\"levelOffset\";i:0;s:9:\"showLevel\";i:0;s:8:\"rootPage\";i:0;s:13:\"navigationTpl\";s:0:\"\";s:9:\"customTpl\";s:0:\"\";s:5:\"pages\";N;s:11:\"customLabel\";s:0:\"\";s:6:\"jumpTo\";i:0;s:12:\"overviewPage\";i:0;s:11:\"pwResetPage\";i:0;s:8:\"editable\";N;s:9:\"memberTpl\";s:0:\"\";s:4:\"form\";i:0;s:9:\"queryType\";s:3:\"and\";s:13:\"contextLength\";s:0:\"\";s:16:\"minKeywordLength\";i:4;s:7:\"perPage\";i:0;s:10:\"searchType\";s:6:\"simple\";s:9:\"searchTpl\";s:0:\"\";s:8:\"inColumn\";s:4:\"main\";s:9:\"skipFirst\";i:0;s:9:\"singleSRC\";N;s:7:\"imgSize\";s:0:\"\";s:8:\"multiSRC\";N;s:4:\"html\";N;s:14:\"unfilteredHtml\";N;s:9:\"rss_cache\";i:3600;s:8:\"rss_feed\";N;s:12:\"rss_template\";s:0:\"\";s:13:\"numberOfItems\";i:3;s:10:\"reg_groups\";N;s:9:\"reg_close\";s:0:\"\";s:11:\"reg_homeDir\";N;s:10:\"reg_jumpTo\";i:0;s:8:\"reg_text\";N;s:12:\"reg_password\";N;s:4:\"data\";N;s:6:\"groups\";N;s:5:\"cssID\";s:28:\"a:2:{i:0;s:0:\"\";i:1;s:0:\"\";}\";s:24:\"rootPageDependentModules\";N;}'),(32,0,1,1708349216,17,'tl_module',1,'admin','Navigation','contao?act=edit&do=themes&id=1&table=tl_module','a:87:{s:2:\"id\";i:1;s:9:\"hardLimit\";i:0;s:13:\"showProtected\";i:0;s:10:\"defineRoot\";i:0;s:10:\"showHidden\";i:0;s:9:\"autologin\";i:0;s:12:\"redirectBack\";i:0;s:5:\"fuzzy\";i:0;s:9:\"loadFirst\";i:0;s:10:\"useCaption\";i:0;s:8:\"fullsize\";i:0;s:14:\"disableCaptcha\";i:0;s:14:\"reg_allowLogin\";i:0;s:12:\"reg_skipName\";i:0;s:13:\"reg_deleteDir\";i:0;s:13:\"reg_assignDir\";i:0;s:12:\"reg_activate\";i:0;s:9:\"protected\";i:0;s:22:\"hofff_navigation_roots\";s:14:\"a:1:{i:0;i:1;}\";s:28:\"hofff_navigation_roots_order\";N;s:22:\"hofff_navigation_start\";i:0;s:30:\"hofff_navigation_respectHidden\";s:0:\"\";s:31:\"hofff_navigation_respectPublish\";s:0:\"\";s:30:\"hofff_navigation_respectGuests\";s:0:\"\";s:29:\"hofff_navigation_includeStart\";s:0:\"\";s:32:\"hofff_navigation_showHiddenStart\";s:0:\"\";s:27:\"hofff_navigation_showHidden\";s:0:\"\";s:30:\"hofff_navigation_showProtected\";s:0:\"\";s:27:\"hofff_navigation_showGuests\";s:0:\"\";s:26:\"hofff_navigation_addFields\";N;s:36:\"hofff_navigation_noForwardResolution\";s:0:\"\";s:31:\"hofff_navigation_showErrorPages\";s:0:\"\";s:30:\"hofff_navigation_disableEvents\";s:0:\"\";s:30:\"hofff_navigation_currentAsRoot\";s:0:\"\";s:28:\"hofff_navigation_defineRoots\";s:1:\"1\";s:27:\"hofff_navigation_defineStop\";s:0:\"\";s:21:\"hofff_navigation_stop\";s:0:\"\";s:27:\"hofff_navigation_defineHard\";s:0:\"\";s:21:\"hofff_navigation_hard\";i:0;s:26:\"hofff_navigation_isSitemap\";s:0:\"\";s:32:\"hofff_navigation_hideSingleLevel\";s:0:\"\";s:29:\"hofff_navigation_addLegacyCss\";s:0:\"\";s:3:\"pid\";i:1;s:6:\"tstamp\";i:1708349216;s:4:\"name\";s:10:\"Navigation\";s:8:\"headline\";s:45:\"a:2:{s:4:\"unit\";s:2:\"h2\";s:5:\"value\";s:0:\"\";}\";s:4:\"type\";s:21:\"hofff_navigation_menu\";s:11:\"levelOffset\";i:0;s:9:\"showLevel\";i:0;s:8:\"rootPage\";i:0;s:13:\"navigationTpl\";s:0:\"\";s:9:\"customTpl\";s:0:\"\";s:5:\"pages\";N;s:11:\"customLabel\";s:0:\"\";s:6:\"jumpTo\";i:0;s:12:\"overviewPage\";i:0;s:11:\"pwResetPage\";i:0;s:8:\"editable\";N;s:9:\"memberTpl\";s:0:\"\";s:4:\"form\";i:0;s:9:\"queryType\";s:3:\"and\";s:13:\"contextLength\";s:0:\"\";s:16:\"minKeywordLength\";i:4;s:7:\"perPage\";i:0;s:10:\"searchType\";s:6:\"simple\";s:9:\"searchTpl\";s:0:\"\";s:8:\"inColumn\";s:4:\"main\";s:9:\"skipFirst\";i:0;s:9:\"singleSRC\";N;s:7:\"imgSize\";s:0:\"\";s:8:\"multiSRC\";N;s:4:\"html\";N;s:14:\"unfilteredHtml\";N;s:9:\"rss_cache\";i:3600;s:8:\"rss_feed\";N;s:12:\"rss_template\";s:0:\"\";s:13:\"numberOfItems\";i:3;s:10:\"reg_groups\";N;s:9:\"reg_close\";s:0:\"\";s:11:\"reg_homeDir\";N;s:10:\"reg_jumpTo\";i:0;s:8:\"reg_text\";N;s:12:\"reg_password\";N;s:4:\"data\";N;s:6:\"groups\";N;s:5:\"cssID\";s:28:\"a:2:{i:0;s:0:\"\";i:1;s:0:\"\";}\";s:24:\"rootPageDependentModules\";N;}'),(33,0,1,1708349222,18,'tl_module',1,'admin','Navigation','contao?act=edit&do=themes&id=1&table=tl_module','a:87:{s:2:\"id\";i:1;s:9:\"hardLimit\";i:0;s:13:\"showProtected\";i:0;s:10:\"defineRoot\";i:0;s:10:\"showHidden\";i:0;s:9:\"autologin\";i:0;s:12:\"redirectBack\";i:0;s:5:\"fuzzy\";i:0;s:9:\"loadFirst\";i:0;s:10:\"useCaption\";i:0;s:8:\"fullsize\";i:0;s:14:\"disableCaptcha\";i:0;s:14:\"reg_allowLogin\";i:0;s:12:\"reg_skipName\";i:0;s:13:\"reg_deleteDir\";i:0;s:13:\"reg_assignDir\";i:0;s:12:\"reg_activate\";i:0;s:9:\"protected\";i:0;s:22:\"hofff_navigation_roots\";s:14:\"a:1:{i:0;i:1;}\";s:28:\"hofff_navigation_roots_order\";N;s:22:\"hofff_navigation_start\";i:0;s:30:\"hofff_navigation_respectHidden\";s:0:\"\";s:31:\"hofff_navigation_respectPublish\";s:0:\"\";s:30:\"hofff_navigation_respectGuests\";s:0:\"\";s:29:\"hofff_navigation_includeStart\";s:0:\"\";s:32:\"hofff_navigation_showHiddenStart\";s:0:\"\";s:27:\"hofff_navigation_showHidden\";s:0:\"\";s:30:\"hofff_navigation_showProtected\";s:0:\"\";s:27:\"hofff_navigation_showGuests\";s:0:\"\";s:26:\"hofff_navigation_addFields\";N;s:36:\"hofff_navigation_noForwardResolution\";s:0:\"\";s:31:\"hofff_navigation_showErrorPages\";s:0:\"\";s:30:\"hofff_navigation_disableEvents\";s:0:\"\";s:30:\"hofff_navigation_currentAsRoot\";s:0:\"\";s:28:\"hofff_navigation_defineRoots\";s:1:\"1\";s:27:\"hofff_navigation_defineStop\";s:1:\"1\";s:21:\"hofff_navigation_stop\";s:0:\"\";s:27:\"hofff_navigation_defineHard\";s:0:\"\";s:21:\"hofff_navigation_hard\";i:0;s:26:\"hofff_navigation_isSitemap\";s:0:\"\";s:32:\"hofff_navigation_hideSingleLevel\";s:0:\"\";s:29:\"hofff_navigation_addLegacyCss\";s:0:\"\";s:3:\"pid\";i:1;s:6:\"tstamp\";i:1708349222;s:4:\"name\";s:10:\"Navigation\";s:8:\"headline\";s:45:\"a:2:{s:4:\"unit\";s:2:\"h2\";s:5:\"value\";s:0:\"\";}\";s:4:\"type\";s:21:\"hofff_navigation_menu\";s:11:\"levelOffset\";i:0;s:9:\"showLevel\";i:0;s:8:\"rootPage\";i:0;s:13:\"navigationTpl\";s:0:\"\";s:9:\"customTpl\";s:0:\"\";s:5:\"pages\";N;s:11:\"customLabel\";s:0:\"\";s:6:\"jumpTo\";i:0;s:12:\"overviewPage\";i:0;s:11:\"pwResetPage\";i:0;s:8:\"editable\";N;s:9:\"memberTpl\";s:0:\"\";s:4:\"form\";i:0;s:9:\"queryType\";s:3:\"and\";s:13:\"contextLength\";s:0:\"\";s:16:\"minKeywordLength\";i:4;s:7:\"perPage\";i:0;s:10:\"searchType\";s:6:\"simple\";s:9:\"searchTpl\";s:0:\"\";s:8:\"inColumn\";s:4:\"main\";s:9:\"skipFirst\";i:0;s:9:\"singleSRC\";N;s:7:\"imgSize\";s:0:\"\";s:8:\"multiSRC\";N;s:4:\"html\";N;s:14:\"unfilteredHtml\";N;s:9:\"rss_cache\";i:3600;s:8:\"rss_feed\";N;s:12:\"rss_template\";s:0:\"\";s:13:\"numberOfItems\";i:3;s:10:\"reg_groups\";N;s:9:\"reg_close\";s:0:\"\";s:11:\"reg_homeDir\";N;s:10:\"reg_jumpTo\";i:0;s:8:\"reg_text\";N;s:12:\"reg_password\";N;s:4:\"data\";N;s:6:\"groups\";N;s:5:\"cssID\";s:28:\"a:2:{i:0;s:0:\"\";i:1;s:0:\"\";}\";s:24:\"rootPageDependentModules\";N;}'),(34,0,1,1708349230,19,'tl_module',1,'admin','Navigation','contao?act=edit&do=themes&id=1&table=tl_module','a:87:{s:2:\"id\";i:1;s:9:\"hardLimit\";i:0;s:13:\"showProtected\";i:0;s:10:\"defineRoot\";i:0;s:10:\"showHidden\";i:0;s:9:\"autologin\";i:0;s:12:\"redirectBack\";i:0;s:5:\"fuzzy\";i:0;s:9:\"loadFirst\";i:0;s:10:\"useCaption\";i:0;s:8:\"fullsize\";i:0;s:14:\"disableCaptcha\";i:0;s:14:\"reg_allowLogin\";i:0;s:12:\"reg_skipName\";i:0;s:13:\"reg_deleteDir\";i:0;s:13:\"reg_assignDir\";i:0;s:12:\"reg_activate\";i:0;s:9:\"protected\";i:0;s:22:\"hofff_navigation_roots\";s:14:\"a:1:{i:0;i:1;}\";s:28:\"hofff_navigation_roots_order\";N;s:22:\"hofff_navigation_start\";i:0;s:30:\"hofff_navigation_respectHidden\";s:0:\"\";s:31:\"hofff_navigation_respectPublish\";s:0:\"\";s:30:\"hofff_navigation_respectGuests\";s:0:\"\";s:29:\"hofff_navigation_includeStart\";s:0:\"\";s:32:\"hofff_navigation_showHiddenStart\";s:0:\"\";s:27:\"hofff_navigation_showHidden\";s:0:\"\";s:30:\"hofff_navigation_showProtected\";s:0:\"\";s:27:\"hofff_navigation_showGuests\";s:0:\"\";s:26:\"hofff_navigation_addFields\";N;s:36:\"hofff_navigation_noForwardResolution\";s:0:\"\";s:31:\"hofff_navigation_showErrorPages\";s:0:\"\";s:30:\"hofff_navigation_disableEvents\";s:0:\"\";s:30:\"hofff_navigation_currentAsRoot\";s:0:\"\";s:28:\"hofff_navigation_defineRoots\";s:1:\"1\";s:27:\"hofff_navigation_defineStop\";s:1:\"1\";s:21:\"hofff_navigation_stop\";s:1:\"0\";s:27:\"hofff_navigation_defineHard\";s:0:\"\";s:21:\"hofff_navigation_hard\";i:0;s:26:\"hofff_navigation_isSitemap\";s:0:\"\";s:32:\"hofff_navigation_hideSingleLevel\";s:0:\"\";s:29:\"hofff_navigation_addLegacyCss\";s:0:\"\";s:3:\"pid\";i:1;s:6:\"tstamp\";i:1708349230;s:4:\"name\";s:10:\"Navigation\";s:8:\"headline\";s:45:\"a:2:{s:4:\"unit\";s:2:\"h2\";s:5:\"value\";s:0:\"\";}\";s:4:\"type\";s:21:\"hofff_navigation_menu\";s:11:\"levelOffset\";i:0;s:9:\"showLevel\";i:0;s:8:\"rootPage\";i:0;s:13:\"navigationTpl\";s:0:\"\";s:9:\"customTpl\";s:0:\"\";s:5:\"pages\";N;s:11:\"customLabel\";s:0:\"\";s:6:\"jumpTo\";i:0;s:12:\"overviewPage\";i:0;s:11:\"pwResetPage\";i:0;s:8:\"editable\";N;s:9:\"memberTpl\";s:0:\"\";s:4:\"form\";i:0;s:9:\"queryType\";s:3:\"and\";s:13:\"contextLength\";s:0:\"\";s:16:\"minKeywordLength\";i:4;s:7:\"perPage\";i:0;s:10:\"searchType\";s:6:\"simple\";s:9:\"searchTpl\";s:0:\"\";s:8:\"inColumn\";s:4:\"main\";s:9:\"skipFirst\";i:0;s:9:\"singleSRC\";N;s:7:\"imgSize\";s:0:\"\";s:8:\"multiSRC\";N;s:4:\"html\";N;s:14:\"unfilteredHtml\";N;s:9:\"rss_cache\";i:3600;s:8:\"rss_feed\";N;s:12:\"rss_template\";s:0:\"\";s:13:\"numberOfItems\";i:3;s:10:\"reg_groups\";N;s:9:\"reg_close\";s:0:\"\";s:11:\"reg_homeDir\";N;s:10:\"reg_jumpTo\";i:0;s:8:\"reg_text\";N;s:12:\"reg_password\";N;s:4:\"data\";N;s:6:\"groups\";N;s:5:\"cssID\";s:28:\"a:2:{i:0;s:0:\"\";i:1;s:0:\"\";}\";s:24:\"rootPageDependentModules\";N;}'),(35,0,1,1708349239,20,'tl_module',1,'admin','Navigation','contao?act=edit&do=themes&id=1&table=tl_module','a:87:{s:2:\"id\";i:1;s:9:\"hardLimit\";i:0;s:13:\"showProtected\";i:0;s:10:\"defineRoot\";i:0;s:10:\"showHidden\";i:0;s:9:\"autologin\";i:0;s:12:\"redirectBack\";i:0;s:5:\"fuzzy\";i:0;s:9:\"loadFirst\";i:0;s:10:\"useCaption\";i:0;s:8:\"fullsize\";i:0;s:14:\"disableCaptcha\";i:0;s:14:\"reg_allowLogin\";i:0;s:12:\"reg_skipName\";i:0;s:13:\"reg_deleteDir\";i:0;s:13:\"reg_assignDir\";i:0;s:12:\"reg_activate\";i:0;s:9:\"protected\";i:0;s:22:\"hofff_navigation_roots\";s:14:\"a:1:{i:0;i:1;}\";s:28:\"hofff_navigation_roots_order\";N;s:22:\"hofff_navigation_start\";i:0;s:30:\"hofff_navigation_respectHidden\";s:0:\"\";s:31:\"hofff_navigation_respectPublish\";s:0:\"\";s:30:\"hofff_navigation_respectGuests\";s:0:\"\";s:29:\"hofff_navigation_includeStart\";s:0:\"\";s:32:\"hofff_navigation_showHiddenStart\";s:0:\"\";s:27:\"hofff_navigation_showHidden\";s:0:\"\";s:30:\"hofff_navigation_showProtected\";s:0:\"\";s:27:\"hofff_navigation_showGuests\";s:0:\"\";s:26:\"hofff_navigation_addFields\";N;s:36:\"hofff_navigation_noForwardResolution\";s:0:\"\";s:31:\"hofff_navigation_showErrorPages\";s:0:\"\";s:30:\"hofff_navigation_disableEvents\";s:0:\"\";s:30:\"hofff_navigation_currentAsRoot\";s:0:\"\";s:28:\"hofff_navigation_defineRoots\";s:1:\"1\";s:27:\"hofff_navigation_defineStop\";s:1:\"1\";s:21:\"hofff_navigation_stop\";s:5:\"0,1,2\";s:27:\"hofff_navigation_defineHard\";s:0:\"\";s:21:\"hofff_navigation_hard\";i:0;s:26:\"hofff_navigation_isSitemap\";s:0:\"\";s:32:\"hofff_navigation_hideSingleLevel\";s:0:\"\";s:29:\"hofff_navigation_addLegacyCss\";s:0:\"\";s:3:\"pid\";i:1;s:6:\"tstamp\";i:1708349239;s:4:\"name\";s:10:\"Navigation\";s:8:\"headline\";s:45:\"a:2:{s:4:\"unit\";s:2:\"h2\";s:5:\"value\";s:0:\"\";}\";s:4:\"type\";s:21:\"hofff_navigation_menu\";s:11:\"levelOffset\";i:0;s:9:\"showLevel\";i:0;s:8:\"rootPage\";i:0;s:13:\"navigationTpl\";s:0:\"\";s:9:\"customTpl\";s:0:\"\";s:5:\"pages\";N;s:11:\"customLabel\";s:0:\"\";s:6:\"jumpTo\";i:0;s:12:\"overviewPage\";i:0;s:11:\"pwResetPage\";i:0;s:8:\"editable\";N;s:9:\"memberTpl\";s:0:\"\";s:4:\"form\";i:0;s:9:\"queryType\";s:3:\"and\";s:13:\"contextLength\";s:0:\"\";s:16:\"minKeywordLength\";i:4;s:7:\"perPage\";i:0;s:10:\"searchType\";s:6:\"simple\";s:9:\"searchTpl\";s:0:\"\";s:8:\"inColumn\";s:4:\"main\";s:9:\"skipFirst\";i:0;s:9:\"singleSRC\";N;s:7:\"imgSize\";s:0:\"\";s:8:\"multiSRC\";N;s:4:\"html\";N;s:14:\"unfilteredHtml\";N;s:9:\"rss_cache\";i:3600;s:8:\"rss_feed\";N;s:12:\"rss_template\";s:0:\"\";s:13:\"numberOfItems\";i:3;s:10:\"reg_groups\";N;s:9:\"reg_close\";s:0:\"\";s:11:\"reg_homeDir\";N;s:10:\"reg_jumpTo\";i:0;s:8:\"reg_text\";N;s:12:\"reg_password\";N;s:4:\"data\";N;s:6:\"groups\";N;s:5:\"cssID\";s:28:\"a:2:{i:0;s:0:\"\";i:1;s:0:\"\";}\";s:24:\"rootPageDependentModules\";N;}'),(36,0,1,1708349251,21,'tl_module',1,'admin','Navigation','contao?act=edit&do=themes&id=1&table=tl_module','a:87:{s:2:\"id\";i:1;s:9:\"hardLimit\";i:0;s:13:\"showProtected\";i:0;s:10:\"defineRoot\";i:0;s:10:\"showHidden\";i:0;s:9:\"autologin\";i:0;s:12:\"redirectBack\";i:0;s:5:\"fuzzy\";i:0;s:9:\"loadFirst\";i:0;s:10:\"useCaption\";i:0;s:8:\"fullsize\";i:0;s:14:\"disableCaptcha\";i:0;s:14:\"reg_allowLogin\";i:0;s:12:\"reg_skipName\";i:0;s:13:\"reg_deleteDir\";i:0;s:13:\"reg_assignDir\";i:0;s:12:\"reg_activate\";i:0;s:9:\"protected\";i:0;s:22:\"hofff_navigation_roots\";s:14:\"a:1:{i:0;i:1;}\";s:28:\"hofff_navigation_roots_order\";N;s:22:\"hofff_navigation_start\";i:1;s:30:\"hofff_navigation_respectHidden\";s:0:\"\";s:31:\"hofff_navigation_respectPublish\";s:0:\"\";s:30:\"hofff_navigation_respectGuests\";s:0:\"\";s:29:\"hofff_navigation_includeStart\";s:0:\"\";s:32:\"hofff_navigation_showHiddenStart\";s:0:\"\";s:27:\"hofff_navigation_showHidden\";s:0:\"\";s:30:\"hofff_navigation_showProtected\";s:0:\"\";s:27:\"hofff_navigation_showGuests\";s:0:\"\";s:26:\"hofff_navigation_addFields\";N;s:36:\"hofff_navigation_noForwardResolution\";s:0:\"\";s:31:\"hofff_navigation_showErrorPages\";s:0:\"\";s:30:\"hofff_navigation_disableEvents\";s:0:\"\";s:30:\"hofff_navigation_currentAsRoot\";s:0:\"\";s:28:\"hofff_navigation_defineRoots\";s:1:\"1\";s:27:\"hofff_navigation_defineStop\";s:1:\"1\";s:21:\"hofff_navigation_stop\";s:5:\"0,1,2\";s:27:\"hofff_navigation_defineHard\";s:0:\"\";s:21:\"hofff_navigation_hard\";i:0;s:26:\"hofff_navigation_isSitemap\";s:0:\"\";s:32:\"hofff_navigation_hideSingleLevel\";s:0:\"\";s:29:\"hofff_navigation_addLegacyCss\";s:0:\"\";s:3:\"pid\";i:1;s:6:\"tstamp\";i:1708349251;s:4:\"name\";s:10:\"Navigation\";s:8:\"headline\";s:45:\"a:2:{s:4:\"unit\";s:2:\"h2\";s:5:\"value\";s:0:\"\";}\";s:4:\"type\";s:21:\"hofff_navigation_menu\";s:11:\"levelOffset\";i:0;s:9:\"showLevel\";i:0;s:8:\"rootPage\";i:0;s:13:\"navigationTpl\";s:0:\"\";s:9:\"customTpl\";s:0:\"\";s:5:\"pages\";N;s:11:\"customLabel\";s:0:\"\";s:6:\"jumpTo\";i:0;s:12:\"overviewPage\";i:0;s:11:\"pwResetPage\";i:0;s:8:\"editable\";N;s:9:\"memberTpl\";s:0:\"\";s:4:\"form\";i:0;s:9:\"queryType\";s:3:\"and\";s:13:\"contextLength\";s:0:\"\";s:16:\"minKeywordLength\";i:4;s:7:\"perPage\";i:0;s:10:\"searchType\";s:6:\"simple\";s:9:\"searchTpl\";s:0:\"\";s:8:\"inColumn\";s:4:\"main\";s:9:\"skipFirst\";i:0;s:9:\"singleSRC\";N;s:7:\"imgSize\";s:0:\"\";s:8:\"multiSRC\";N;s:4:\"html\";N;s:14:\"unfilteredHtml\";N;s:9:\"rss_cache\";i:3600;s:8:\"rss_feed\";N;s:12:\"rss_template\";s:0:\"\";s:13:\"numberOfItems\";i:3;s:10:\"reg_groups\";N;s:9:\"reg_close\";s:0:\"\";s:11:\"reg_homeDir\";N;s:10:\"reg_jumpTo\";i:0;s:8:\"reg_text\";N;s:12:\"reg_password\";N;s:4:\"data\";N;s:6:\"groups\";N;s:5:\"cssID\";s:28:\"a:2:{i:0;s:0:\"\";i:1;s:0:\"\";}\";s:24:\"rootPageDependentModules\";N;}'),(37,0,1,1708349258,22,'tl_module',1,'admin','Navigation','contao?act=edit&do=themes&id=1&table=tl_module','a:87:{s:2:\"id\";i:1;s:9:\"hardLimit\";i:0;s:13:\"showProtected\";i:0;s:10:\"defineRoot\";i:0;s:10:\"showHidden\";i:0;s:9:\"autologin\";i:0;s:12:\"redirectBack\";i:0;s:5:\"fuzzy\";i:0;s:9:\"loadFirst\";i:0;s:10:\"useCaption\";i:0;s:8:\"fullsize\";i:0;s:14:\"disableCaptcha\";i:0;s:14:\"reg_allowLogin\";i:0;s:12:\"reg_skipName\";i:0;s:13:\"reg_deleteDir\";i:0;s:13:\"reg_assignDir\";i:0;s:12:\"reg_activate\";i:0;s:9:\"protected\";i:0;s:22:\"hofff_navigation_roots\";s:14:\"a:1:{i:0;i:1;}\";s:28:\"hofff_navigation_roots_order\";N;s:22:\"hofff_navigation_start\";i:1;s:30:\"hofff_navigation_respectHidden\";s:0:\"\";s:31:\"hofff_navigation_respectPublish\";s:0:\"\";s:30:\"hofff_navigation_respectGuests\";s:0:\"\";s:29:\"hofff_navigation_includeStart\";s:0:\"\";s:32:\"hofff_navigation_showHiddenStart\";s:0:\"\";s:27:\"hofff_navigation_showHidden\";s:0:\"\";s:30:\"hofff_navigation_showProtected\";s:0:\"\";s:27:\"hofff_navigation_showGuests\";s:0:\"\";s:26:\"hofff_navigation_addFields\";N;s:36:\"hofff_navigation_noForwardResolution\";s:0:\"\";s:31:\"hofff_navigation_showErrorPages\";s:0:\"\";s:30:\"hofff_navigation_disableEvents\";s:0:\"\";s:30:\"hofff_navigation_currentAsRoot\";s:0:\"\";s:28:\"hofff_navigation_defineRoots\";s:1:\"1\";s:27:\"hofff_navigation_defineStop\";s:0:\"\";s:21:\"hofff_navigation_stop\";s:5:\"0,1,2\";s:27:\"hofff_navigation_defineHard\";s:0:\"\";s:21:\"hofff_navigation_hard\";i:0;s:26:\"hofff_navigation_isSitemap\";s:0:\"\";s:32:\"hofff_navigation_hideSingleLevel\";s:0:\"\";s:29:\"hofff_navigation_addLegacyCss\";s:0:\"\";s:3:\"pid\";i:1;s:6:\"tstamp\";i:1708349258;s:4:\"name\";s:10:\"Navigation\";s:8:\"headline\";s:45:\"a:2:{s:4:\"unit\";s:2:\"h2\";s:5:\"value\";s:0:\"\";}\";s:4:\"type\";s:21:\"hofff_navigation_menu\";s:11:\"levelOffset\";i:0;s:9:\"showLevel\";i:0;s:8:\"rootPage\";i:0;s:13:\"navigationTpl\";s:0:\"\";s:9:\"customTpl\";s:0:\"\";s:5:\"pages\";N;s:11:\"customLabel\";s:0:\"\";s:6:\"jumpTo\";i:0;s:12:\"overviewPage\";i:0;s:11:\"pwResetPage\";i:0;s:8:\"editable\";N;s:9:\"memberTpl\";s:0:\"\";s:4:\"form\";i:0;s:9:\"queryType\";s:3:\"and\";s:13:\"contextLength\";s:0:\"\";s:16:\"minKeywordLength\";i:4;s:7:\"perPage\";i:0;s:10:\"searchType\";s:6:\"simple\";s:9:\"searchTpl\";s:0:\"\";s:8:\"inColumn\";s:4:\"main\";s:9:\"skipFirst\";i:0;s:9:\"singleSRC\";N;s:7:\"imgSize\";s:0:\"\";s:8:\"multiSRC\";N;s:4:\"html\";N;s:14:\"unfilteredHtml\";N;s:9:\"rss_cache\";i:3600;s:8:\"rss_feed\";N;s:12:\"rss_template\";s:0:\"\";s:13:\"numberOfItems\";i:3;s:10:\"reg_groups\";N;s:9:\"reg_close\";s:0:\"\";s:11:\"reg_homeDir\";N;s:10:\"reg_jumpTo\";i:0;s:8:\"reg_text\";N;s:12:\"reg_password\";N;s:4:\"data\";N;s:6:\"groups\";N;s:5:\"cssID\";s:28:\"a:2:{i:0;s:0:\"\";i:1;s:0:\"\";}\";s:24:\"rootPageDependentModules\";N;}'),(38,0,1,1708349260,23,'tl_module',1,'admin','Navigation','contao?act=edit&do=themes&id=1&table=tl_module','a:87:{s:2:\"id\";i:1;s:9:\"hardLimit\";i:0;s:13:\"showProtected\";i:0;s:10:\"defineRoot\";i:0;s:10:\"showHidden\";i:0;s:9:\"autologin\";i:0;s:12:\"redirectBack\";i:0;s:5:\"fuzzy\";i:0;s:9:\"loadFirst\";i:0;s:10:\"useCaption\";i:0;s:8:\"fullsize\";i:0;s:14:\"disableCaptcha\";i:0;s:14:\"reg_allowLogin\";i:0;s:12:\"reg_skipName\";i:0;s:13:\"reg_deleteDir\";i:0;s:13:\"reg_assignDir\";i:0;s:12:\"reg_activate\";i:0;s:9:\"protected\";i:0;s:22:\"hofff_navigation_roots\";s:14:\"a:1:{i:0;i:1;}\";s:28:\"hofff_navigation_roots_order\";N;s:22:\"hofff_navigation_start\";i:1;s:30:\"hofff_navigation_respectHidden\";s:0:\"\";s:31:\"hofff_navigation_respectPublish\";s:0:\"\";s:30:\"hofff_navigation_respectGuests\";s:0:\"\";s:29:\"hofff_navigation_includeStart\";s:0:\"\";s:32:\"hofff_navigation_showHiddenStart\";s:0:\"\";s:27:\"hofff_navigation_showHidden\";s:0:\"\";s:30:\"hofff_navigation_showProtected\";s:0:\"\";s:27:\"hofff_navigation_showGuests\";s:0:\"\";s:26:\"hofff_navigation_addFields\";N;s:36:\"hofff_navigation_noForwardResolution\";s:0:\"\";s:31:\"hofff_navigation_showErrorPages\";s:0:\"\";s:30:\"hofff_navigation_disableEvents\";s:0:\"\";s:30:\"hofff_navigation_currentAsRoot\";s:0:\"\";s:28:\"hofff_navigation_defineRoots\";s:1:\"1\";s:27:\"hofff_navigation_defineStop\";s:0:\"\";s:21:\"hofff_navigation_stop\";s:5:\"0,1,2\";s:27:\"hofff_navigation_defineHard\";s:0:\"\";s:21:\"hofff_navigation_hard\";i:0;s:26:\"hofff_navigation_isSitemap\";s:0:\"\";s:32:\"hofff_navigation_hideSingleLevel\";s:0:\"\";s:29:\"hofff_navigation_addLegacyCss\";s:0:\"\";s:3:\"pid\";i:1;s:6:\"tstamp\";i:1708349260;s:4:\"name\";s:10:\"Navigation\";s:8:\"headline\";s:45:\"a:2:{s:4:\"unit\";s:2:\"h2\";s:5:\"value\";s:0:\"\";}\";s:4:\"type\";s:21:\"hofff_navigation_menu\";s:11:\"levelOffset\";i:0;s:9:\"showLevel\";i:0;s:8:\"rootPage\";i:0;s:13:\"navigationTpl\";s:0:\"\";s:9:\"customTpl\";s:0:\"\";s:5:\"pages\";N;s:11:\"customLabel\";s:0:\"\";s:6:\"jumpTo\";i:0;s:12:\"overviewPage\";i:0;s:11:\"pwResetPage\";i:0;s:8:\"editable\";N;s:9:\"memberTpl\";s:0:\"\";s:4:\"form\";i:0;s:9:\"queryType\";s:3:\"and\";s:13:\"contextLength\";s:0:\"\";s:16:\"minKeywordLength\";i:4;s:7:\"perPage\";i:0;s:10:\"searchType\";s:6:\"simple\";s:9:\"searchTpl\";s:0:\"\";s:8:\"inColumn\";s:4:\"main\";s:9:\"skipFirst\";i:0;s:9:\"singleSRC\";N;s:7:\"imgSize\";s:0:\"\";s:8:\"multiSRC\";N;s:4:\"html\";N;s:14:\"unfilteredHtml\";N;s:9:\"rss_cache\";i:3600;s:8:\"rss_feed\";N;s:12:\"rss_template\";s:0:\"\";s:13:\"numberOfItems\";i:3;s:10:\"reg_groups\";N;s:9:\"reg_close\";s:0:\"\";s:11:\"reg_homeDir\";N;s:10:\"reg_jumpTo\";i:0;s:8:\"reg_text\";N;s:12:\"reg_password\";N;s:4:\"data\";N;s:6:\"groups\";N;s:5:\"cssID\";s:28:\"a:2:{i:0;s:0:\"\";i:1;s:0:\"\";}\";s:24:\"rootPageDependentModules\";N;}'),(39,0,1,1708349268,24,'tl_module',1,'admin','Navigation','contao?act=edit&do=themes&id=1&table=tl_module','a:87:{s:2:\"id\";i:1;s:9:\"hardLimit\";i:0;s:13:\"showProtected\";i:0;s:10:\"defineRoot\";i:0;s:10:\"showHidden\";i:0;s:9:\"autologin\";i:0;s:12:\"redirectBack\";i:0;s:5:\"fuzzy\";i:0;s:9:\"loadFirst\";i:0;s:10:\"useCaption\";i:0;s:8:\"fullsize\";i:0;s:14:\"disableCaptcha\";i:0;s:14:\"reg_allowLogin\";i:0;s:12:\"reg_skipName\";i:0;s:13:\"reg_deleteDir\";i:0;s:13:\"reg_assignDir\";i:0;s:12:\"reg_activate\";i:0;s:9:\"protected\";i:0;s:22:\"hofff_navigation_roots\";s:14:\"a:1:{i:0;i:1;}\";s:28:\"hofff_navigation_roots_order\";N;s:22:\"hofff_navigation_start\";i:1;s:30:\"hofff_navigation_respectHidden\";s:0:\"\";s:31:\"hofff_navigation_respectPublish\";s:0:\"\";s:30:\"hofff_navigation_respectGuests\";s:0:\"\";s:29:\"hofff_navigation_includeStart\";s:0:\"\";s:32:\"hofff_navigation_showHiddenStart\";s:0:\"\";s:27:\"hofff_navigation_showHidden\";s:0:\"\";s:30:\"hofff_navigation_showProtected\";s:0:\"\";s:27:\"hofff_navigation_showGuests\";s:0:\"\";s:26:\"hofff_navigation_addFields\";N;s:36:\"hofff_navigation_noForwardResolution\";s:0:\"\";s:31:\"hofff_navigation_showErrorPages\";s:0:\"\";s:30:\"hofff_navigation_disableEvents\";s:0:\"\";s:30:\"hofff_navigation_currentAsRoot\";s:0:\"\";s:28:\"hofff_navigation_defineRoots\";s:1:\"1\";s:27:\"hofff_navigation_defineStop\";s:0:\"\";s:21:\"hofff_navigation_stop\";s:5:\"0,1,2\";s:27:\"hofff_navigation_defineHard\";s:0:\"\";s:21:\"hofff_navigation_hard\";i:0;s:26:\"hofff_navigation_isSitemap\";s:0:\"\";s:32:\"hofff_navigation_hideSingleLevel\";s:0:\"\";s:29:\"hofff_navigation_addLegacyCss\";s:0:\"\";s:3:\"pid\";i:1;s:6:\"tstamp\";i:1708349268;s:4:\"name\";s:10:\"Navigation\";s:8:\"headline\";s:45:\"a:2:{s:4:\"unit\";s:2:\"h2\";s:5:\"value\";s:0:\"\";}\";s:4:\"type\";s:21:\"hofff_navigation_menu\";s:11:\"levelOffset\";i:0;s:9:\"showLevel\";i:0;s:8:\"rootPage\";i:0;s:13:\"navigationTpl\";s:0:\"\";s:9:\"customTpl\";s:0:\"\";s:5:\"pages\";N;s:11:\"customLabel\";s:0:\"\";s:6:\"jumpTo\";i:0;s:12:\"overviewPage\";i:0;s:11:\"pwResetPage\";i:0;s:8:\"editable\";N;s:9:\"memberTpl\";s:0:\"\";s:4:\"form\";i:0;s:9:\"queryType\";s:3:\"and\";s:13:\"contextLength\";s:0:\"\";s:16:\"minKeywordLength\";i:4;s:7:\"perPage\";i:0;s:10:\"searchType\";s:6:\"simple\";s:9:\"searchTpl\";s:0:\"\";s:8:\"inColumn\";s:4:\"main\";s:9:\"skipFirst\";i:0;s:9:\"singleSRC\";N;s:7:\"imgSize\";s:0:\"\";s:8:\"multiSRC\";N;s:4:\"html\";N;s:14:\"unfilteredHtml\";N;s:9:\"rss_cache\";i:3600;s:8:\"rss_feed\";N;s:12:\"rss_template\";s:0:\"\";s:13:\"numberOfItems\";i:3;s:10:\"reg_groups\";N;s:9:\"reg_close\";s:0:\"\";s:11:\"reg_homeDir\";N;s:10:\"reg_jumpTo\";i:0;s:8:\"reg_text\";N;s:12:\"reg_password\";N;s:4:\"data\";N;s:6:\"groups\";N;s:5:\"cssID\";s:28:\"a:2:{i:0;s:0:\"\";i:1;s:0:\"\";}\";s:24:\"rootPageDependentModules\";N;}'),(40,0,1,1708349269,25,'tl_module',1,'admin','Navigation','contao?act=edit&do=themes&id=1&table=tl_module','a:87:{s:2:\"id\";i:1;s:9:\"hardLimit\";i:0;s:13:\"showProtected\";i:0;s:10:\"defineRoot\";i:0;s:10:\"showHidden\";i:0;s:9:\"autologin\";i:0;s:12:\"redirectBack\";i:0;s:5:\"fuzzy\";i:0;s:9:\"loadFirst\";i:0;s:10:\"useCaption\";i:0;s:8:\"fullsize\";i:0;s:14:\"disableCaptcha\";i:0;s:14:\"reg_allowLogin\";i:0;s:12:\"reg_skipName\";i:0;s:13:\"reg_deleteDir\";i:0;s:13:\"reg_assignDir\";i:0;s:12:\"reg_activate\";i:0;s:9:\"protected\";i:0;s:22:\"hofff_navigation_roots\";s:14:\"a:1:{i:0;i:1;}\";s:28:\"hofff_navigation_roots_order\";N;s:22:\"hofff_navigation_start\";i:1;s:30:\"hofff_navigation_respectHidden\";s:0:\"\";s:31:\"hofff_navigation_respectPublish\";s:0:\"\";s:30:\"hofff_navigation_respectGuests\";s:0:\"\";s:29:\"hofff_navigation_includeStart\";s:0:\"\";s:32:\"hofff_navigation_showHiddenStart\";s:0:\"\";s:27:\"hofff_navigation_showHidden\";s:0:\"\";s:30:\"hofff_navigation_showProtected\";s:0:\"\";s:27:\"hofff_navigation_showGuests\";s:0:\"\";s:26:\"hofff_navigation_addFields\";N;s:36:\"hofff_navigation_noForwardResolution\";s:0:\"\";s:31:\"hofff_navigation_showErrorPages\";s:0:\"\";s:30:\"hofff_navigation_disableEvents\";s:0:\"\";s:30:\"hofff_navigation_currentAsRoot\";s:0:\"\";s:28:\"hofff_navigation_defineRoots\";s:0:\"\";s:27:\"hofff_navigation_defineStop\";s:0:\"\";s:21:\"hofff_navigation_stop\";s:5:\"0,1,2\";s:27:\"hofff_navigation_defineHard\";s:0:\"\";s:21:\"hofff_navigation_hard\";i:0;s:26:\"hofff_navigation_isSitemap\";s:0:\"\";s:32:\"hofff_navigation_hideSingleLevel\";s:0:\"\";s:29:\"hofff_navigation_addLegacyCss\";s:0:\"\";s:3:\"pid\";i:1;s:6:\"tstamp\";i:1708349269;s:4:\"name\";s:10:\"Navigation\";s:8:\"headline\";s:45:\"a:2:{s:4:\"unit\";s:2:\"h2\";s:5:\"value\";s:0:\"\";}\";s:4:\"type\";s:21:\"hofff_navigation_menu\";s:11:\"levelOffset\";i:0;s:9:\"showLevel\";i:0;s:8:\"rootPage\";i:0;s:13:\"navigationTpl\";s:0:\"\";s:9:\"customTpl\";s:0:\"\";s:5:\"pages\";N;s:11:\"customLabel\";s:0:\"\";s:6:\"jumpTo\";i:0;s:12:\"overviewPage\";i:0;s:11:\"pwResetPage\";i:0;s:8:\"editable\";N;s:9:\"memberTpl\";s:0:\"\";s:4:\"form\";i:0;s:9:\"queryType\";s:3:\"and\";s:13:\"contextLength\";s:0:\"\";s:16:\"minKeywordLength\";i:4;s:7:\"perPage\";i:0;s:10:\"searchType\";s:6:\"simple\";s:9:\"searchTpl\";s:0:\"\";s:8:\"inColumn\";s:4:\"main\";s:9:\"skipFirst\";i:0;s:9:\"singleSRC\";N;s:7:\"imgSize\";s:0:\"\";s:8:\"multiSRC\";N;s:4:\"html\";N;s:14:\"unfilteredHtml\";N;s:9:\"rss_cache\";i:3600;s:8:\"rss_feed\";N;s:12:\"rss_template\";s:0:\"\";s:13:\"numberOfItems\";i:3;s:10:\"reg_groups\";N;s:9:\"reg_close\";s:0:\"\";s:11:\"reg_homeDir\";N;s:10:\"reg_jumpTo\";i:0;s:8:\"reg_text\";N;s:12:\"reg_password\";N;s:4:\"data\";N;s:6:\"groups\";N;s:5:\"cssID\";s:28:\"a:2:{i:0;s:0:\"\";i:1;s:0:\"\";}\";s:24:\"rootPageDependentModules\";N;}'),(41,0,1,1708349270,26,'tl_module',1,'admin','Navigation','contao?act=edit&do=themes&id=1&table=tl_module','a:87:{s:2:\"id\";i:1;s:9:\"hardLimit\";i:0;s:13:\"showProtected\";i:0;s:10:\"defineRoot\";i:0;s:10:\"showHidden\";i:0;s:9:\"autologin\";i:0;s:12:\"redirectBack\";i:0;s:5:\"fuzzy\";i:0;s:9:\"loadFirst\";i:0;s:10:\"useCaption\";i:0;s:8:\"fullsize\";i:0;s:14:\"disableCaptcha\";i:0;s:14:\"reg_allowLogin\";i:0;s:12:\"reg_skipName\";i:0;s:13:\"reg_deleteDir\";i:0;s:13:\"reg_assignDir\";i:0;s:12:\"reg_activate\";i:0;s:9:\"protected\";i:0;s:22:\"hofff_navigation_roots\";s:14:\"a:1:{i:0;i:1;}\";s:28:\"hofff_navigation_roots_order\";N;s:22:\"hofff_navigation_start\";i:1;s:30:\"hofff_navigation_respectHidden\";s:0:\"\";s:31:\"hofff_navigation_respectPublish\";s:0:\"\";s:30:\"hofff_navigation_respectGuests\";s:0:\"\";s:29:\"hofff_navigation_includeStart\";s:0:\"\";s:32:\"hofff_navigation_showHiddenStart\";s:0:\"\";s:27:\"hofff_navigation_showHidden\";s:0:\"\";s:30:\"hofff_navigation_showProtected\";s:0:\"\";s:27:\"hofff_navigation_showGuests\";s:0:\"\";s:26:\"hofff_navigation_addFields\";N;s:36:\"hofff_navigation_noForwardResolution\";s:0:\"\";s:31:\"hofff_navigation_showErrorPages\";s:0:\"\";s:30:\"hofff_navigation_disableEvents\";s:0:\"\";s:30:\"hofff_navigation_currentAsRoot\";s:0:\"\";s:28:\"hofff_navigation_defineRoots\";s:0:\"\";s:27:\"hofff_navigation_defineStop\";s:0:\"\";s:21:\"hofff_navigation_stop\";s:5:\"0,1,2\";s:27:\"hofff_navigation_defineHard\";s:0:\"\";s:21:\"hofff_navigation_hard\";i:0;s:26:\"hofff_navigation_isSitemap\";s:0:\"\";s:32:\"hofff_navigation_hideSingleLevel\";s:0:\"\";s:29:\"hofff_navigation_addLegacyCss\";s:0:\"\";s:3:\"pid\";i:1;s:6:\"tstamp\";i:1708349270;s:4:\"name\";s:10:\"Navigation\";s:8:\"headline\";s:45:\"a:2:{s:4:\"unit\";s:2:\"h2\";s:5:\"value\";s:0:\"\";}\";s:4:\"type\";s:21:\"hofff_navigation_menu\";s:11:\"levelOffset\";i:0;s:9:\"showLevel\";i:0;s:8:\"rootPage\";i:0;s:13:\"navigationTpl\";s:0:\"\";s:9:\"customTpl\";s:0:\"\";s:5:\"pages\";N;s:11:\"customLabel\";s:0:\"\";s:6:\"jumpTo\";i:0;s:12:\"overviewPage\";i:0;s:11:\"pwResetPage\";i:0;s:8:\"editable\";N;s:9:\"memberTpl\";s:0:\"\";s:4:\"form\";i:0;s:9:\"queryType\";s:3:\"and\";s:13:\"contextLength\";s:0:\"\";s:16:\"minKeywordLength\";i:4;s:7:\"perPage\";i:0;s:10:\"searchType\";s:6:\"simple\";s:9:\"searchTpl\";s:0:\"\";s:8:\"inColumn\";s:4:\"main\";s:9:\"skipFirst\";i:0;s:9:\"singleSRC\";N;s:7:\"imgSize\";s:0:\"\";s:8:\"multiSRC\";N;s:4:\"html\";N;s:14:\"unfilteredHtml\";N;s:9:\"rss_cache\";i:3600;s:8:\"rss_feed\";N;s:12:\"rss_template\";s:0:\"\";s:13:\"numberOfItems\";i:3;s:10:\"reg_groups\";N;s:9:\"reg_close\";s:0:\"\";s:11:\"reg_homeDir\";N;s:10:\"reg_jumpTo\";i:0;s:8:\"reg_text\";N;s:12:\"reg_password\";N;s:4:\"data\";N;s:6:\"groups\";N;s:5:\"cssID\";s:28:\"a:2:{i:0;s:0:\"\";i:1;s:0:\"\";}\";s:24:\"rootPageDependentModules\";N;}'),(42,1,1,1708349281,27,'tl_module',1,'admin','Navigation','contao?act=edit&do=themes&id=1&table=tl_module','a:87:{s:2:\"id\";i:1;s:9:\"hardLimit\";i:0;s:13:\"showProtected\";i:0;s:10:\"defineRoot\";i:0;s:10:\"showHidden\";i:0;s:9:\"autologin\";i:0;s:12:\"redirectBack\";i:0;s:5:\"fuzzy\";i:0;s:9:\"loadFirst\";i:0;s:10:\"useCaption\";i:0;s:8:\"fullsize\";i:0;s:14:\"disableCaptcha\";i:0;s:14:\"reg_allowLogin\";i:0;s:12:\"reg_skipName\";i:0;s:13:\"reg_deleteDir\";i:0;s:13:\"reg_assignDir\";i:0;s:12:\"reg_activate\";i:0;s:9:\"protected\";i:0;s:22:\"hofff_navigation_roots\";s:14:\"a:1:{i:0;i:1;}\";s:28:\"hofff_navigation_roots_order\";N;s:22:\"hofff_navigation_start\";i:0;s:30:\"hofff_navigation_respectHidden\";s:0:\"\";s:31:\"hofff_navigation_respectPublish\";s:0:\"\";s:30:\"hofff_navigation_respectGuests\";s:0:\"\";s:29:\"hofff_navigation_includeStart\";s:0:\"\";s:32:\"hofff_navigation_showHiddenStart\";s:0:\"\";s:27:\"hofff_navigation_showHidden\";s:0:\"\";s:30:\"hofff_navigation_showProtected\";s:0:\"\";s:27:\"hofff_navigation_showGuests\";s:0:\"\";s:26:\"hofff_navigation_addFields\";N;s:36:\"hofff_navigation_noForwardResolution\";s:0:\"\";s:31:\"hofff_navigation_showErrorPages\";s:0:\"\";s:30:\"hofff_navigation_disableEvents\";s:0:\"\";s:30:\"hofff_navigation_currentAsRoot\";s:0:\"\";s:28:\"hofff_navigation_defineRoots\";s:0:\"\";s:27:\"hofff_navigation_defineStop\";s:0:\"\";s:21:\"hofff_navigation_stop\";s:5:\"0,1,2\";s:27:\"hofff_navigation_defineHard\";s:0:\"\";s:21:\"hofff_navigation_hard\";i:0;s:26:\"hofff_navigation_isSitemap\";s:0:\"\";s:32:\"hofff_navigation_hideSingleLevel\";s:0:\"\";s:29:\"hofff_navigation_addLegacyCss\";s:0:\"\";s:3:\"pid\";i:1;s:6:\"tstamp\";i:1708349281;s:4:\"name\";s:10:\"Navigation\";s:8:\"headline\";s:45:\"a:2:{s:4:\"unit\";s:2:\"h2\";s:5:\"value\";s:0:\"\";}\";s:4:\"type\";s:21:\"hofff_navigation_menu\";s:11:\"levelOffset\";i:0;s:9:\"showLevel\";i:0;s:8:\"rootPage\";i:0;s:13:\"navigationTpl\";s:0:\"\";s:9:\"customTpl\";s:0:\"\";s:5:\"pages\";N;s:11:\"customLabel\";s:0:\"\";s:6:\"jumpTo\";i:0;s:12:\"overviewPage\";i:0;s:11:\"pwResetPage\";i:0;s:8:\"editable\";N;s:9:\"memberTpl\";s:0:\"\";s:4:\"form\";i:0;s:9:\"queryType\";s:3:\"and\";s:13:\"contextLength\";s:0:\"\";s:16:\"minKeywordLength\";i:4;s:7:\"perPage\";i:0;s:10:\"searchType\";s:6:\"simple\";s:9:\"searchTpl\";s:0:\"\";s:8:\"inColumn\";s:4:\"main\";s:9:\"skipFirst\";i:0;s:9:\"singleSRC\";N;s:7:\"imgSize\";s:0:\"\";s:8:\"multiSRC\";N;s:4:\"html\";N;s:14:\"unfilteredHtml\";N;s:9:\"rss_cache\";i:3600;s:8:\"rss_feed\";N;s:12:\"rss_template\";s:0:\"\";s:13:\"numberOfItems\";i:3;s:10:\"reg_groups\";N;s:9:\"reg_close\";s:0:\"\";s:11:\"reg_homeDir\";N;s:10:\"reg_jumpTo\";i:0;s:8:\"reg_text\";N;s:12:\"reg_password\";N;s:4:\"data\";N;s:6:\"groups\";N;s:5:\"cssID\";s:28:\"a:2:{i:0;s:0:\"\";i:1;s:0:\"\";}\";s:24:\"rootPageDependentModules\";N;}');
/*!40000 ALTER TABLE `tl_version` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-02-19 14:38:09
